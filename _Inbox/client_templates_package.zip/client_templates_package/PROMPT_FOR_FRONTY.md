# Prompt for Fronty

```
You are working on the CRM frontend. Task: add full Italian (it) translations for ALL client-communication templates, while keeping the existing English (en) versions unchanged.

Source: templates_en.json in this package (also in templates_en.md).

Scope: every template, both channels (email: subject + body; messenger: WhatsApp/Telegram/SMS text). IDs: welcome, intake_ack, intake_nudge, appointment_propose, appointment_confirm, appointment_reminder, appointment_reschedule, appointment_cancel_confirm, appointment_missed, documents_received, documents_missing, event_status_update, event_deadline_alert, event_invitation, invoice_payment, feedback_request. Do not skip any, especially welcome, appointment proposal, appointment confirmation and event notifications.

Requirements:
1. Data model: each template has locale versions {en, it}. Keep en as fallback. Do not edit English text.
2. Translation: natural, professional Italian for law/accounting firms. Formal "Lei". Greeting "Gentile {{client_name}},", sign-off "Cordiali saluti,". Dates DD/MM/YYYY, 24-hour time.
3. Keep every {{placeholder}} exactly as is. Do not translate placeholders, links or emojis.
4. Messenger texts stay short (under about 300 characters), keeping reply keywords. Accept both English and Italian replies: YES/SI/SÌ, NO, CONFIRM/CONFERMO.
5. UI: add EN/IT language selector in the template editor and preview. Add a per-client "preferred language" field (default it for Italian clients, en otherwise) and use it when sending.
6. Validation: check every template has en and it for email and messenger, and that placeholders match across languages. Warn in UI if missing.
7. Output: list files changed, new keys added, and any template not completed.

Work step by step, commit in small reversible changes, and do not modify backend sending logic beyond the locale lookup.
```
