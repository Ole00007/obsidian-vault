# Client communication templates (EN)

## welcome - Welcome new client
**Email subject:** Welcome to {{firm_name}}, {{client_name}}

```
Dear {{client_name}},

Welcome to {{firm_name}}. {{staff_name}} ({{staff_role}}) will be your main contact for {{matter}}. Next steps:
1. We confirm your details.
2. You send the documents we need: {{upload_link}}.
3. We schedule your first meeting.

Questions? Reply to this email or call {{phone}}.

Kind regards,
{{staff_name}}
```
**Messenger:** Hello {{client_name}}, welcome to {{firm_name}}! I'm {{staff_name}} and I'll be handling {{matter}}. I'll send the next steps shortly. You can write to me here any time.

## intake_ack - Same-day acknowledgment after intake
**Email subject:** Thanks, {{client_name}} - next steps for {{firm_name}}

```
Dear {{client_name}},

Thank you for contacting {{firm_name}} about {{matter}}. We have received your details and {{staff_name}} will review them.

Please send: {{doc_list}}
Secure upload: {{upload_link}} (handled under GDPR, kept confidential).

Book a first call: {{booking_link}}. We reply within 1 business day.

Kind regards,
{{staff_name}}
```
**Messenger:** Hi {{client_name}}, thanks for contacting {{firm_name}} about {{matter}}. Please send {{doc_list}} here: {{upload_link}}. Book a call: {{booking_link}}

## intake_nudge - Nudge after no reply (3-5 days)
**Email subject:** Still need help with {{matter}}? Quick reminder

```
Dear {{client_name}},

I'm following up on your enquiry. I haven't received your documents/availability yet.

Reply with:
A - Send the checklist again
B - Call me on {{phone}}
C - No longer needed

If we don't hear from you, we'll close the request on {{deadline}}. You can reopen it any time.

Kind regards,
{{staff_name}}
```
**Messenger:** Hi {{client_name}}, quick follow-up on {{matter}}. Reply A = resend checklist, B = call me, C = no longer needed.

## appointment_propose - Propose appointment times
**Email subject:** Choose a time for your appointment

```
Dear {{client_name}},

We'd like to schedule your appointment about {{matter}}. Available times:
- {{slot_1}}
- {{slot_2}}
- {{slot_3}}

Reply with your preferred option, or pick another time: {{booking_link}}.

Kind regards,
{{staff_name}}
```
**Messenger:** Hi {{client_name}}, can we meet for {{matter}}? 1) {{slot_1}} 2) {{slot_2}} 3) {{slot_3}}. Reply 1, 2 or 3, or choose here: {{booking_link}}

## appointment_confirm - Confirm appointment
**Email subject:** Appointment confirmed: {{date}} at {{time}}

```
Dear {{client_name}},

Your appointment is confirmed.
Date: {{date}}
Time: {{time}}
Place: {{location}}
Online link: {{meeting_link}}
With: {{staff_name}}
Please bring: {{doc_list}}

To reschedule, reply to this email or call {{phone}}.

Kind regards,
{{firm_name}}
```
**Messenger:** Confirmed ✅ {{date}} at {{time}}, {{location}}. With {{staff_name}}. Please bring: {{doc_list}}. Need to change it? Reply here.

## appointment_reminder - Reminder before appointment
**Email subject:** Reminder: appointment on {{date}} at {{time}}

```
Dear {{client_name}},

A reminder of your appointment with {{staff_name}} on {{date}} at {{time}} ({{location}} / {{meeting_link}}). Please reply "Confirm" or ask us to reschedule.

Kind regards,
{{firm_name}}
```
**Messenger:** Reminder: {{date}} at {{time}} with {{staff_name}}. Reply YES to confirm or NO to reschedule.

## appointment_reschedule - Firm needs to reschedule
**Email subject:** We need to reschedule your appointment

```
Dear {{client_name}},

We apologise, but we need to move your appointment from {{date}} at {{time}}. New options: {{slot_1}}, {{slot_2}}, {{slot_3}}, or choose here: {{booking_link}}.

Thank you for understanding.

Kind regards,
{{staff_name}}
```
**Messenger:** Sorry {{client_name}}, we must move your {{date}} {{time}} appointment. New options: {{slot_1}} / {{slot_2}} / {{slot_3}}. Which suits you?

## appointment_cancel_confirm - Cancellation confirmation
**Email subject:** Your appointment has been cancelled

```
Dear {{client_name}},

Your appointment on {{date}} at {{time}} is cancelled as requested. You can book a new time any time: {{booking_link}}.

Kind regards,
{{firm_name}}
```
**Messenger:** Done, your {{date}} {{time}} appointment is cancelled. Rebook any time: {{booking_link}}

## appointment_missed - Missed appointment
**Email subject:** We missed you today

```
Dear {{client_name}},

We were expecting you today at {{time}}. If something came up, choose a new time here: {{booking_link}}.

Kind regards,
{{staff_name}}
```
**Messenger:** Hi {{client_name}}, we missed you today. Want to rebook? {{booking_link}}

## documents_received - Documents received
**Email subject:** We received your documents

```
Dear {{client_name}},

Thank you, we received your documents for {{matter}}. We will review them and reply by {{deadline}}. If anything is missing, we'll tell you.

Kind regards,
{{staff_name}}
```
**Messenger:** Thanks {{client_name}}, documents received ✅ We'll update you by {{deadline}}.

## documents_missing - Documents missing
**Email subject:** Documents still needed for {{matter}}

```
Dear {{client_name}},

To continue with {{matter}}, we still need: {{doc_list}}. Please upload them here: {{upload_link}} by {{deadline}}.

Kind regards,
{{staff_name}}
```
**Messenger:** Hi {{client_name}}, we still need: {{doc_list}}. Please send by {{deadline}}: {{upload_link}}

## event_status_update - Case/file status event
**Email subject:** Update on {{matter}}: {{status}}

```
Dear {{client_name}},

Your file {{matter}} has a new status: {{status}}. Next step: {{event_name}}. We'll keep you informed.

Kind regards,
{{staff_name}}
```
**Messenger:** Update on {{matter}}: {{status}}. Next step: {{event_name}}.

## event_deadline_alert - Deadline alert
**Email subject:** Important deadline: {{event_name}} on {{deadline}}

```
Dear {{client_name}},

Please note the deadline for {{event_name}} is {{deadline}}. Action needed from you: {{doc_list}}. Contact us on {{phone}} if you need help.

Kind regards,
{{staff_name}}
```
**Messenger:** ⚠️ Deadline: {{event_name}} on {{deadline}}. We need: {{doc_list}}. Call {{phone}} if you need help.

## event_invitation - Event invitation
**Email subject:** You're invited: {{event_name}}

```
Dear {{client_name}},

We invite you to {{event_name}} on {{date}} at {{time}}, {{location}}. Please confirm attendance: {{booking_link}}.

Kind regards,
{{firm_name}}
```
**Messenger:** You're invited to {{event_name}} on {{date}} at {{time}}, {{location}}. Will you join? Reply YES or NO.

## invoice_payment - Invoice
**Email subject:** Invoice for {{matter}}

```
Dear {{client_name}},

Your invoice of {{amount}} for {{matter}} is ready: {{invoice_link}}. Payment is due by {{deadline}}.

Kind regards,
{{firm_name}}
```
**Messenger:** Invoice {{amount}} for {{matter}}: {{invoice_link}}. Due {{deadline}}. Thank you!

## feedback_request - Review request
**Email subject:** How did we do?

```
Dear {{client_name}},

Thank you for choosing {{firm_name}}. A short review helps us improve: {{review_link}}.

Kind regards,
{{staff_name}}
```
**Messenger:** Thanks for your trust, {{client_name}}! Could you leave a quick review? {{review_link}}

