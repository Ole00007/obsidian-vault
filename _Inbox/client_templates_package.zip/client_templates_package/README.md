Package: 16 client-communication templates (email + messenger), English source with empty Italian slots, and the Fronty translation prompt.
Placeholders use {{double_braces}}.
