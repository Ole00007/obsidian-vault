# LexFlow-Elisa | First office pilot | 24.11.2026

[Italiano: guida per lo studio](IT.md) · [English: pilot guide](EN.md) · [Русский: руководство](RU.md)

[Scelta e messaggio per lo studio / Decision sheet and pre-visit message / Выбор установки и сообщение адвокату](decision.md)

[Prova / Exercise / Упражнение](exercise.txt) · [Verbale / Scorecard / Протокол](scorecard.md) · [Windows test utility / Utilità / Утилита](Test-LocalModel.ps1)

**IT:** estrarre tutto in una cartella privata non sincronizzata. Leggere IT.md prima di eseguire qualsiasi comando. Questo kit contiene documentazione e una prova tecnica con dati inventati, non il programma di installazione di Elisa.

**EN:** extract into a private, unsynced folder. Read EN.md before running anything. This is a pilot kit and synthetic model test, not the Elisa application installer.

**RU:** распакуйте архив в закрытую папку без синхронизации. Перед запуском прочитайте RU.md. Это комплект для пилота с вымышленным примером, а не установщик Elisa.
