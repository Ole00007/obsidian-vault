# LexFlow-Elisa | First law-office pilot

Tuesday, 24 November 2026: the lawyer turns three short records into a chronology, verifies each entry against its source and identifies the missing receipt. A useful result is a draft the lawyer can check and reproduce without you. Configure the workflow; do not train a model or give a generic training course.

## Decision model

| Route | Choose when | Decision |
|---|---|---|
| Elisa on the PC + existing on-device LLM | Compatible build, sufficient memory and working local endpoint | First choice. No Grok subscription, new agent or API bill for that local inference. |
| Local Elisa + office-owned model server | PC is too slow; IT confirms the server identity, private network, access and logs | Next compute option. Data leaves the PC but stays inside the verified office boundary. |
| Hermes + same model | A repeatable task genuinely needs tools or several steps, after the direct test passes | First agentic option. One existing agent, one test matter, read and draft only. No shell, sending, cron or shared memory. |
| Local Elisa + customer cloud API | Approved need for a stronger model | Separate opt-in route with the office's credentials, reviewed terms, region, retention and cost cap. No fallback. |
| Hosted Elisa | Office needs multi-user remote access | Separate deployment project: authentication, tenant/matter isolation, encryption, restore, deletion and support. No hosted service is provisioned here. |

Hermes orchestrates tools and can use a local endpoint; Grok is a model/service option, not a substitute for that layer ([Hermes provider guide](https://hermes-agent.nousresearch.com/docs/integrations/providers)). Neither party has a Grok subscription. Skip it for the pilot; reconsider when multiple paying firms request it and margin covers integration/support. Assess API usage separately from consumer seats ([xAI billing](https://docs.x.ai/console/billing)).

## Before Monday ends

1. Obtain OS version, RAM, disk space, GPU, existing model/server and authorised IT contact. Ask for no case files. Reserve 45 minutes.
2. Obtain the approved Elisa release, version, publisher signature or independently supplied checksum, requirements, launch and uninstall instructions. Rehearse on a comparable clean PC. Verify where UI, backend, database, search, telemetry, OCR and backups run. Never point a test at the live CRM.
3. With office approval record existing settings, install using the release-specific instructions and minimum privileges, create an isolated test workspace, select the approved endpoint only if supported by this build. Close, reopen and repeat offline. No specific Elisa settings screen is assumed.
4. Missing build, install permission or local backend? Stop installation. Run the model-only test or manual exercise instead. Do not record that as an Elisa pass.

## Local Windows model check

Reuse the customer's model first. If needed, IT may install [Ollama for Windows](https://docs.ollama.com/windows) and pre-download a licensed local model that fits the PC; use the [official quickstart](https://docs.ollama.com/quickstart) as an example, not a mandatory model choice.

With IT approval set user environment variables `OLLAMA_NO_CLOUD=1` and `OLLAMA_HOST=127.0.0.1:11434`; fully quit and relaunch Ollama, then verify cloud-disabled status in its logs ([Ollama FAQ](https://docs.ollama.com/faq)). Expose no network port. Disable sync, cloud OCR, telemetry and fallbacks across the stack. Disconnect networking for the local test; before live use also inspect queues, logs and reconnect behaviour. A successful offline response alone does not rule out delayed uploads.

```powershell
ollama list
# In the extracted folder, replace TAG with the exact installed name.
.\Test-LocalModel.ps1 -Model "TAG"
```

The script sends only built-in fictional Italian text and prints a draft. It does not install Elisa, read matter files or grade legal conclusions. If blocked by IT policy, do not bypass it. Paste [the exercise](exercise.txt) into the approved local client instead. For a non-Ollama model use its own approved client. If slow, record elapsed time; do not silently switch to cloud.

## Adapt the lawyer's workflow

Ask: “Show me how you build a chronology now. Which error costs you the most time?” Record only approved preferences: language, columns, document/page format, disputed-fact wording and reviewer. No fine-tuning, automatic memory, cross-matter retrieval or reuse of real files. Before a live matter, the firm approves purpose, minimum data, destinations, permissions, retention and disposal.

**Prompt:** “Write an internal draft in Italian: date | event or statement | document and page | to verify. Distinguish attributed statements from documented facts. Identify the missing document. Infer no deadlines or debts. Do not send or file anything.”

**Meeting:** 5 min for permission and scope; 10 install and check; 10 baseline and first draft; 10 independent test; 10 review and decision. For the independent test, the lawyer changes the fictional €400 statement to €450 and runs the draft unaided. Expect €450 as reported, not verified. Use the actual app for this variation, not the fixed script.

**Release decision:** complete the [scorecard](scorecard.md). Continue only when factual/source checks and critical controls pass and the lawyer finds the total time including review worthwhile. Otherwise record a defect without case data, restore prior settings and retest. Retain only what the firm approves; never delete originals. Offer a fixed-scope supervised pilot for one workflow with that acceptance condition, not a mandatory subscription.
