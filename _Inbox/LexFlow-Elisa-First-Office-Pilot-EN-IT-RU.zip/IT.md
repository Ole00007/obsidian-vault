# LexFlow-Elisa | Prima prova presso lo studio

Obiettivo di martedì 24 novembre 2026: l’avvocato prende tre brevi documenti, ottiene una cronologia con rimandi alle fonti e individua il giustificativo mancante. Il risultato utile è una bozza che il professionista sa controllare e rifare senza assistenza. Non è un corso, un parere, né un addestramento del modello.

## Decisione: prima il compito, poi l’agente

| Opzione | Quando sceglierla | Decisione |
|---|---|---|
| Elisa sul PC + modello già presente sul PC | Il modello accetta richieste locali, il PC ha memoria sufficiente e la build di Elisa consente di indicare l’endpoint | Prima scelta. Nessun abbonamento Grok. |
| Elisa sul PC + modello dello studio su server interno | PC poco potente; IT conferma identità del server, rete protetta, autenticazione, registri e permessi | Seconda scelta per la potenza di calcolo. I dati escono dal PC ma restano nel perimetro verificato dello studio. |
| Elisa + Hermes + stesso modello | Dopo il primo test, una sequenza ripetuta richiede strumenti o più passaggi | Un solo agente esistente, lettura del solo fascicolo di prova e bozze. Niente invii, shell, cron o memoria condivisa. |
| Elisa locale + API cloud dello studio | Serve qualità o capacità non ottenibile in locale | Opzione separata e non attiva. Lo studio sceglie fornitore, trattamento dati, regione, conservazione e tetto di spesa. Nessun passaggio automatico al cloud. |
| Intera Elisa ospitata in cloud | Serve accesso multiutente e c’è una distribuzione verificata | Progetto distinto: autenticazione, separazione tra studi e fascicoli, cifratura, backup/ripristino, cancellazione e assistenza. Nessun servizio cloud pronto viene fornito con questo kit. |

Grok è un’opzione di modello/servizio; Hermes è il software che coordina strumenti e modelli, anche locali ([documentazione Hermes](https://hermes-agent.nousresearch.com/docs/integrations/providers)). Non acquistare Grok né importare un bot per questa prova. Rivalutarlo quando più studi lo richiedono e i ricavi previsti coprono integrazione e assistenza; distinguere i costi API dall’abbonamento ([xAI, fatturazione](https://docs.x.ai/console/billing)).

## Prima dell’appuntamento: verificare la vera installazione

1. Entro lunedì chiedere solo: versione Windows, RAM, spazio libero, GPU, eventuale modello locale e referente IT autorizzato. Nessun nome cliente o documento. Prenotare 45 minuti.
2. Procurarsi la build Elisa approvata: versione, provenienza, firma o hash da una fonte indipendente, istruzioni di avvio/disinstallazione e requisiti. Provare la stessa build su un PC pulito comparabile. Controllare che interfaccia, backend, database, ricerca, log e modello possano operare nel perimetro scelto. Non puntare al CRM di produzione.
3. Sul PC dello studio, con autorizzazione: annotare impostazioni iniziali, avviare l’installer secondo le sue istruzioni con i privilegi minimi; creare uno spazio test separato. Collegare l’endpoint locale nella build solo se supportato. Chiudere, riaprire, ripetere la prova offline. Nessun percorso di menu Elisa è dato per verificato.
4. Se manca la build, l’installazione non è autorizzata o serve un backend remoto non approvato: fermare l’installazione. Fare la prova del solo modello o l’esercizio manuale. Non chiamarla collaudo Elisa.

## Prova tecnica locale su Windows

Preferire il modello dello studio. Se manca, IT può installare [Ollama per Windows](https://docs.ollama.com/windows) e scaricare prima dell’incontro un modello consentito e compatibile con il PC ([guida ufficiale con esempio](https://docs.ollama.com/quickstart)). Non scaricare modelli usando materiale di un fascicolo.

Con l’autorizzazione IT impostare `OLLAMA_NO_CLOUD=1` e `OLLAMA_HOST=127.0.0.1:11434` nelle variabili utente, quindi uscire completamente da Ollama e riavviarlo; verificare nel log che il cloud sia disabilitato ([Ollama FAQ](https://docs.ollama.com/faq)). Non aprire porte in rete. Disattivare sincronizzazione, telemetria, OCR remoto e fallback nell’intera catena. Disconnettere la rete per la prova locale; prima di usarla con dati veri verificare anche code, log e comportamento dopo la riconnessione.

```powershell
ollama list
# Dalla cartella estratta, sostituire TAG con il nome esatto installato
.\Test-LocalModel.ps1 -Model "TAG"
```

L’utilità usa solo testo inventato incorporato e stampa la bozza. Non installa Elisa e non valuta automaticamente il diritto. Se i criteri IT bloccano gli script, non aggirarli: incollare [la prova](exercise.txt) nell’interfaccia locale consentita. Se il modello usa un protocollo diverso, usare il suo client approvato. Se la macchina è lenta, misurare il tempo completo; non attivare il cloud di nascosto.

## Il flusso dell’avvocato, senza addestramento

Chiedere: «Mi fa vedere come costruisce oggi una cronologia e quali errori Le costerebbero più tempo?» Salvare solo le preferenze approvate: italiano, ordine delle colonne, citazione documento/pagina, dicitura per fatti contestati e chi revisiona. Nessun fine-tuning, memoria automatica, recupero da altri fascicoli o trasferimento di originali. Per la prima pratica reale lo studio approva finalità, dati minimi, destinazioni, accessi, conservazione e cancellazione.

**Istruzione da provare:** «Prepara una bozza interna: data | fatto o dichiarazione | documento e pagina | da verificare. Non trasformare una dichiarazione in fatto accertato. Indica il documento mancante. Non dedurre scadenze o debiti. Non inviare né archiviare.»

**Agenda:** 5 min perimetro e autorizzazione; 10 min installazione e verifica; 10 min procedura manuale e prima bozza; 10 min prova indipendente; 10 min correzioni e decisione. Per la prova indipendente l’avvocato, senza suggerimenti, cambia nel testo inventato €400 in €450: la nuova bozza deve citare €450 come dichiarazione, senza confermarla. Non usare la risposta precompilata dello script: eseguire questa variante nell’app.

**Decisione:** compilare il [verbale](scorecard.md). Proseguire solo se fatti, fonti e controlli critici sono corretti e il professionista ritiene utile il tempo totale, revisione compresa. In caso contrario fermarsi, registrare il difetto senza dati del cliente, ripristinare la configurazione iniziale e riprovare. Alla chiusura conservare soltanto gli elementi concordati; non cancellare originali. Proporre un pilota assistito a prezzo fisso per un solo flusso, con esito misurabile e senza abbonamenti imposti.
