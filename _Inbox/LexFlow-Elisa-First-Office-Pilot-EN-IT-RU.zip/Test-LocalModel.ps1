# Windows PowerShell 5.1+; synthetic exercise only. No file input, keys, or installation.
param([Parameter(Mandatory=$true)][string]$Model)
$ErrorActionPreference = 'Stop'
if ($Model -notmatch '^[A-Za-z0-9][A-Za-z0-9._:/-]{0,150}$' -or $Model -match 'cloud') { throw 'Use an installed local model tag.' }
Add-Type -AssemblyName System.Net.Http
$handler = New-Object System.Net.Http.HttpClientHandler
$handler.AllowAutoRedirect = $false
$handler.UseProxy = $false
$http = New-Object System.Net.Http.HttpClient($handler)
$http.Timeout = [TimeSpan]::FromSeconds(180)
$base = 'http://127.0.0.1:11434'
try {
  $tags = $http.GetStringAsync("$base/api/tags").GetAwaiter().GetResult() | ConvertFrom-Json
  if (@($tags.models | ForEach-Object { $_.name }) -cnotcontains $Model) { throw 'Tag not in local catalog. Check ollama list.' }
  # Fixed fixture: never accept real documents from disk, stdin or the clipboard.
  $fixture = @'
D1 p.1 | Preventivo, 03/11/2026: compenso proposto EUR 1.200. Non e' una fattura ne' una quietanza.
D2 p.1 | Nota del cliente, 09/11/2026: "Ho versato EUR 400 il 06/11/2026". Non e' allegata una ricevuta.
D3 p.1 | Email dello studio, 10/11/2026: "Chiediamo copia della ricevuta per verificare il versamento". Nessun termine indicato.
'@
  $instruction = 'Scrivi in italiano una tabella: data | fatto o dichiarazione | fonte e pagina | da verificare. Distingui preventivo e pagamento. Indica il documento mancante. Non dedurre scadenze, saldo dovuto o diritti. Solo bozza interna.'
  $payload = @{ model=$Model; stream=$false; messages=@(@{role='system';content=$instruction},@{role='user';content=$fixture});options=@{temperature=0;num_predict=550} } | ConvertTo-Json -Depth 6
  $body = New-Object System.Net.Http.StringContent($payload,[Text.Encoding]::UTF8,'application/json')
  $timer = [Diagnostics.Stopwatch]::StartNew()
  $r = $http.PostAsync("$base/api/chat",$body).GetAwaiter().GetResult()
  if (-not $r.IsSuccessStatusCode) { throw "Local server returned HTTP $([int]$r.StatusCode); no fallback." }
  $reply = $r.Content.ReadAsStringAsync().GetAwaiter().GetResult() | ConvertFrom-Json
  if ([string]::IsNullOrWhiteSpace($reply.message.content)) { throw 'No draft returned.' }
  Write-Output "LOCAL MODEL TEST ONLY | $Model | $([int]$timer.Elapsed.TotalSeconds)s"
  Write-Output $reply.message.content
} finally { $http.Dispose() }
