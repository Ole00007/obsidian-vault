# Scelta di installazione / Deployment decision / Выбор установки

**24.11.2026 · Studio / office / бюро:** _____  **Referente IT / IT owner / ИТ:** _____

| Domanda / Question / Вопрос | Sì / Yes / Да | No / Нет |
|---|---|---|
| Build Elisa verificata sullo stesso sistema? / Rehearsed the release on a comparable OS? / Сборка проверена на похожем ПК? | ↓ | Solo dimostrazione, non installare / demo only / без установки |
| Il modello locale supera la prova nei tempi dello studio? / Does the local model meet office time and quality targets? / Локальная модель справляется по качеству и времени? | Elisa + local LLM | Server dello studio approvato / approved office server / проверенный сервер бюро |
| Manca ancora capacità e lo studio approva un fornitore esterno? / Capacity still lacking and cloud approved? / Всё ещё не хватает мощности, а облако согласовано? | Test separato, dati inventati, limite di spesa / separate capped synthetic trial / отдельная проба с лимитом | Fermarsi / stop / остановиться |
| La bozza diretta funziona ma richiede passaggi ripetitivi? / Direct draft passes but repeated steps remain? / Черновик принят, остались повторяющиеся шаги? | Valutare un agente Hermes / trial one Hermes agent / испытать одного агента | Nessun agente / no agent / агент не нужен |
| Più studi paganti chiedono Grok? / Multiple paying offices request Grok? / Несколько платящих бюро просят Grok? | Confronto su casi sintetici e margine / benchmark and margin / сравнить качество и экономику | Rinviare / defer / отложить |

**Before testing / Prima della prova / До теста:** agree maximum review-inclusive minutes ____; number of substantive factual or attribution errors permitted **0**; unauthorised disclosures or external actions permitted **0**. Record the result in the [scorecard](scorecard.md). This form authorises no purchases or external processing.

## Messaggio da inviare prima della visita / Pre-visit message / Сообщение до встречи

**IT:** «Buongiorno Avvocato, per martedì 24 novembre propongo una prova di 45 minuti: da tre documenti inventati a una cronologia verificabile, nel Suo formato. Non occorrono un abbonamento Grok né atti dei clienti. Potrebbe indicarmi versione di Windows, RAM, eventuale modello già in uso e chi può autorizzare l’installazione? Se il PC è gestito, possiamo coinvolgere il referente IT. Decideremo insieme se il risultato giustifica un pilota su un Suo flusso di lavoro.»

**EN:** “For Tuesday 24 November I suggest a 45-minute test: turn three fictional records into a verifiable chronology in your format. No Grok subscription or client documents needed. What Windows version, RAM and existing model do you use, and who can authorise installation? We can involve your IT contact and decide together whether the result merits a pilot.”

**RU:** «На вторник, 24 ноября, предлагаю 45-минутную проверку: составим по трём вымышленным документам хронологию в Вашем формате. Подписка Grok и материалы клиентов не нужны. Подскажите версию Windows, объём памяти, используемую модель и кто согласует установку. При необходимости пригласим Вашего ИТ-специалиста и вместе решим, стоит ли переходить к пилоту».
