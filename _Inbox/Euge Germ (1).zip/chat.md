# WhatsApp Chat Export: Euge Germ
Export date: November 5, 2026 at 4:39 PM

---

## October 22, 2025

[11:22 AM] **Euge Germ:** You want a divorce; i will not stop you. My lawyer is waiting

[11:22 AM] **You:** And that I still have a word SOMEWHERE

[11:22 AM] **Euge Germ:** I make the effort; you don't

[11:22 AM] **You:**
> _Euge Germ: You want a divorce; i will not stop you. My lawyer is waiting_
i didn't say this

[11:22 AM] **You:** But you do whatever you want

[11:23 AM] **Euge Germ:**
> _You: And that I still have a word SOMEWHERE_
Of course, in everything

[11:23 AM] **You:** I don't need a lawyer

[11:23 AM] **You:** But go ahead through your money away

[11:23 AM] **You:** I don't have this luxury

[11:23 AM] **You:** So use it

[11:23 AM] **You:** Hurry up

[11:24 AM] **You:** I also don't see the need

[11:24 AM] **Euge Germ:** I make the effort; i try, but yes, i also firget things; but you really need to get so angry all tge time??

[11:24 AM] **Euge Germ:**
> _You: I don't have this luxury_
I will pay for it

[11:24 AM] **You:** Though.. come tonthink of this..Perhaps it's better indeed to talk to your lawyer then to you

[11:24 AM] **You:** He will need to SEE mE

[11:24 AM] **You:** And HEAR ME OIT

[11:24 AM] **You:** ilunlike yourself

[11:25 AM] **Euge Germ:**
> _You: I also don't see the need_
You want a divorce; you need a lawyer to do the paperwork

[11:25 AM] **You:** Stop

[11:25 AM] **You:** No more clean chats

[11:25 AM] **You:** I just said i take care of Mika today

[11:25 AM] **You:** That's  all

[11:26 AM] **Euge Germ:**
> _You: And HEAR ME OIT_
He represents me, not you. For a divorce you need lawyers. I will pay even your lawyer.

[11:27 AM] **You:**
> _Euge Germ: He represents me, not you. For a divorce you need lawyers. I will pay even your lawyer._
So will you give him instructions to ignore me 🤣

[11:27 AM] **You:** Whatever

[11:27 AM] **Euge Germ:** You don't want to try, you have no feelings left, just anger. You told me more than 50 times the last 1,5 years that you want a divorce. Fine; put it in process then.

[11:27 AM] **You:** Will be difficult to find such a dummy though))

[11:27 AM] **You:** But hey

[11:28 AM] **You:** If you really want something

[11:28 AM] **You:** Would have been easier and cheaper just to try to  treat me with a bit of respect

[11:28 AM] **Euge Germ:**
> _You: So will you give him instructions to ignore me 🤣_
He will work with your lawyer for the paperwork; it should be 2 months

[11:29 AM] **You:** Not to ant as if Was ALREADY OUT OF YOUR SPPARTMENT

[11:29 AM] **You:** For what "YOU PAY"

[11:29 AM] **Euge Germ:**
> _You: Would have been easier and cheaper just to try to  treat me with a bit of respect_
I don't treat you with respect because of these little things?? What about treating me with respect?

[11:29 AM] **You:** But go ahead

[11:29 AM] **You:** Send me a lawyer

[11:30 AM] **You:** Send me a lawyer

[11:30 AM] **Euge Germ:** I already send you his email

[11:30 AM] **Euge Germ:** You want a divorce; now you have my lawyers contact; go ahead; i will sign the docs

[11:32 AM] **You:** Really..))

[11:32 AM] **You:** I don't expect but I ask you gently and politely to inform me

[11:33 AM] **Euge Germ:**
> _You: Really..))_
Yes, really

[11:33 AM] **You:** When and how I will be contacted by "Your lawyer")

[11:34 AM] **Euge Germ:** You want a divorce, so you put it in motion. But i will pay all costs involved,

[11:35 AM] **Euge Germ:** You want the divorce, not me, i want to work things out, but i will not further try to convince you anymore.

[11:37 AM] **Euge Germ:** You told me more than 25 times the last 1,5 years that you want to divorce; verbally, by messages and during the recorded therapy sessions.

[11:39 AM] **Euge Germ:** So now you have the contact of my lawer; your lawyer should contact him and they file the paperwork; thats it

[3:46 PM] **Euge Germ:** [Document] Here is our wedding certificate; you only need to get a lawyer in moscow, tell him to file for divorce and send the bill to me.

[3:49 PM] **Euge Germ:** So no more need to be angry with me all the time; in 2 months we can be officially divorced and we never have to see each other again. But its your choice, not mine

---

## November 5, 2025

[4:40 AM] **Euge Germ:** In any case, in any event, your conclusion is that you don't want to be together anymore; why don't you then put the divorce in motion?
