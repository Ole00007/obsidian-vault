# BROGLIACCIO DELLA PARTE IN FATTO — NUCLEO FAMILIARE RASING

**Bozza v4 — non ancora approvata dalla cliente. Da verificare punto per punto prima di ogni uso esterno o processuale.**

---

## 1. Premessa

Come indicato dall'Avv., questo documento costituisce il brogliaccio della parte in fatto relativo alla causa in oggetto: una ricostruzione degli accadimenti, punto per punto, nella lingua e nella forma più utili a chi non ha vissuto direttamente le circostanze né dispone della memoria storica della cliente. Dove non vi è prova documentale immediatamente disponibile, la circostanza viene comunque annotata, in vista di un'eventuale successiva indicazione di testimoni sulle circostanze che realmente interessano alla causa.

## 2. Composizione del nucleo familiare

- **Olesia Rasing**, madre e parte istante, nata il 28/06/1982, residente in Via Quarnaro n. 4, interno 5, 16145 Genova.
- **Eugene Theodorus Wilhelmus Rasing**, coniuge, nato a Tiel (Paesi Bassi) il 01/01/1971.
- **Daniella Eugenevna Rasing**, figlia, nata a Mosca il 03/12/2013.
- **Emil Eugenevich Rasing**, figlio, nato a Mosca il 29/01/2016.

## 3. Residenza precedente al trasferimento in Italia — Mosca

Dal matrimonio, celebrato il 28 luglio 2010, il nucleo ha risieduto nel centro storico di Mosca: prima in Rochdel'skaja ul., 5 (nei pressi della sede del Governo della Federazione Russa, vista sul fiume Moscova), poi in Baumanskaja ul., sempre nel centro storico.

## 4. Cronologia delle residenze in Italia

| Periodo | Località | Indirizzo / descrizione |
|---|---|---|
| 28/07/2010 – agosto 2017 | Mosca | v. §3 |
| Agosto 2017 – settembre 2019 | Firenze | Via di Pietra Tacca, n. 2 — villa indipendente, ~430 mq, ~1,5 ha di giardino/uliveto |
| Settembre 2019 – gennaio 2023 | Lerici (SP) | Quota di villa bifamiliare, giardino privato, posto auto, vista Golfo dei Poeti, zona "Bella Vista", Loc. Catene |
| Gennaio 2023 – oggi | Genova | Via Quarnaro n. 4, int. 5, 16145 Genova — appartamento di ~145 mq in palazzo, zona Albaro, vista mare su Corso Italia |

## 5. Tenore di vita — dettaglio per periodo

### 5.1 Firenze (agosto 2017 – settembre 2019)

| Voce di spesa | Importo mensile | Note |
|---|---|---|
| Affitto | €4.500 | Dichiarato |
| Giardiniere (1x/settimana) | €346–433 | Stima su €80–100/intervento |
| Collaboratrice domestica | €260–433 | Frequenza da confermare |
| Sicurezza e manutenzione strada privata | €800 | Dichiarato |
| Utenze (incl. riscaldamento a gasolio) | €900 (media) | Dichiarato |
| Tata per il figlio minore | €800 | Dichiarato, presente in questo periodo |
| Scuola materna privata (figlia) | €650 | Dichiarato |
| Spesa alimentare | €2.700–3.400 | Rideterminato dalla cliente |
| Spesa vestiario | €700–1.000 | Dichiarato |
| **Totale mensile stimato** | **€11.656 – €12.916** | Escl. viaggi, ristorazione, attività culturali |

### 5.2 Lerici (settembre 2019 – gennaio 2023)

| Voce di spesa | Importo mensile | Note |
|---|---|---|
| Affitto | €1.900 | Dichiarato |
| Giardiniere (1x ogni 3–4 settimane) | €87–115 | Stima su €80/intervento |
| Collaboratrice domestica (€50–60/volta) | €216–260 | Frequenza da confermare |
| Sicurezza e manutenzione strada privata | €0 | Dichiarato |
| Utenze | €400 (media) | Dichiarato |
| Tata per il figlio minore | €0 | Confermato: non più presente in questo periodo |
| Scuola materna pubblica (mensa) | €220 | Da confermare se riferito a un figlio o entrambi |
| Spesa alimentare | €2.700–3.400 | Rideterminato dalla cliente |
| Spesa vestiario | €500–600 | Dichiarato |
| Affitto magazzino (mobili residui casa fiorentina) | €500 | Dichiarato |
| Attività dei figli (calcio, danza, centri estivi: €2.350/anno; più quota settimanale €17) | €269 | Importi annuali ripartiti su 12 mesi + quota settimanale — interpretazione da confermare con la cliente |
| **Totale mensile stimato** | **€6.792 – €7.664** | Escl. viaggi, ristorazione |

### 5.3 Genova (gennaio 2023 – oggi)

| Voce di spesa | Importo mensile | Note |
|---|---|---|
| Affitto (appartamento ~145 mq, palazzo, zona Albaro, vista mare, Corso Italia) | €1.450 | Descrizione corretta dalla cliente; importo da riconfermare |
| Giardiniere | €0 | Non applicabile — appartamento in condominio (da confermare) |
| Collaboratrice domestica (€50–60/volta) | €216–260 | Frequenza da confermare |
| Sicurezza e manutenzione strada privata | €0 | Non applicabile — condominio urbano |
| Utenze | €400 (media) | Dichiarato |
| Tata per il figlio minore | €0 | Confermato: non più presente |
| Scuola materna pubblica (mensa, due figli) | €220–260 | Dichiarato |
| Spesa alimentare | €2.500–2.700 | Corretto dalla cliente |
| Spesa vestiario | €500–600 | Dichiarato |
| Affitto magazzino | €0 | Confermato: azzerato a Genova |
| Attività dei figli (calcio, danza, centri estivi: €2.350/anno; più quota settimanale €17) | €269 | Stessa interpretazione di cui al §5.2 — da confermare |
| **Totale mensile stimato** | **€5.555 – €5.939** | Escl. viaggi, ristorazione |

### 5.4 Beni mobili registrati (autovetture)

- **Lerici**: Eugene Rasing — BMW X5; Olesia Rasing — Mercedes Classe C.
- **Genova**: sostituite con nuova BMW X5 e Alfa Romeo Junior.

## 6. Vicende professionali della sig.ra Olesia Rasing e loro incidenza sulla vita familiare

La sig.ra Rasing era titolare di un'attività di vendita al dettaglio di abbigliamento, costituita come società a responsabilità limitata di diritto russo (OOO), fondata e costruita personalmente sino a raggiungere un fatturato annuo di circa €1,5 milioni, con 8 punti vendita fisici. La società era stata costituita nel 2010.

Nel primo anno successivo al trasferimento a Firenze, oltre alle esigenze legate al regime dei visti (soglia 180/180 giorni), la cliente continuava a fare la spola tra Firenze e Mosca per gestire personalmente l'attività. A partire dal **2018**, la cliente ha progressivamente ridotto la frequenza dei propri spostamenti; ha successivamente ottenuto, nel corso del **2019–2020**, il permesso di soggiorno per motivi di ricongiungimento familiare, cessando integralmente i viaggi internazionali a partire dal **2020**.

Con il tempo, la conciliazione tra impegni professionali e vita familiare è divenuta insostenibile: la sig.ra Rasing sentiva fortemente la lontananza dai figli, mentre il coniuge incontrava difficoltà nella gestione della casa e dei bambini, ancora molto piccoli, anche in presenza della tata — difficoltà che si aggravavano ulteriormente nei periodi in cui quest'ultima non era disponibile.

Dopo un anno di spostamenti continui, la cliente ha deciso di chiudere la parte più consistente dei punti vendita, per non doversi più allontanare frequentemente dalla famiglia. Ha mantenuto per un periodo un'attività residuale (2 punti vendita), non essendo però un'attività di tali dimensioni sostenibile senza la presenza costante della fondatrice.

In seguito, la figlia Daniella è stata ricoverata in ospedale per una patologia con pericolo per la vita; la cliente si è dedicata a tempo pieno alla figlia, ciò che ha determinato l'abbandono definitivo delle ultime attività professionali residue. La società è stata formalmente chiusa e cancellata dal registro delle imprese nel 2022 **[documentazione a supporto: visura camerale russa attestante la cancellazione — da allegare, con denominazione e numero di iscrizione OOO da integrare]**.

Sintesi del percorso: costituzione nel 2010; trasferimento della famiglia in Italia nel 2017; riduzione progressiva dei viaggi dal 2018; permesso di soggiorno per ricongiungimento familiare ottenuto nel 2019–2020; cessazione dei viaggi internazionali nel 2020; attività ridotta al minimo operativo nel 2021; cessazione formale e cancellazione dal registro nel 2022.

La cliente precisa che tale rinuncia è stata dettata dalla consapevolezza che una piccola impresa, priva del supporto di investitori esterni e di una struttura manageriale solida, non può proseguire la propria crescita in assenza della presenza diretta della titolare — ragione per cui, in origine, la stessa non era favorevole al trasferimento in Italia.

## 7. Trasferimento dei risparmi e situazione economica della cliente

A seguito della chiusura dell'attività, la cliente ha trasferito i propri risparmi dalla Federazione Russa con notevoli difficoltà operative, incluso il ricorso a canali basati su criptovalute, non essendovi, al momento, alternative praticabili a causa del blocco delle transazioni SWIFT tra Russia ed Europa. Di tali risparmi la cliente si è sostenuta per un consistente periodo, senza mai richiedere un contributo economico al coniuge.

## 8. Squilibrio nelle spese personali dei coniugi

Si segnala, ai fini della ricostruzione delle circostanze economiche rilevanti per la causa, il seguente divario tra le spese personali del coniuge e l'onere sostenuto dalla cliente per le necessità correnti della famiglia:

**Spese personali del sig. Eugene Rasing** (a titolo esemplificativo, secondo quanto riferito dalla cliente):
- acquisto di una nuova BMW X5 (valore stimato €100.000–120.000), in sostituzione di un veicolo che la cliente stessa gli aveva donato a Mosca per il suo compleanno;
- acquisto di un orologio IWC (valore stimato €22.000–23.000);
- viaggi in hotel e ristoranti di fascia alta/lusso, sostenuti autonomamente dal coniuge.

**Oneri sostenuti dalla cliente**, con i propri risparmi personali, per le necessità correnti del nucleo:
- spese fondamentali quotidiane (alimentazione, vestiario, utenze — v. tabelle §5);
- partecipazione dei figli a torneo/attività sportive, incluso l'accompagnamento in diverse città italiane per tornei e competizioni;
- costi relativi a eventi scolastici e delle società sportive dei figli.

La cliente, nel medesimo periodo, ha continuato a utilizzare una vecchia Mercedes, progressivamente deteriorata per l'uso intenso — dovuto anche ai lunghi spostamenti familiari e all'utilizzo, da parte del sig. Rasing, del medesimo veicolo (non a lui formalmente assegnato) per il trasporto di strumenti connessi alla propria attività professionale in Europa.

## 9. Tentativo di terapia di coppia e relativo esito

La coppia ha intrapreso un percorso di terapia familiare. Secondo quanto riferito dalla cliente, il coniuge ha successivamente manifestato la volontà di interrompere il percorso, imputando alla terapeuta un ruolo nell'aver rafforzato, a suo dire, la determinazione della cliente verso la separazione. La cliente riferisce che tale convincimento si è progressivamente consolidato proprio a fronte della condotta assunta dal coniuge durante le sedute, connotata da atteggiamenti aggressivi anche in presenza della terapeuta, sino a un episodio in cui il coniuge ha abbandonato bruscamente la seduta. La terapeuta ha, in tale contesto, confermato la natura di crudeltà della condotta osservata.

Il percorso terapeutico non ha condotto, in ogni caso, a risultati significativi, permanendo — secondo quanto riferito dalla cliente — una scarsa disponibilità di supporto morale ed economico da parte del coniuge, a fronte di reiterate osservazioni critiche.

## 10. Richieste al Giudice

Avendo l'insoddisfazione reciproca raggiunto un livello non più sostenibile, la cliente dichiara l'impossibilità di prosecuzione della convivenza sotto lo stesso tetto e chiede che il Giudice disponga:

1. il collocamento dei figli minori presso la madre, con diritto di frequentazione del padre secondo le modalità ordinariamente previste, senza ostacoli da parte della madre;
2. un contributo economico da parte del coniuge, non essendo la cliente attualmente in condizione di sostenere autonomamente l'intero costo della vita corrente propria e dei figli, al fine di mantenere un livello di vita adeguato e permettere ai minori di continuare le proprie attività sociali e sportive, con relativo accompagnamento da parte della madre.

## 11. Conclusioni

La situazione di conflittualità tra i coniugi, unitamente alla progressiva insostenibilità per la ricorrente, ha reso impossibile la prosecuzione della convivenza sotto lo stesso tetto.

Quanto sopra costituisce ricostruzione, punto per punto, degli accadimenti rilevanti per la causa in corso. Restano da confermare con la cliente le circostanze e gli importi segnalati nelle tabelle di cui al §5, in particolare l'importo del canone di Genova e l'interpretazione delle voci relative alle attività dei figli.

**P.S.** Il certificati storici di residenza del nucleo familiare Rasing verranno allegati non appena disponibili, essendo stati richiesti all'Uffici Anagrafe del Comune di Genova, Commune di Lerici e Commune di Firenze con rilascio atteso indicativamente in data 26 settembre 2026. Qualora fosse necessario produrre ulteriore documentazione, si prega di darne cortese comunicazione.

Con osservanza.

---
*Brogliaccio v4. Necessita approvazione finale della cliente prima di ogni uso esterno o processuale. Dati aziendali, sanitari e personali riportati su base dichiarativa della cliente; da corroborare con documentazione (visura camerale russa, cartella clinica, estratti conto/wallet crypto, dichiarazione della terapeuta, se pertinenti e producibili).*
