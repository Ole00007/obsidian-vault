**BOZZA — NON DEFINITIVA. DA SOTTOPORRE A REVISIONE E SOTTOSCRIZIONE DELL'AVV. PRIMA DEL DEPOSITO.**

---

# TRIBUNALE ORDINARIO DI GENOVA
## Sezione Famiglia, Persone e Minori

# RICORSO PER SEPARAZIONE GIUDIZIALE DEI CONIUGI
### (artt. 150 e ss. c.c.; artt. 337-bis e ss. c.c.; artt. 706 e ss. c.p.c.)

**Per**: Olesia Rasing, nata il 28/06/1982, C.F. RSNLSO82H68Z154D, residente in Genova, Via Quarnaro n. 4, interno 5, 16145 Genova, rappresentata e difesa dall'Avv. **[nome, foro di appartenenza e C.F./P.IVA da inserire]**, giusta procura in atti, presso il cui studio in **[indirizzo studio]** elegge domicilio, PEC **[da inserire]**, fax/email **[da inserire]**;

**RICORRENTE**

### CONTRO

Eugene Theodorus Wilhelmus Rasing, nato a Tiel (Regno dei Paesi Bassi) il 01/01/1971, residente in **[indirizzo del resistente — da confermare, presumibilmente Via Quarnaro n. 4, int. 5, 16145 Genova, salvo diversa residenza attuale]**;

**RESISTENTE**

---

## PREMESSO IN FATTO

1. I coniugi Olesia Rasing e Eugene Rasing hanno contratto matrimonio in data 28 luglio 2010, stabilendo la propria residenza familiare nel centro storico di Mosca (Federazione Russa), in Rochdel'skaja ul. n. 5 e, successivamente, in Baumanskaja ul., sempre nel centro storico della capitale.

2. Dal matrimonio sono nati due figli, entrambi minori: Daniella Eugenevna Rasing, nata a Mosca il 03/12/2013, e Emil Eugenevich Rasing, nato a Mosca il 29/01/2016.

3. Nel mese di agosto 2017 il nucleo familiare si è trasferito in Italia, stabilendo la propria residenza a Firenze, in Via di Pietra Tacca n. 2, in una villa indipendente di circa 430 mq con giardino e uliveto di circa 1,5 ettari.

4. Nel corso del primo anno successivo al trasferimento, la ricorrente ha mantenuto la gestione della propria attività commerciale in Russia (società a responsabilità limitata — OOO — attiva nella vendita al dettaglio di articoli di abbigliamento, con 8 punti vendita e fatturato annuo di circa €1,5 milioni), effettuando spostamenti reiterati tra l'Italia e la Federazione Russa entro la soglia di permanenza consentita (regola dei 180/180 giorni), essendo titolare di visto di lungo periodo. A partire dal **2018** la ricorrente ha progressivamente ridotto la frequenza di tali spostamenti; ha successivamente ottenuto, nel corso del **2019–2020**, il permesso di soggiorno per motivi di ricongiungimento familiare, cessando integralmente i viaggi internazionali a partire dal **2020**.

5. Le difficoltà di conciliazione tra l'attività professionale della ricorrente e le esigenze della famiglia, unitamente alla tenera età dei minori, hanno condotto la ricorrente, dopo circa un anno, a cessare la parte più consistente della propria attività commerciale, mantenendo per un periodo limitato un'attività residuale, sino alla cessazione definitiva e cancellazione della società dal registro delle imprese russo nel corso del 2022 **[da allegare: visura camerale russa attestante la cancellazione]**, anche a seguito del ricovero ospedaliero della figlia Daniella per patologia con pericolo per la vita, che ha assorbito integralmente le energie della ricorrente.

6. In data settembre 2019 il nucleo familiare si è trasferito a Lerici (SP), presso una quota di villa bifamiliare con giardino privato e posto auto, in zona "Bella Vista", Località Catene, ove ha risieduto sino al gennaio 2023.

7. Dal gennaio 2023 il nucleo familiare risiede in Genova, Via Quarnaro n. 4, interno 5, in un appartamento di circa 145 mq, zona Albaro, con vista mare su Corso Italia.

8. Durante l'intero periodo di permanenza in Italia, la ricorrente si è pressoché integralmente dedicata alla cura dei figli e alla gestione della casa, mentre il resistente ha proseguito la propria attività lavorativa con frequenti spostamenti. La ricorrente ha sostenuto, con i propri risparmi personali — trasferiti dalla Russia con significative difficoltà operative, incluso il ricorso a canali basati su criptovalute in ragione del blocco delle transazioni SWIFT tra Russia ed Europa — le spese correnti relative all'alimentazione, al vestiario, alle utenze, alle attività scolastiche e sportive dei figli, incluso l'accompagnamento a torneo e manifestazioni in diverse città italiane, senza mai richiedere un contributo economico al resistente, che ha provveduto al pagamento del canone di locazione delle abitazioni via via occupate dal nucleo.

9. Nel medesimo periodo, il resistente ha sostenuto spese personali di rilevante importo, quali l'acquisto di un'autovettura BMW X5 (valore stimato €100.000–120.000) e di un orologio IWC (valore stimato €22.000–23.000), oltre a soggiorni in strutture alberghiere e ristoranti di fascia alta, mentre la ricorrente ha continuato a utilizzare un'autovettura Mercedes usata, progressivamente deteriorata anche a causa dell'utilizzo, da parte del resistente, per il trasporto di strumenti connessi alla propria attività professionale in Europa.

10. La coppia ha tentato un percorso di terapia familiare, interrotto per volontà del resistente, il quale ha assunto, secondo quanto emerso nel corso delle sedute, una condotta connotata da aggressività, sino ad abbandonare bruscamente una seduta; la terapeuta ha confermato, in tale contesto, la natura di crudeltà della condotta osservata.

11. La situazione di conflittualità tra i coniugi, unitamente alla progressiva insostenibilità per la ricorrente, ha reso impossibile la prosecuzione della convivenza sotto lo stesso tetto.

## RITENUTO IN DIRITTO

Che, ai sensi dell'art. 151 c.c., la separazione può essere richiesta quando si verificano fatti tali da rendere intollerabile la prosecuzione della convivenza; che, nella specie, tale intollerabilità è comprovata dalle circostanze sopra esposte;

che, ai sensi degli artt. 337-bis e ss. c.c., l'affidamento dei figli minori deve essere deciso nel loro esclusivo interesse, avuto riguardo alla circostanza che la ricorrente si è costantemente occupata della cura quotidiana dei minori;

che, ai sensi dell'art. 337-ter c.c., i genitori sono tenuti a provvedere al mantenimento dei figli in misura proporzionale al proprio reddito, tenuto conto delle esigenze del minore, del tenore di vita goduto in costanza di convivenza e dei tempi di permanenza presso ciascun genitore;

**[da valutare con l'Avv.: eventuale richiesta di addebito della separazione ex art. 151, comma 2, c.c., alla luce delle circostanze di cui al punto 10 che precede]**;

## PER TALI MOTIVI

la ricorrente, come sopra rappresentata e difesa, chiede che l'Ill.mo Tribunale di Genova, Sezione Famiglia, Persone e Minori, voglia:

1. dichiarare la separazione personale dei coniugi Olesia Rasing e Eugene Theodorus Wilhelmus Rasing;
2. disporre l'affidamento condiviso dei figli minori Daniella Eugenevna Rasing e Emil Eugenevich Rasing, con collocamento prevalente presso la madre e diritto di frequentazione del padre secondo le modalità ordinariamente previste dalla prassi del Tribunale, senza ostacoli da parte della ricorrente;
3. determinare, a carico del resistente, un assegno di mantenimento per i figli minori e, occorrendo, per la ricorrente, in misura da quantificarsi anche tenuto conto del tenore di vita goduto dal nucleo in costanza di convivenza, come documentato nella memoria allegata;
4. **[eventualmente]** pronunciare l'addebito della separazione a carico del resistente, ove ritenuto dall'Avv. opportuno e sostenibile in base alla documentazione producibile;
5. assegnare la casa familiare alla ricorrente, in quanto genitore collocatario dei figli minori;
6. disporre quant'altro di giustizia.

## SI PRODUCE

- Certificato di matrimonio;
- Certificati di nascita dei figli minori;
- Certificati storici di residenza relativi ai Comuni di Firenze, Lerici e Genova **[in corso di rilascio — attesi indicativamente il 26 settembre 2026]**;
- Memoria di parte in fatto (brogliaccio) con cronologia delle residenze e tenore di vita del nucleo familiare;
- **[da integrare]**: visura camerale russa attestante la cancellazione della società (OOO);
- **[da integrare]**: documentazione medica relativa al ricovero della figlia Daniella;
- **[da integrare]**: archivio messaggi vocali/testuali WhatsApp relativo alla vicenda della terapia familiare, disponibile su richiesta, qualora se ne ravvisi l'assoluta necessità; eventuale dichiarazione della terapeuta, se e quando producibile;
- **[da integrare]**: documentazione reddituale della ricorrente e, del resistente, quella disponibile.

Si dichiara, ai sensi di legge, il valore della causa **[da determinare con l'Avv.]**.

Genova, **[data da inserire]**

Avv. **[nome e firma]**

---

*Documento predisposto in forma di bozza sulla base delle informazioni fornite dalla cliente. Necessita di revisione legale integrale, verifica della competenza territoriale, completamento dei dati anagrafici e procedurali mancanti, e sottoscrizione da parte del difensore prima del deposito presso la Cancelleria del Tribunale di Genova.*
