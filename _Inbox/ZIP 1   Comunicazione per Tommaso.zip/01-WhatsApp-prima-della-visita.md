# Messaggio per Tommaso

Ciao Tommaso! Martedì ti va di fare una prova di dieci minuti? Quando trovi su One LEGALE x Libra un punto utile, come arriva a chi ti assiste sulla pratica? Se c’è qualcosa che vi tocca riscrivere, provo a farvi saltare quel passaggio con Elisa e LexFlow.

Porto io un esempio inventato su privacy o 231. Niente documenti dei clienti, niente accesso ai vostri account e nessuna mail da inviare. Mi basta una riga, anche un vocale. A martedì!
