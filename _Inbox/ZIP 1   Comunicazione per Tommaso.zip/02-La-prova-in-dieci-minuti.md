# Dalla ricerca alla pratica | La prova in dieci minuti

**Il punto di partenza.** «Tommaso, continui a lavorare su One LEGALE x Libra o Lexroom come fai oggi. A noi interessa il momento dopo: quando hai scelto il passaggio utile, chi deve riportarlo nella pratica o spiegare al collega cosa fare?»

**Primi due minuti.** Basta raccontare l’ultimo passaggio, senza aprire il fascicolo. Se oggi il risultato è già nel posto giusto, visibile alla persona giusta e pronto per la verifica, non serve duplicarlo.

**Cinque minuti di prova.** Su una pratica inventata, scegliamo una breve nota con il suo riferimento. Proviamo a inserirla una sola volta in LexFlow e a ritrovarla nella stessa pratica, accanto alla richiesta che Elisa propone. Esempio: era stata chiesta una procedura firmata, ma fra gli allegati c’è solo una bozza. La richiesta corretta è «Ci puoi trasmettere la versione firmata?», non «L’azienda è inadempiente». Poi aggiungiamo la versione firmata: Elisa dovrebbe smettere di chiederla.

**Ultimi tre minuti.** Chi assiste l’avvocato ripete il passaggio; Tommaso controlla fonte, pratica e testo. La domanda finale: «Contando anche la rilettura, vi abbiamo tolto un passaggio o ve ne abbiamo aggiunto uno?»

## Risposte rapide

| Domanda | Risposta |
|---|---|
| Devo ancora copiare? | Una volta sì, oppure bastano un tuo appunto e il riferimento. L’obiettivo è non ricopiarli una seconda e una terza volta. |
| Elisa entra nella banca dati? | Non in questa prova. Nessuna password, nessun connettore agli account, nessun materiale dei clienti. |
| Chi sceglie la pratica? | La scegli tu o chi ti assiste; prima del salvataggio controllate il destinatario e il contenuto. |
| Viene inviata una richiesta? | No. Per la prova la posta resta scollegata: si prepara solo una bozza interna. |
| I dati del mio studio rimarrebbero sul PC? | Prima di usare dati veri verifichiamo insieme dove girano gestionale, modello, registri e backup. La dimostrazione usa solo testi inventati. |
| E se lo faccio già bene con i miei strumenti? | Mantieni il tuo metodo. Ha senso continuare solo se la prova fa emergere un vantaggio concreto. |
