# Istruzioni — pacchetto Olesia Rasing

## Contenuto
- 6 notule pro forma PF-01/2026–PF-06/2026: inviare prima del pagamento.
- 6 ricevute R-01/2026–R-06/2026: completare e firmare soltanto dopo ciascun accredito.

## Totali
- Compenso lordo complessivo: € 2.900,00.
- Ritenuta d’acconto complessiva: € 580,00.
- Bonifici complessivi immediati: € 2.320,00.
- Bolli: 6 × € 2,00 = € 12,00, indicati a carico della prestatrice.

## Sequenza
1. Inserire nella notula PF la data di invio e mandarla al committente.
2. Il committente trattiene il 20% e versa il netto.
3. Verificare l’accredito.
4. Compilare la corrispondente ricevuta R con data di incasso, applicare il bollo e firmare.
5. Inviare la ricevuta al committente e conservarne copia/scansione.

## Nota sul nome
È stato scelto “Notula pro forma per prestazione di lavoro autonomo occasionale — documento non fiscale”. “Notula” è usato anche in documenti di enti e ordini professionali liguri; la dicitura pro forma evita che il documento venga confuso con una quietanza.

## Avvertenza
I documenti assumono che i sei pagamenti siano fasi di un unico incarico occasionale e che non vi siano altre ricevute 2026 con numerazione confliggente. Verificare i dati societari del committente prima dell’uso.
