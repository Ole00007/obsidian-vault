# Schema Comparison

## A. Hindsight bank isolation
| Option | Isolation | Cost/ops | Deletion | Leak risk | Verdict |
|---|---|---|---|---|---|
| Bank per workspace | strongest | 1 bank/tenant | drop bank | lowest | USE at M3 |
| Shared bank + workspace tag filter | logical only | cheapest | per-record delete | filter bug = leak | avoid |
| Bank per client-of-tenant | very strong | high ops | easy | low | only if law-firm demands |
| None (Obsidian only) | folder + RLS index | zero | tombstone | low (single tenant) | NOW |

## B. Source ID tracking in Obsidian
| Option | Pros | Cons | Verdict |
|---|---|---|---|
| Frontmatter only | simple, portable | no central query, drift | base layer |
| Registry file (md/csv) | easy audit | merge conflicts, PII risk in git | no |
| Postgres `memory_index` (+ frontmatter) | queryable, RLS, drives deletion | new table | USE (M1) |

## C. Retention
| Option | Pros | Cons | Verdict |
|---|---|---|---|
| Fixed cron age-based | simple | wrong for legal matters (clock should start at matter close) | no |
| Event-driven (matter.closed + period) | legally accurate | needs events | USE |
| Manual | safe | forgotten | fallback + legal hold |

Legal hold: any entity with `legal_hold=true` is exempt from purge.
