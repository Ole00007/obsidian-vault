# GDPR Opaque UUID Rule for GitHub (DRAFT - confirm with DPO/lawyer)
Why: git history is effectively permanent, so erasure requests cannot be honoured for data once pushed.

RULES
1. GitHub holds code, schemas, policies, templates ONLY.
2. Allowed identifiers: random UUIDv4 in format `lf:<workspace_id>:<entity>:<uuid4>`. IDs must have no derivation from personal data (no hashes of emails/names, no sequential IDs, no codice fiscale).
3. Forbidden in any repo, branch, PR, issue, commit message, CI log: names, emails, phones, addresses, case numbers, case titles, document text, client lists, screenshots with client data.
4. Fixtures/tests: synthetic data only (Faker); marked `synthetic: true`.
5. Vault folder `vault/` is git-ignored except `vault/_templates/`.
6. Mapping UUID <-> person exists ONLY in Postgres; deleting the DB row makes the UUID unlinkable (effective anonymisation).
7. Pre-commit + CI: gitleaks + PII regex scan; failure blocks push.
8. If PII is pushed: stop, notify owner, rotate/purge (git filter-repo + force push + contact GitHub support to purge caches), log incident, assess GDPR breach duty (72h to supervisory authority where applicable).
9. Review quarterly or on trigger T-TENANT2.

```bash
# .gitignore
vault/*
!vault/_templates/
.env*
*.pem
# pre-commit
pip install pre-commit && pre-commit install
gitleaks detect --source . --no-banner
```
