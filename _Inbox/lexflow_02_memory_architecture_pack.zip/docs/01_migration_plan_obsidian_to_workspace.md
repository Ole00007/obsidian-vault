# Obsidian -> Workspace Migration Plan
Principle: Postgres = SoR. Memory derived. Each phase starts on an EVENT, not a date.

| Phase | Trigger event | Action | Isolation | Rollback |
|---|---|---|---|---|
| M0 | now | Obsidian only. Add frontmatter (source_id, workspace_id, retention_class). Opaque UUID IDs | folder per workspace: vault/ws/<workspace_id>/ | git revert rules |
| M1 | P0 deployed | `memory_index` table (IDs, hashes, status) + RLS; `memory_gateway` w/ Obsidian backend | RLS on workspace_id | drop table (derived) |
| M2 | retention periods confirmed (D9) | Enable retention jobs from retention.yaml (dry-run 1 cycle first) | per-class | disable flag |
| M3 | 2nd tenant live data | Hindsight bank per workspace (`lf-<workspace_id>`); dual-write behind flag; backfill from Postgres (not from notes) | bank-per-tenant, keys per tenant | flag off, bank delete |
| M4 | tenant wants own agent | OAuth2+PKCE, MCP facade over service layer, scoped tokens | audience-bound tokens | revoke clients |

## Backfill rule
Rebuild memory from Postgres + source IDs. Never copy Obsidian -> Hindsight blindly (stale risk).

## Per-note migration steps
1. Assign `source_id` (lf:<ws>:<entity>:<uuid>) from DB row id mapping.
2. Strip PII from filenames/titles.
3. Set retention_class by entity type.
4. Register in memory_index (hash of body, derived_at).
5. Verify: source row exists; else mark `orphan` -> review.

## Tenant isolation checklist
- [ ] workspace_id on every ID/note/queue row/log
- [ ] RLS policies + FORCE ROW LEVEL SECURITY; app role without BYPASSRLS
- [ ] memory_gateway rejects cross-workspace source_ids
- [ ] separate Hindsight API key per bank (M3)
- [ ] test: tenant A token cannot read tenant B note/bank (CI)
