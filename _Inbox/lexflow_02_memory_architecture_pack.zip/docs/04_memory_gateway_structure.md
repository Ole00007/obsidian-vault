# memory_gateway structure
```
app/memory/
  __init__.py
  gateway.py        # single entry point; enforces workspace + source_id rules
  backends/
    base.py         # MemoryBackend Protocol
    obsidian.py     # M0/M1
    hindsight.py    # M3 (stub, flag-off)
  source_id.py      # parse/validate lf:<ws>:<entity>:<uuid4>
  sor.py            # fetch_authoritative(source_id) from Postgres
  retention.py      # reads retention.yaml, event-driven purge
  propagate.py      # deletion propagation worker + ledger
tests/memory/       # isolation + tombstone + stale tests
```
Rules: agents call ONLY `gateway`. Gateway: validates ID -> checks workspace == caller -> reads backend -> compares with SoR hash -> returns `stale=True` if changed. Reference code: code/memory_gateway.py
