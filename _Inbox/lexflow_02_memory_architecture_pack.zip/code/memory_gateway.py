"""memory_gateway: single entry point. Reference scaffold."""
import re, uuid, hashlib
from dataclasses import dataclass
from typing import Protocol, Optional

SID = re.compile(r"^lf:(?P<ws>[a-z0-9_-]+):(?P<entity>[a-z_]+):(?P<id>[0-9a-f-]{36})$")

class CrossWorkspaceError(PermissionError): ...
class BadSourceId(ValueError): ...

@dataclass
class Note:
    source_id: str
    body: str
    derived_at: str
    status: str = "active"   # active|stale|tombstoned
    stale: bool = False

class MemoryBackend(Protocol):
    def read(self, source_id: str) -> Optional[Note]: ...
    def write(self, note: Note) -> None: ...
    def tombstone(self, source_id: str, deleted_at: str) -> None: ...

def parse(source_id: str):
    m = SID.match(source_id)
    if not m: raise BadSourceId(source_id)
    uuid.UUID(m["id"], version=4)
    return m["ws"], m["entity"], m["id"]

def new_source_id(ws: str, entity: str) -> str:
    return f"lf:{ws}:{entity}:{uuid.uuid4()}"

def digest(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()

class MemoryGateway:
    def __init__(self, backend: MemoryBackend, sor_fetch, workspace_id: str):
        self.b, self.sor, self.ws = backend, sor_fetch, workspace_id

    def _guard(self, source_id):
        ws, _, _ = parse(source_id)
        if ws != self.ws: raise CrossWorkspaceError(source_id)

    def recall(self, source_id: str) -> Optional[Note]:
        self._guard(source_id)
        note = self.b.read(source_id)
        if not note or note.status == "tombstoned": return None
        truth = self.sor(source_id)        # Postgres via workspace-scoped API; None if deleted
        if truth is None:
            self.b.tombstone(source_id, "now"); return None
        note.stale = digest(truth["summary_input"]) != digest(note.body) if "summary_input" in truth else False
        return note

    def remember(self, note: Note) -> None:
        self._guard(note.source_id)
        if self.sor(note.source_id) is None:
            raise LookupError("no SoR row; memory cannot create facts")
        self.b.write(note)

    def forget(self, source_id: str, deleted_at: str) -> None:
        self._guard(source_id)
        self.b.tombstone(source_id, deleted_at)
