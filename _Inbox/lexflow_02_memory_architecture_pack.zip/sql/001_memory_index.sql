-- STAGING FIRST
CREATE TABLE memory_index (
  source_id text PRIMARY KEY,
  workspace_id uuid NOT NULL,
  entity text NOT NULL,
  body_sha256 text,
  derived_at timestamptz NOT NULL,
  source_updated_at timestamptz,
  retention_class text NOT NULL CHECK (retention_class IN ('R1','R2','R3','R4')),
  legal_hold boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','stale','tombstoned','orphan'))
);
CREATE TABLE deletion_ledger (
  id bigserial PRIMARY KEY,
  source_id text NOT NULL,
  workspace_id uuid NOT NULL,
  deleted_at timestamptz NOT NULL DEFAULT now(),
  targets jsonb NOT NULL,
  result text NOT NULL
);
ALTER TABLE memory_index ENABLE ROW LEVEL SECURITY;
ALTER TABLE memory_index FORCE ROW LEVEL SECURITY;
ALTER TABLE deletion_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE deletion_ledger FORCE ROW LEVEL SECURITY;
CREATE POLICY ws_isolation ON memory_index USING (workspace_id = current_setting('app.workspace_id')::uuid) WITH CHECK (workspace_id = current_setting('app.workspace_id')::uuid);
CREATE POLICY ws_isolation ON deletion_ledger USING (workspace_id = current_setting('app.workspace_id')::uuid) WITH CHECK (workspace_id = current_setting('app.workspace_id')::uuid);
