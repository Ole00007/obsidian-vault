PROMPT_ADMY.md and PROMPT_SMOOTHY.md are delivered as standalone files alongside this ZIP, not inside it. See README.md.
