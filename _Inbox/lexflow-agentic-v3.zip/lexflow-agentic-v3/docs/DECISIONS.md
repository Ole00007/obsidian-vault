# DECISIONS.md (v3.1, append-only)

ADR-001 to ADR-014 from prior revisions remain valid. New entries below.

## ADR-015 — Building agents formally certified as Cloudflare Workers experts
**Status:** Accepted
**Decision:** Admy, Smoothy, Backy, and Fronty each carry an explicit, distinct Cloudflare Workers expert specialization (platform/ops/backend/frontend-edge respectively) in addition to shared baseline Workers fluency.
**Reason:** User required best-expert-level Workers competence across all building agents, not generic familiarity.

## ADR-016 — Prompts must eliminate guessing
**Status:** Accepted
**Decision:** `PROMPT_ADMY.md` and `PROMPT_SMOOTHY.md` are rewritten with explicit definitions, step-by-step procedures, and mandatory escalation triggers so Hermes asks a precise question instead of assuming.
**Reason:** User explicitly required this to reduce ambiguity-driven errors.

## ADR-017 — Roadmap visuals delivered separately from the ZIP
**Status:** Accepted
**Decision:** Prompt markdown files and roadmap PNGs are delivered as standalone files in the response; the ZIP contains only the reference/registry documents and workbook.
**Reason:** User explicitly requested this separation for faster review.
