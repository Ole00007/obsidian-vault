# INTEROP_CONTRACTS.md — Additive, Non-Schema-Inventing Contracts

## Governing rule
No contract introduces a new entity, table, or field name. Replace `<TBD-audit>` only with a name confirmed in the live Flask codebase.

## API contract layer
Worker calls existing Flask endpoints. If a capability has no existing endpoint, Backy/Fronty propose a new **additive** Flask endpoint (same models, same conventions) — a Flask-side change proposal, not a schema invention — requiring Admy + Crunchy approval.

## Agent tool schema (grouped by business action)
- `<TBD-audit>.search` / `<TBD-audit>.get` — existing "person/entity" model lookups
- `intake.create` or equivalent existing flow — no new table
- `activity.log` — uses existing activity/audit mechanism, or is proposed as one additive table only after audit confirms none exists
- `case.propose_stage_change` — proposes a change to an existing status field, gated by approval

## Event schema (edge-only, not a CRM record)
```json
{
  "event_id": "uuid",
  "event_type": "lead.captured | activity.logged | cta.viewed | utm.attributed",
  "occurred_at": "iso8601",
  "existing_record_id": "<TBD-audit>",
  "producer": "worker-gateway",
  "payload_reference": "pointer only"
}
```

## CSV hand-off schema
CSV headers must match confirmed real Flask field names. Until audit, every CSV in this pack is a placeholder template only.

## Agent-specific touch points
- **Sally** — calls existing intake/activity endpoints via MCP; never writes directly to the database.
- **Daty** — reads existing attribution/activity events; uses edge KV/D1 for SEO-only experiment state, no new CRM fields.
- **Mr. Beast** — publishes content via site Worker/static assets; no CRM data touched.
- **Memo** — reads audit/event references for Obsidian/Hindsight sync; writes only to memory/audit stores.
