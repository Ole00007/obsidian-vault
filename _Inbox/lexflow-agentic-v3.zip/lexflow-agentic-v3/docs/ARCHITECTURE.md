# ARCHITECTURE.md (v3.1) — Additive Cloudflare Layer, Existing Database Unchanged

## Corrected data-ownership rule
LexFlow's existing Flask models and PostgreSQL tables are the only canonical schema. No generic CRM schema is proposed anywhere in this pack. Every field referenced must already exist in the live Flask models, confirmed by direct inspection.

## Target topology

```text
LexFlow website
      │
      ▼
Cloudflare Worker (Fronty builds the edge, Backy builds the gateway logic)
- validates requests (Turnstile, schema, rate limits)
- tracks attribution/activity (UTM, CTA events)
- protects public forms
- routes requests
- invokes approved Workflows
      │
      ▼
Existing LexFlow Flask API
- applies existing CRM permissions
- executes existing business rules
- reads/writes existing records — no schema change
      │
      ▼
Existing PostgreSQL database (Railway) — untouched
```

Agent access path:

```text
Any multifunctional agent (e.g., Sally, Daty, Backy)
      │
      ▼
Typed MCP/Worker tool (maps 1:1 to an existing API operation)
      │
      ▼
Cloudflare API gateway (auth, rate limit, schema validation)
      │
      ▼
Existing LexFlow Flask API (existing permission and business logic)
      │
      ▼
Existing PostgreSQL database — untouched
```

## Component responsibilities

| Component | Owns | Must not own | Built/operated by |
|---|---|---|---|
| Cloudflare Worker gateway | Validation, attribution capture, routing, rate limiting, Workflow triggering | Business rules already in Flask | Backy + Fronty, reviewed by Smoothy |
| Existing Flask API | All CRM business logic, permissions, canonical reads/writes | Duplicated edge logic | Backy (audits only, no rewrite) |
| Existing PostgreSQL | All CRM data as currently modeled | Any newly invented entity | Untouched |
| MCP tool layer | Narrow-but-not-too-narrow actions mapped to existing endpoints | Direct SQL, arbitrary HTTP | Backy, reviewed by Crunchy |
| Workflows | Durable multi-step jobs | Canonical storage | Backy/Smoothy |
| Queues | Event buffering | Long-term storage | Smoothy |
| KV | Cache, flags, CTA experiment buckets | Durable customer records | Fronty/Daty |
| D1 | Optional edge-only metadata | Canonical CRM records | Backy, only if approved |
| R2 | Documents referenced by ID | Public unscoped storage | Backy |

## Why all four building agents must be Cloudflare Workers experts, not generalists
LexFlow is one of several products this team will build. Admy, Smoothy, Backy, and Fronty are staffed as full Cloudflare Workers experts (see `AGENTS.md`) precisely so any of the four can pick up another's Worker code on any project without a learning curve, and so the team is never single-threaded on one Cloudflare specialist.

## Pre-contract verification checklist
- Actual Flask model definitions and field names (including the contacts / primary case clients / case participants split)
- Actual migrations history
- Actual API routes and serializers
- Actual permission/roles model
- Actual auth mechanism

Until this audit completes, every contract in `docs/INTEROP_CONTRACTS.md` uses `<TBD-audit>` placeholders.
