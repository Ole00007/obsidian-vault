# LexFlow Agentic Architecture v3.1 — Cloudflare-Expert Roster + Interoperability

**Status:** draft for approval, September 2026

## What changed in this revision (v3.1)

1. All four building agents (Admy, Smoothy, Backy, Fronty) now carry explicit **expert-level Cloudflare Workers specializations** (see `AGENTS.md` and `csv/agent_roster.csv`), while retaining full-stack, multi-project versatility.
2. The parallel roadmap is visually upgraded (`parallel_gantt_v2.png` and `roadmap_overview_v2.png`, delivered separately, not inside this ZIP).
3. `docs/PROMPT_ADMY.md` and `docs/PROMPT_SMOOTHY.md` are rewritten to be maximally explicit — Hermes should be able to execute or ask a precise clarifying question, never guess. These are delivered separately, not inside this ZIP.

## Still binding from v3

- No new CRM schema anywhere — every field is a placeholder pending audit of the real Flask models.
- No new agent identities — ten nicknames only, skills intentionally overlap.
- No deletion, rename, or destructive/production change without explicit approval.
- Building agents are Cloudflare-broad and full-stack, reusable across LexFlow and other current/future projects.

## Reading order

1. `AGENTS.md`
2. `docs/ARCHITECTURE.md`
3. `docs/INTEROP_CONTRACTS.md`
4. `docs/DECISIONS.md`
5. `csv/` registries
6. `lexflow_agentic_plan_v3.xlsx`

Prompts and roadmap images are delivered as separate files alongside this ZIP, not inside it.
