# Hermes | Execution order and handoff

**Scope:** existing LexFlow CRM and its Elisa worker, not a new application. None of the enclosed prompts asserts that a route, MCP server, model adapter or installer exists. Begin with [ADMY’s audit](01-ADMY-audit.md); after human scope approval use [backy’s reinforcement ticket](02-backy-reinforcement.md), then [ADMY’s independent release gate](03-ADMY-release.md). Read [the living documentation policy](04-Architecture-and-retirement.md) before changing documentation.

AI engineering assistance owns approvals. ADMY orchestrates and independently tests; backy implements one accepted change at a time. No new profiles. Approved build/revision: ___; source: ___; disposable environment: ___; authorised paths: ___; test accounts: ___; issue/time/spend ceiling: ___; human owner: ___. Pass credential references through the approved secret store, not prompts. Missing permission, source or test environment → mark BLOCKED; no production fallback.

Use existing approved models: inexpensive routine model for inventory, coding-capable model only for a real defect, deterministic tests for contracts and access. Zero incremental paid inference unless a cap is approved. Use a private test folder and synthetic data only. Keep development, office installation and real-matter approval separate.
