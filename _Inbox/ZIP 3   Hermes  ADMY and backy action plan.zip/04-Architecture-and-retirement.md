# Architecture that changes with Elisa

**Terminology:** Architectural Knowledge Management (AKM) is the practice; an Architecture Decision Record (ADR) captures one significant decision and its rationale. The collection is the decision log ([ADR community definitions](https://adr.github.io/)). For a changed decision, link a successor rather than rewriting the accepted reasoning ([Microsoft architecture guidance](https://learn.microsoft.com/en-us/azure/well-architected/architect-role/architecture-decision-record)).

## Minimum documentation, not another documentation tree

Reuse existing canonical paths. If none exists, ADMY proposes `ARCHITECTURE.md` (current behaviour), `docs/decisions/` (why significant choices were made) and links to the existing API contract, MCP inventory, release procedure and tests. No new ADR for routine bug fixes. Avoid a second hand-maintained copy of generated routes or tool schemas.

| Update trigger | backy changes in the same patch | ADMY checks before marking done |
|---|---|---|
| New/removed route, changed schema or error | Existing contract, compatibility note and regression | Contract and running route agree on test build |
| MCP server/tool/scope added, changed or removed | Inventory, data destination, owner, approvals and disable path | Runtime capability evidence or explicit N/A |
| Storage, trust boundary, deployment or recovery changes | Current diagram and rollback; ADR for hard-to-reverse choice | Diagram labels as-is vs proposed; restore verified |
| Architecture unchanged | “No architectural impact” with one reason in change note | No unnecessary pages generated |

Current-state header: `owner | revision | verified date | environment | evidence link | known unknowns`. Diagram each boundary and data direction; do not label a design intention “deployed.” ADR template: `ID | status | context | alternatives | decision | trade-off | owner | evidence | revisit trigger | supersedes/superseded by`.

## ADMY upkeep prompt: run at each accepted change

> Compare the release diff with the canonical architecture and interface contracts. Report changed facts and affected links. Update current guidance in place. For obsolete documentation produce a retirement manifest: exact path, replacement, unique material migrated, inbound links, owner, retention/hold status, recoverable version and restore check. Mark known outdated guidance as superseded; stop indexing it as current advice. Request approval listing the exact paths before deletion. After approval remove only those redundant pages from the working tree, fix links and agent retrieval indexes, then verify clean navigation and recovery from history/backup. Preserve accepted/superseded ADRs, evidence and anything under hold. Never delete client files, unknown documents or sole copies. If retention is unclear, quarantine from active guidance and ask. Report what was removed, kept and why.

Progress entry for each cycle: `issue → user pain → smallest change → candidate build → independent test evidence → outcome → next decision`. Review every release; spend engineering time on the next measured bottleneck, not on increasing document or agent count.
