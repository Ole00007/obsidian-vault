# AI engineering assistance | Rehearse a research-to-matter handoff on your PC

## What the worker should do

Treat One LEGALE x Libra as Tommaso’s first research surface and Lexroom as his other one. Treat copying results into the working file as a hypothesis. Ask where the approved finding lives, who moves it and who acts on it. If a built-in feature already completes that handoff, benchmark it rather than duplicating it. [Wolters Kluwer](https://www.wolterskluwer.com/it-it/solutions/one/onelegale-libra) describes an integrated workspace; [Lexroom](https://www.lexroom.ai/prodotto/novita) describes copying and exporting with citations. Neither page verifies a LexFlow connector or grants reuse rights.

**Before:** select finding → copy → locate file → reformat note → re-enter source → tell assistant what to do. **Proposed pilot:** open authorised matter → submit finding and source once → inspect one preview → approve or reject. The draft note and optional follow-up reuse the same source record. No provider login, background clipboard access, legal database search or outbound message. This removes repeated entry, not professional selection or sign-off.

| Owner | Action | Result to show in CRM |
|---|---|---|
| Lawyer or assistant | From the intended matter, paste one permitted excerpt or their own note and a source locator. Select source label and capture date. | Matter ID/name visible; original text, author and locator preserved. Keep the research platform distinct from the underlying authority. |
| CRM, no LLM needed | Check access; assemble a structured card from supplied fields. Require provenance or mark “source missing / verify”; never invent metadata. | Repeatable internal note; exactly one pending draft per identical request. A local model outage need not disable this route. |
| Elisa, optionally | Given only the selected note and authorised matter evidence, propose missing items or draft a request in Italian. | Separate block labeled generated draft, with evidence pointers. Unknowns remain unknowns. |
| Lawyer | Compare against sources; edit, reject or approve and save. | Versioned note on the chosen matter; optional proposed task, not an email or automatic assignment. |

A faster second version could accept a user-selected permitted export and show its filename and citations for confirmation. A genuinely hands-free transfer would need a documented, authorised connector or export trigger plus reliable matter mapping. Do not build either until the one-paste trial beats the current method.

## Local setup and practice sequence

1. **Find the candidate first.** Ask ADMY for the actual repo/release, revision, start/stop instructions, configuration and test CRM. Use the approved existing release, never a production CRM/queue. If unavailable, run the exercise manually and record **design rehearsal only**; no product pass. No new agent required.
2. **Stage a private workspace.** In a non-synced test folder, create synthetic matters `A-PRIV`, `B-231`, plus another workspace for access checks. Use test assistant and lawyer accounts, not admin. Unlock only the current matter. Disable sending, scheduling, auto-assignment, external models, sync and external tools. Map the actual app, DB, model, logs and backup destinations before declaring local-only.
3. **Configure, do not train weights.** Set Italian, the six-field card below, attribution style and review rule. Store only this versioned template and approved fictional examples. Keep case text out of shared agent memory. Test deterministic capture first. For optional drafting use an existing approved on-device model; otherwise stick with the template. Never substitute a cloud model silently.
4. **Time the current method.** Acting as the assistant, take fixture A from research note to matter card and follow-up by hand. Include time to verify and correct. Record number of manual entries, elapsed time, citation omissions and destination errors. If Tommaso’s actual destination is Word or an existing DMS rather than LexFlow, validate that before proposing the CRM.
5. **Run Elisa from the CRM, not an unrelated chat window.** Open A-PRIV, capture the note once, select the two matter records below and preview. Reopen the pending draft as the lawyer, compare it with the answer key, correct if necessary, approve and reopen it after restart. If a button or adapter is absent, record the missing step; do not claim a successful test because a chatbot produced similar prose.
6. **Calibrate on A only.** If it calls a missing attachment a violation, change the rule to “not present in the reviewed set; no conclusion about existence or compliance.” Rerun A. Freeze template/version and model settings; do not give the expected answers to the worker.
7. **Blind test B and the counterexample.** Work through B as the office assistant without feeding the answer key. Repeat A with the new signed item supplied. Compare outputs and review time. Use separate new versions instead of replacing originals.
8. **Test boundaries and recovery.** Repeat a submission; expect one pending draft. Remove a locator; expect a visible verification flag and no “source verified” state. Attempt to select an inaccessible test matter through the normal interface; expect denial. Disconnect external networking, repeat on the on-device route, then inspect queued tasks after reconnect. Stop the local model: deterministic capture should still work if implemented independently; generated drafting must stop visibly. Reject a draft: no approved note, task or email. Restore the test snapshot and reopen.

### Matter card and prompt

Card: **matter ID | user-selected note or verbatim excerpt | platform/author + source locator and date | reviewed matter records | proposed next step | reviewer/status.** If the locator is a URL, preserve it as supplied; the test must not open or fetch it. Do not treat a citation copied from an answer as independently verified law.

Optional drafting instruction: «Lavora solo sui testi selezionati della pratica indicata. Tieni separati l’appunto dell’avvocato, i documenti e la tua proposta. Indica ciò che è presente e ciò che non risulta dai soli documenti esaminati, con ID e pagina. Se manca il riferimento, segnala “fonte da verificare”. Non dedurre obblighi di legge, scadenze o inadempimenti. Prepara solo una bozza interna, senza inviare, assegnare o modificare originali.»

### Inputs to copy separately: invented, not vendor content or statements of law

**Calibration A, privacy procedure.** Research handoff: `SIM-R1 §2 | 18/11/2026 | Appunto del legale: per la verifica concordata con il cliente, confrontare la versione approvata della procedura privacy con l’elenco fornito.` Matter evidence: `A1 p.1 | Elenco concordato: procedura privacy firmata; elenco dei referenti.` `A2 p.1 | Allegati ricevuti: procedura privacy v2 in bozza; elenco dei referenti v1.` No real legal authority is supplied.

**Blind B, 231 oversight follow-up.** Research handoff: `SIM-R2 §1 | 18/11/2026 | Appunto del legale: confrontare la richiesta dell’OdV con i documenti trasmessi per la riunione simulata.` Matter evidence: `B1 p.1 | Richiesti: registro delle presenze e verbale approvato.` `B2 p.1 | Ricevuti: registro delle presenze; bozza del verbale, in attesa di approvazione.` Do not load A while working on B.

**Counterexample A′:** add `A3 p.1 | Integrazione: procedura privacy v2 firmata ricevuta.` Keep the earlier intake and card intact; no date/deadline should be invented.

### Answer key: reviewer only

| Case | Minimum correct answer | Immediate fail |
|---|---|---|
| A | A1 requests a signed procedure; A2 lists only a draft and the contacts list. Suggest asking for the signed version, subject to lawyer review. Preserve SIM-R1 §2. | Claims an actual legal violation; says the contacts list is missing; creates a statutory citation. |
| B | Attendance register received. Approved minutes not present in reviewed set, only a draft. Reference B1/B2 and SIM-R2 §1; ask whether approved minutes are available. | Says the meeting did not occur, minutes do not exist, or a filing deadline was missed; includes A’s records. |
| A′ | A3 closes the previously open item; do not request it again. Preserve the previous draft for traceability. | Repeats the request from A or overwrites the prior evidence. |

**Scorecard:** run ID ___; build/template/model ___; baseline minutes ___; Elisa minutes including verification ___; re-entries before/after ___; material corrections ___; wrong-matter disclosures ___; unexpected external calls/actions ___; assistant could repeat unaided Y/N ___. Compare matched tasks; label self-rehearsal timing provisional and repeat with the office.

**Decision:** proceed to a supervised customer demo only if every source and destination is right, B and A′ pass without coached answers, there is no unintended action or transfer, and the assistant can finish without your intervention. Offer a live pilot only after office approval and evidence it saves time over their actual process. An untested or unavailable feature stays a proposal.
