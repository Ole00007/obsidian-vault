# AI engineering assistance | Your action plan

**Your decision:** does Elisa remove a repeated handoff without creating extra review work? Tommaso uses One LEGALE x Libra and Lexroom; the manual copy into his operational matter is still a hypothesis. Do not offer a vendor integration or production installation as an established capability.

| When | Your action | Evidence before moving on |
|---|---|---|
| Now | Send only the WhatsApp from ZIP 1. Give ADMY ZIP 3, an authorised build/repository location and a disposable CRM. Authorise read-only inspection, not production changes or spend. | Tommaso can reply in one line. ADMY records the revision, environment and unknowns. |
| Before the visit | Work through [the local rehearsal](Local-rehearsal.md). Time a manual handoff first. Use A to calibrate; keep the answer key and B/A′ away from backy during calibration. | One entry reopens as one draft in the correct matter. Compare times **including review**. If this is only a model response, label it model-only. |
| After audit | Choose one outcome: reuse, configure, patch one confirmed defect, or stop. Approve a named issue, acceptance test, budget and rollback, not a general rewrite. | Verified current-state diagram; list of enabled API/MCP capabilities and actual destinations, or explicit unknowns. |
| Before installation | Obtain a trusted release, OS/permissions, IT approval and an uninstall/restore procedure. Have ADMY witness a clean-PC rehearsal. | Installed build ID and restore evidence. Without either, bring a demo on your own PC rather than installing at the office. |
| Tuesday 24 November | Ask about the last handoff, test with invented material, then let the assistant repeat the task and Tommaso judge it. | Record the office’s actual baseline, saved re-entry and review-inclusive time. If their current tools already do it, stop. |
| After the visit | Agree one supervised pilot only if useful. Ask separately about real data, processing destinations, retention, access and any fees. | Named owner, scope, next test, decision date. No real matter by default. |

**Control your time.** Allow 45–90 minutes for the initial audit, 1–3 hours for a narrow confirmed defect, and 45–90 minutes for local installation rehearsal. These are planning allowances, not promises. Stop for a new estimate if identity isolation, deployment or the worker itself is missing. No new subscription or paid provider by default.

**Documentation approval:** ask to see the current architecture, the decision that changed, and a list of stale pages with replacements. Approve removal of exact paths only after a restorable snapshot and link checks; never delete client records or the decision trail.

**Track improvement:** after each session, capture one troublesome manual step and one before/after measure in [the scorecard](Progress.csv). Require ADMY to attach the build, backy’s change, an independent retest, and the next decision before marking work done.
