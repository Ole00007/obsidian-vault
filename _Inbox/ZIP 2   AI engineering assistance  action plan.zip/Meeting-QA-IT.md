# Tommaso | Dalla ricerca alla pratica, senza riscriverla

## Prima domanda: trenta secondi

«Tommaso, mettiamo che tu abbia appena trovato su One LEGALE x Libra il punto che ti serve. Cosa succede dopo? Lo ritrovi già nella pratica dove lavorate tu e chi ti assiste, oppure qualcuno deve riportarlo lì? Non serve aprire un fascicolo: mi basta sapere l’ultimo passaggio.»

Se non ricopia nulla: «Perfetto, allora quel passaggio non lo tocchiamo. Resta qualcosa da fare a mano, magari assegnare la verifica o ricordarsi cosa chiedere al cliente?» Se la risposta è no, fermati. Non proporgli un secondo archivio.

## Come spiegarglielo

«Tu continui a fare ricerca su One LEGALE x Libra o su Lexroom. L’idea è toglierti il lavoro dopo: apri la pratica giusta in LexFlow e passi a Elisa una volta sola un tuo appunto con il riferimento, oppure un estratto che puoi riutilizzare. Lei ti prepara una nota con il riferimento già al suo posto e, se serve, una bozza per chi ti assiste. Tu controlli, correggi o scarti. Una scelta resta tua: cosa vale la pena portare nella pratica. Quello che proviamo a eliminare è doverlo riscrivere in tre posti.»

«Per esempio: la checklist concordata con un’azienda prevede la versione firmata di una procedura. Nella cartella di prova c’è solo una bozza. Il risultato utile non è “il cliente è inadempiente”: è “negli allegati esaminati non ho trovato la versione firmata”, con il riferimento e una breve richiesta pronta da rivedere. Porto io i documenti inventati. Non devo entrare nei tuoi account.»

## Domande che potrebbe farti

| Se chiede… | Puoi rispondere… |
|---|---|
| «Ma allora devo ancora fare copia e incolla?» | «Una volta, sì, oppure scrivi due righe tue col riferimento. Non ti prometto un collegamento automatico. Il vantaggio c’è se dopo né tu né chi ti assiste dovete riaprire la ricerca, riformattarla e riscrivere la stessa richiesta.» |
| «Perché non farlo direttamente in Libra o Lexroom?» | «Se lì hai già nota, incarico e verifica nel posto dove lavorate entrambi, ti direi di continuare così. Proviamo Elisa solo se oggi manca il passaggio alla pratica operativa o al tuo assistente.» |
| «Come sa in quale pratica metterlo?» | «Non voglio che lo indovini. Scegli tu la pratica. Prima di salvare vedi cliente e codice; se non coincidono o non hai accesso, il flusso deve fermarsi.» |
| «Come controllo che non abbia cambiato il senso?» | «Ti mostro separati il testo che hai scelto, il riferimento e la bozza di Elisa. Se la fonte non c’è, deve dirlo; non inventa un articolo o una scadenza. La verifica giuridica resta tua.» |
| «Può usare tutto ciò che trovo nella banca dati?» | «Non lo diamo per scontato. Nella prova usiamo solo testo nostro. Sul lavoro vero partiamo da una tua nota e dagli estremi della fonte; usiamo estratti o esportazioni solo se le condizioni applicabili lo consentono.» |
| «Serve la mia password? Oppure ChatGPT, Claude, Grok?» | «Per questa prova no. Non usiamo i tuoi account e non importa quale chat usi. Prima verifichiamo il passaggio nella pratica; per copiare fedelmente testo e riferimento non serve nemmeno un modello.» |
| «I miei dati restano qui?» | «Per la demo non uso dati tuoi. Per una pratica vera ti faccio vedere prima dove girano CRM, modello e salvataggi, chi ha accesso e quanto si conserva. Non ti dirò che è tutto locale solo perché l’app si apre sul PC.» |
| «E se parte una mail o viene assegnato un compito per errore?» | «Nella prova non colleghiamo la posta. La richiesta e l’eventuale attività restano bozze. Se non posso dimostrartelo sull’installazione, non la usiamo con una pratica vera.» |
| «Se cambia il risultato domani?» | «La nota è datata, non un aggiornamento automatico della banca dati. Se cambi il riferimento prepariamo una nuova versione, senza sovrascrivere quella che avevi controllato.» |
| «Quanto mi costa e come so che conviene?» | «Per la dimostrazione non ti chiedo di comprare un abbonamento. Cronometriamo il tuo metodo e la prova, inclusa la rilettura. Se aggiunge passaggi anziché toglierli, ci fermiamo prima di parlare di un pilota.» |

**Promemoria privato:** strumenti in uso secondo il tuo resoconto: One LEGALE x Libra e Lexroom. Frequenza relativa, passaggio manuale e uso di ChatGPT/Claude da confermare. Fonte primaria per il nome e il perimetro commerciale: [Wolters Kluwer, One LEGALE x Libra](https://www.wolterskluwer.com/it-it/solutions/one/onelegale-libra). Lexroom descrive copia ed esportazione con o senza fonti nelle [novità ufficiali](https://www.lexroom.ai/prodotto/novita). Queste pagine descrivono prodotti; non attestano un’integrazione Elisa, né le condizioni contrattuali dello studio.
