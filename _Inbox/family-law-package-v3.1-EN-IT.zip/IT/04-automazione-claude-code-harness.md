# 04 - Configurazione: Hermes / Lexflow-Elisa + Claude Code + Cowork + altri (v3.1)

I comandi derivano da documentazione e repository pubblici; confermare con `--help`. Nulla e' installato o testato. Il comportamento di Lexflow-Elisa e Copilot non e' verificato: usare il pacchetto Markdown portabile e controllare cosa ciascuna piattaforma legge davvero. Terminologia: Groq = fornitore di inferenza (un backend di modelli, non un assistente); Grok Bot = prodotto assistente che Hermes puo' importare; "Groq Bot" nella frase finale sulle piattaforme resta come formulazione dell'avvocato.

## Ruoli
- Hermes / Lexflow-Elisa: intake, pianificazione, coordinamento, memoria, gateway di messaggistica.
- Claude Code: script circoscritti, pipeline OCR, test; i compiti arrivano come file.
- Claude Cowork (avvocato): revisione e approvazione su cartella condivisa; vede solo `13-review-pack/`.
- Copilot, Groq Bot, altri: stesso contratto - leggono il pacchetto, scrivono in `10-drafts/` o propongono differenze, mai sugli originali delle prove.
- `legal-harness-init`: scrive blocchi governati di AGENTS.md/CLAUDE.md; non e' una barriera in esecuzione.

## Pacchetto portabile (vale su ogni piattaforma)
`AGENTS.md` (regole, controlli, scala) + `skills/family-law-casework/` + `PROJECT.md` + vault (Obsidian) + pacchetto di revisione. Mappa per piattaforma: Hermes -> istruzioni del profilo/SOUL.md e skill; Claude Code/Cowork -> CLAUDE.md e profilo di pratica del plugin; Copilot -> il proprio file di istruzioni personalizzate; Lexflow-Elisa/Groq Bot/altro -> il file di istruzioni che carica. Impacchettare come cartella Agent Plugins v1 (`plugin.json`, `skills/`, `mcp.json`) dove supportato.

## Componenti Hermes
- Per profilo: `hermes -p <profilo> cron list`, `cron doctor`, `mcp add`. Server MCP e credenziali sono per profilo.
- `hermes import-agent` (plugin `agent-importers`): prima l'anteprima, `--dry-run` non scrive nulla. Claude Code/Codex/Cursor: istruzioni -> memoria, MCP -> config.yaml, skill copiate, `--sync` reimporta le modifiche. Grok Bot/OpenBot: ruolo -> SOUL.md, memorie -> MEMORY/USER, skill -> `skills/grok-bot-imports/`, routine pianificate -> cron in pausa, routine a evento -> file di note; gli export con chiavi che sembrano credenziali vengono rifiutati; eseguire una volta per Bot nel profilo che deve possederlo.
- `delegation.backend: profile_routes` (plugin advanced-delegation): il sotto-agente gira come uno dei tuoi profili, con modello, skill, SOUL.md di quel profilo. Riusa agenti; non ne aggiunge. Elencare un profilo condivide le sue credenziali con i sotto-agenti del profilo chiamante.
- Terminale in sandbox: `hermes config set terminal.backend bubblewrap` (Linux) o `singularity`.
- `hermes inbox` (vista in sola lettura di cron falliti/deleghe bloccate); schema `hermes-telegram-business` = bozza al titolare, Invia/Modifica/Scarta, nulla parte senza un tocco.
- Tracciamento Langfuse: lasciare la cattura dei contenuti al livello sanitizzato predefinito o spenta.

## Corsie dei modelli (instradamento dei fornitori)
| Corsia | Per cosa | Non per |
|---|---|---|
| Veloce (es. Groq, `hermes plugins install groq-provider`, `GROQ_API_KEY` in `.env`, `model.provider: groq`) | pulizia OCR, triage, sintesi, bozze di traduzione, estrazione strutturata su dati non riservati o con ZDR approvato | analisi giuridica finale, conclusioni finanziarie |
| Profonda (modello piu' robusto scelto dall'avvocato) | G2 diritto, G3 numeri, bozze per G4 | lavoro massivo a basso rischio (costo) |
| Locale (Ollama / llama.cpp / vLLM / LM Studio) | le pratiche piu' sensibili | compiti che richiedono qualita' di frontiera |
Gestione dati di Groq (documentazione del fornitore): le richieste di inferenza non sono conservate di default; input/output possono essere registrati fino a 30 giorni per affidabilita' o indagini su abusi, salvo Zero Data Retention attivato in Data Controls; batch e fine-tuning conservano i dati; i dati conservati risiedono in bucket cloud negli USA. L'avvocato decide per pratica e registra in `14-agent-ops/access-log.md`.

## Bridge MCP di Hermes (`hermes mcp-serve`): esposizione e configurazione locale sicura
Cosa fa: qualsiasi client MCP collegato (Claude Code, Claude Desktop, Cursor, Codex) puo' elencare e leggere le conversazioni di messaggistica del profilo attivo (`state.db`), leggere eventi, inviare messaggi come i tuoi account collegati, rispondere ad approvazioni. `--tools` (spento di default) espone anche strumenti web, browser, visione, immagini, skill, TTS con le tue credenziali del fornitore; terminale, file e kanban non sono mai esposti. Il trasporto e' stdio.

Il locale e' piu' sicuro? Si' per l'esposizione di rete, no per tutto il resto. Una configurazione locale e privata (macchina propria, memoria locale, server locale) elimina: raggiungibilita' da rete, archiviazione cloud di terzi della cronologia, host condiviso tra utenti. Non elimina: (a) il client collegato che invia cio' che legge al proprio fornitore di modelli; (b) il fornitore del modello che riceve i prompt; (c) altri programmi sulla stessa macchina (qualsiasi processo locale raggiunge una porta loopback senza password); (d) furto del disco/malware; (e) invii a nome tuo se sono collegati account gateway.

Configurazione sicura, in ordine:
1. Macchina: cifratura dell'intero disco (FileVault/BitLocker/LUKS); blocco schermo; utente di sistema dedicato al lavoro legale; firewall attivo.
2. Profilo Hermes dedicato alla pratica; `HERMES_HOME` sul volume cifrato; permessi di `.env` 600; solo le chiavi necessarie a quel profilo.
3. Non collegare alcun account di messaggistica a quel profilo (o usare un account bot separato), cosi' il bridge non ha nulla a nome del quale inviare. `--tools` spento.
4. Avviare il bridge solo su richiesta, da una sola configurazione client, via stdio: `hermes -p <profilo> mcp-serve` (argomenti del client MCP `["mcp-serve"]`). Non avvolgerlo in proxy HTTP o tunnel.
5. Verificare che non sia comparso alcun listener: `lsof -iTCP -sTCP:LISTEN -n -P` (macOS/Linux) o `netstat -ano` (Windows); fermare il bridge a fine revisione.
6. Percorso del modello: fornitore zero-retention, regione UE, con DPA firmato, oppure modello locale, per le pratiche piu' sensibili.
7. Memoria: vault Obsidian sul volume cifrato, senza sincronizzazione consumer; Hindsight in `local_embedded` con endpoint LLM locale, oppure `local_external` solo su `localhost`; `auto_retain` spento; plugin bloccato a un commit SHA; il daemon integrato viene scaricato con uvx al primo avvio, quindi installare una volta su rete fidata.
8. Terminale in sandbox (bubblewrap/singularity) e prompt per comandi pericolosi attivi.
9. Test canarino: inserire una stringa unica in una pratica fittizia, eseguire il flusso, controllare log del fornitore/traffico in uscita (firewall o monitor di rete) per confermare dove va.
10. Backup cifrati; prova di ripristino; log e tracce contengono testo della pratica: fissare la conservazione e trattarli come atti della pratica.
11. L'avvocato registra fornitore, luogo e base giuridica di ogni strumento in `14-agent-ops/access-log.md`.

## Permessi (partire stretti)
| Connessione | Permesso |
|---|---|
| Cartella pratica | lettura degli originali; scrittura solo nelle cartelle derivate |
| OCR | prima locale; cloud con approvazione |
| Ricerca giuridica | norme e sentenze ufficiali; registrare le fonti non disponibili |
| Registri societari | atti pubblici; costi con approvazione |
| Email/PEC | solo bozze |
| Calendario | proposte; i termini li conferma l'avvocato |
| CRM / piattaforme di automazione | scrittura solo via webhook approvato con schema del payload; nessun export massivo a testo libero |
| Bridge MCP di Hermes | spento di default |

## Flusso
```text
file autorizzato -> hash/dedup -> OCR -> verifica campi -> differenza indice (proposta)
-> aggiornamento cronologia/questioni -> ricerca solo sulle domande cambiate -> bozza
-> controllo G4 -> 13-review-pack -> avvocato (Cowork) -> rilascio approvato
```
Checkpoint sui lavori lunghi, limite ai tentativi, budget di token, fallback di fornitore non approvati disattivati. I primi cron sono solo interni: sintesi dei nuovi documenti, elenco prove mancanti, revisione dei termini.

## Ordine dei lavori
1 Inventario + backup. 2 Approvare la mappa delle capacita'. 3 Revisione licenze/connettori. 4 Istruzioni tramite diff rivisto. 5 Permessi di esecuzione + controlli sul bridge + corsie dei modelli. 6 Test (per corsia). 7 Attivare cron. 8 Prova di ripristino. 9 Ricalcolo dei rischi (file 03).

## Accettazione
Test 1-10 superati; una nuova sessione carica le istruzioni; il backup si ripristina; il cron gira sotto il profilo indicato; la stringa canarino resta nei percorsi approvati; nessun invio esterno senza approvazione.

---
Hermes, Claude Cowork, Claude Code, Copilot, Lexflow Elisa, Groq Bot o qualsiasi altra infrastruttura di assistente agentico: la configurazione di base e' a scelta dell'avvocato.
