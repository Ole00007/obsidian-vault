# 05 - Diritti sugli interessi societari nella separazione (v3): quadro generale

Informazione giuridica per preparare il confronto con il legale; non e' una determinazione di spettanza. Vale per ogni pratica in cui un coniuge detiene, gestisce o beneficia di una societa', di una societa' di persone o di altro ente. Esempio svolto: la separazione Rasing (procedimento italiano; una societa' tedesca e una societa' di Hong Kong sono trattate come esempi; ruoli ed eventuali collegamenti vanno provati con visure e registri, non presunti).

## Sintesi
Il matrimonio non attribuisce automaticamente meta' di una societa', meta' degli utili o l'accesso ai libri. Quattro domande distinte: chi e' titolare; se rientra nel regime patrimoniale; quale pretesa economica esiste senza titolarita'; quali risorse contano per il mantenimento.

## Punti fissi
1. Controllo, titolarita' e beneficio sono diversi: un amministratore (es. Geschaeftsfuehrer tedesco) puo' non possedere nulla; un titolare puo' non gestire; un beneficiario puo' detenere tramite un altro ente.
2. Ogni ente risponde alla legge della propria sede per i diritti societari; il matrimonio alla legge del regime patrimoniale. Mappare entrambe.
3. Nulla e' "accertato" finche' un documento non lo mostra. Il non verificato resta IGNOTO.

## Quale legge risponde a quale domanda
| Tema | Da verificare |
|---|---|
| Legge su divorzio/separazione | Reg. (UE) 1259/2010 (Roma III); l'Italia vi partecipa |
| Regime patrimoniale | Reg. (UE) 2016/1103 per matrimoni/scelte dopo il 29 gen 2019 (art. 69); prima: norme nazionali di conflitto, es. L. 218/1995 art. 30 |
| Mantenimento | Reg. (CE) 4/2009, strumenti dell'Aia; escluso dal 2016/1103 |
| Diritti societari | legge della sede dell'ente: es. GmbHG tedesca; diritto societario di Hong Kong tramite i dati del Companies Registry |
| Riconoscimento/esecuzione | Bruxelles II ter (2019/1111) nell'UE; per Stati terzi (es. Hong Kong) serve un legale in quella giurisdizione |
Nel 2016/1103: prima la legge scelta (art. 22); altrimenti prima residenza abituale comune dopo il matrimonio, poi cittadinanza comune, poi collegamento piu' stretto (art. 26); la legge applicabile disciplina classificazione, debiti, poteri sui beni e liquidazione (art. 27).

## Matrice per tipo di ente (riutilizzabile)
| Tipo di ente | Prova della titolarita' | Come l'utile arriva al titolare | Via di informazione |
|---|---|---|---|
| GmbH tedesca (esempio) | elenco soci (GmbHG 40), atti notarili di cessione | dividendo dopo delibera (par. 29); compenso da amministratore; interessi su finanziamento soci | diritti del socio par. 51a-51b; via giudiziale |
| Societa' privata di Hong Kong (esempio) | Companies Registry: annual return, registro soci, amministratori | dividendi, compensi, finanziamenti | ricerca nel registro (pubblica); diritti dei soci secondo il diritto di HK tramite legale di HK |
| S.r.l./S.p.A. italiana | visura camerale, libro soci | dividendi, compensi | diritti societari italiani; legale |
| Societa' di persone / ditta individuale | atto costitutivo, partita IVA | prelievi, quota di utili | atti fiscali; disclosure nel procedimento |
| Trust / fondazione / fiduciario | atto, registro dei beneficiari | distribuzioni | legale nella giurisdizione della sede |

## Punti di ancoraggio italiani (testo da verificare dal legale)
- La comunione legale si scioglie, in caso di separazione, quando il giudice autorizza i coniugi a vivere separati, o dalla sottoscrizione del verbale di separazione consensuale davanti al presidente, se omologato (e-Justice).
- Codice civile artt. 177-179 (comunione, beni destinati all'impresa, beni personali), 191 (scioglimento), 194 (divisione). Se frutti, proventi o beni d'impresa pongano questioni di comunione de residuo e' domanda per il legale.
- Divorzio dopo separazione: 12 mesi (giudiziale) o 6 mesi (consensuale) ininterrotti (e-Justice).
- Nel procedimento si allegano dichiarazioni dei redditi (3 anni), prova di diritti su beni registrati e quote, estratti bancari/finanziari (3 anni) (artt. 473-bis.12 ss.).

## Percorso decisionale
1. Date chiave: matrimonio, prima residenza comune, acquisto/cessione delle partecipazioni, data di separazione, data di deposito.
2. Legge per tema (tabella).
3. La titolarita' e' provata da documenti? Se no, raccoglierli prima di argomentare.
4. La partecipazione rientra nel regime? Applicare la legge competente a data di acquisto, provvista, esclusioni.
5. Se la partecipazione resta all'altro coniuge: cercare una via economica (conguaglio, rimborso, accordo).
6. A parte, costruire il prospetto delle risorse personali per il mantenimento.
7. Piu' enti: disegnare `group-chart.md`; tracciare i flussi tra enti (finanziamenti, compensi, dividendi); segnalare flussi tra parti correlate senza presumere illeciti.

## Lessico degli "utili"
Fatturato, utile contabile, riserve, dividendo, compenso dell'amministratore, finanziamento soci, valore delle quote sono cose diverse. Il capitale non e' valore; l'aumento del patrimonio netto non e' reddito netto; il saldo verso i soci e' un credito/debito, non liquidita'; righe assenti in bilanci pubblici abbreviati non provano nulla. Esempio: il bilancio abbreviato di una GmbH mostra variazioni di attivo e patrimonio netto, non stipendi, imposte o ricavi.

## Diritti di informazione (esempio: GmbH)
GmbHG par. 29 (utili), 40 (elenco soci), 51a-51b (informazione, ispezione, via giudiziale). Il matrimonio da solo non prova un diritto ex par. 51a; conta la qualita' di socio. La traduzione inglese puo' essere in ritardo; usare il testo tedesco. Mai accedere ad account o sistemi privati senza base lecita.

## Cautele
Nessun doppio conteggio; le decisioni sui figli restano separate dalla trattativa economica; ogni cifra riconducibile a un documento; le conclusioni di diritto straniero vengono da un legale abilitato in quella giurisdizione.
