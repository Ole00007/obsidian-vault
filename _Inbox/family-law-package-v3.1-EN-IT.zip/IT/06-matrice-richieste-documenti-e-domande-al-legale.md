# 06 - Matrice generale di richieste documentali e domande al legale (v3)

Riutilizzabile per ogni separazione/divorzio. Esempio svolto: separazione Rasing - la societa' tedesca e quella di Hong Kong sono esempi delle righe "ente"; sostituirle con gli enti della nuova pratica.

## Come usarla
1. Spuntare i blocchi pertinenti (A-H). 2. Per ogni riga fissare: base giuridica, rilevanza, periodo, fonte, via (volontaria / tramite legale / giudiziale), responsabile, scadenza, stato. 3. Registrare in `evidence-index.md`; annotare le lacune in `open-questions.md`.

## Matrice delle richieste
| Blocco | Documento | Scopo | Livello | Fonte tipica |
|---|---|---|---|---|
| A Identita' e stato | certificato di matrimonio; documenti di identita', certificati di residenza; permesso/visto; certificati dei figli | competenza, legge applicabile, date chiave | P1 | stato civile, cliente |
| A | convenzione matrimoniale / scelta del regime / accordo sulla legge applicabile | regime applicabile | P1 | notaio, cliente |
| B Procedura | provvedimenti e procedimenti precedenti tra le parti (qualsiasi paese) | litispendenza, coerenza | P1 | tribunali, cliente |
| C Reddito (ciascun coniuge) | dichiarazioni dei redditi (3 anni); buste paga; fatture/registri IVA; prestazioni | mantenimento, disclosure | P1 | agenzia delle entrate, cliente |
| C | contratti da amministratore, bonus, policy spese, costi pagati dalla societa' (auto, alloggio, viaggi) | risorse reali | P2 | datore/ente |
| D Banche | estratti conto bancari/carte/finanziari (3 anni), tutti i conti anche esteri e cointestati | disclosure, tracciamento | P1 | banche |
| D | finanziamenti, mutui, garanzie; trasferimenti di denaro tra coniugi/enti | passivita', flussi | P2 | banche, cliente |
| E Beni | atti, visure catastali/ipotecarie, locazioni, registri di veicoli/natanti; stime | patrimonio, qualificazione | P1/P2 | conservatorie, cliente |
| F Interessi societari (per ente) | visura (camerale / Handelsregister / HK Companies Registry); elenco soci / registro dei membri; statuto e patti parasociali | titolarita', controllo | P2 | registri |
| F | atti di acquisto / cessione / aumento di capitale; prova dei pagamenti | data e provvista dell'acquisto | P2 | notaio, ente |
| F | bilanci con conto economico; delibere su utili e dividendi; contratti e mastri dei finanziamenti soci | utile vs distribuzione vs debito | P2/P3 | ente |
| F | contratti con parti correlate; organigramma di gruppo; trasferimenti infragruppo | flussi tra enti | P3 | ente, legale |
| G Previdenza e assicurazioni | estratti pensionistici, polizze vita/sanitarie, TFR | patrimonio, mantenimento | P2 | fondi, assicuratori |
| H Figli | costi scolastici/sanitari; storia di residenza e cura; registro comunicazioni | affidamento, mantenimento | P1 | cliente, scuole |

Livelli: P1 = di norma richiesto nel procedimento; P2 = necessario a provare titolarita'/reddito, da chiedere tramite il legale; P3 = decide il legale dopo l'esame di P1/P2 (proporzionalita').

## Domande al legale (generali)
1. Competenza e legge: quale giudice; quale legge per divorzio, regime patrimoniale, mantenimento, figli; il 2016/1103 si applica a questo matrimonio?
2. Date chiave: quali date il giudice considera decisive (separazione, scioglimento della comunione, valutazione)?
3. Titolarita': cosa mostrano registri e atti societari affidabili per ciascun ente?
4. Tipo di pretesa: le quote, il loro valore, un rimborso o altro?
5. Mantenimento: quali redditi e benefit contano, in quale procedimento?
6. Acquisizione degli atti: chi puo' lecitamente chiedere cosa, con quale via; costi; prassi dei registri esteri?
7. Legale estero / perito / commercialista: necessari per quale ente o tema?
8. Urgenza: ci sono elementi (non sospetti) per misure di conservazione?
9. Figli: modalita' e costi; esistono timori per la sicurezza?
10. Accordo: quali voci sono negoziabili, in che ordine, con quali documenti allegati?

### Integrazioni per ente (esempi dalla pratica Rasing)
- Societa' tedesca: elenco soci (GmbHG 40), bilanci e delibere sugli utili (par. 29), via di informazione (51a-51b), legale tedesco per le questioni societarie.
- Societa' di Hong Kong: estratti del Companies Registry (membri, amministratori, annual return), legale locale, collegamento con l'ente tedesco provato solo da documenti.

## Istruzione al legale
> Si chiede di valutare quali documenti siano richiesti in questo procedimento e se ulteriori atti societari o esteri possano essere lecitamente richiesti. Distinguere le prove su titolarita', trattamento nel regime patrimoniale, reddito personale effettivo e presupposti per ulteriori accertamenti. Indicare documenti mancanti e via di acquisizione per giurisdizione.

## Prompt di ricerca (per l'assistente)
> Analizza i diritti del coniuge su interessi societari e redditi in una separazione con enti in [paesi]. Individua la legge applicabile per tema, applica le norme transitorie, separa titolarita/valore/utile/dividendo/compenso/finanziamenti, attribuisci le contestazioni, verifica ogni punto giuridico in una fonte ufficiale aggiornata. Non affermare meta' automatica, accesso automatico ai libri o redditi occultati provati. Consegna matrice condizionale dei diritti, prove, richieste per livello, spiegazioni alternative, domande per il legale.
