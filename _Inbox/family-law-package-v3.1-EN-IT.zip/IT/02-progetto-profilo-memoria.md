# 02 - Progetto, profilo, memoria, struttura cartelle (v3.1)

## PROJECT.md
```markdown
# Preparazione pratica di diritto di famiglia
Scopo: organizzare prove lecite, verificare il diritto, preparare bozze per revisione dell'avvocato.
Giurisdizione: Italia; competenza e legge applicabile decise per tema.
Lingua: spiegazioni in inglese; italiano per le bozze destinate al legale; termini tedeschi/stranieri accanto alla traduzione.
Autorita': gli originali prevalgono sui riassunti. Dichiarazioni contestate = affermazioni attribuite.
Modalita' privacy: local. Fatti reali solo in private/case-context.md (permessi 0600, escluso da Git). I file di istruzioni condivisi contengono solo codice pratica, fase, regole.
Limiti: nessun deposito, invio, transazione, pagamento, cancellazione o accesso agli account privati altrui senza base lecita e approvazione specifica per l'azione.
Stato: ogni documento giuridico e' bozza finche' non approvato dall'avvocato.
```

## Descrizione del profilo (neutrale rispetto alla piattaforma)
Assistente di diritto di famiglia basato sulle prove. Organizza i materiali di separazione/divorzio, verifica il diritto per giurisdizione, riconcilia i dati finanziari, prepara bozze con fonti per l'avvocato. Segnala incertezze, rischi per la sicurezza, azioni esterne.
Funziona su qualsiasi infrastruttura agentica: Hermes, Claude Cowork, Claude Code, Copilot, Lexflow Elisa, Groq Bot o qualsiasi altra infrastruttura di assistente agentico: la configurazione di base e' a scelta dell'avvocato.
Regole che seguono il profilo su ogni piattaforma: etichette delle prove, controlli G0-G4, scala di autonomia L0-L3, nessuna azione esterna senza approvazione.
Specifiche Hermes: riusare il profilo esistente; eseguire le automazioni con `hermes -p <profilo>`; un profilo separa configurazione, `.env`, memoria, skill, sessioni, gateway ma non e' una sandbox.

## Memoria: tre livelli, prima il Markdown
| Livello | Ruolo | Strumento |
|---|---|---|
| 1 Memoria integrata | piccola, limitata: preferenze, codice pratica, percorsi degli indici | Hermes `USER.md`/`MEMORY.md`; CLAUDE.md negli strumenti Claude; memoria propria della piattaforma |
| 2 Vault esterno (fonte di verita') | leggibile, portabile, dell'avvocato: decisioni, cronologia, questioni, schede societa', glossario | vault Obsidian, uno per pratica |
| 3 Motore di richiamo esterno (opzionale) | richiamo di fatti/entita' tra sessioni e strumenti | Hindsight (retain / recall / reflect) |

Perche' esterna: la memoria sopravvive al cambio di assistente (Hermes -> Cowork -> Copilot -> CRM o piattaforma di automazione), e' verificabile, salvabile, consegnabile a un collega. La memoria integrata e' un'istantanea limitata: non deve essere l'unico registro.

### Obsidian
- Un vault per pratica; cartella = `14-agent-ops/memory/` piu' note nelle cartelle della pratica. Markdown semplice con frontmatter: `type, matter, status, source, date, confidence, reviewed_by`.
- Gli agenti vi accedono via MCP/CLI (es. plugin Agent MCP per Claude Code/Codex, `mcp-obsidian` tramite Local REST API - Obsidian deve essere aperto - oppure Open Second Brain, che supporta Hermes e Claude Code). Verificare codice e comportamento di rete di ogni plugin prima dell'uso.
- Vault su disco cifrato. Nessuna sincronizzazione cloud consumer, salvo cifratura end-to-end approvata dall'avvocato.
- Esportazione notturna: `MEMORY.md`, `USER.md`, `decisions.md`, attivita' aperte -> vault. Ripristino = copia inversa.

### Hindsight (Vectorize)
- Provider di memoria nativo di Hermes: `hermes plugins install hindsight`, poi `hermes memory setup` (o `hermes config set memory.provider hindsight`); verifica con `hermes memory status`; disattivazione `hermes memory off`. Blocco versione: `hermes plugins install vectorize-io/hindsight/hindsight-integrations/hermes --force --ref <sha-di-40-caratteri>`.
- Modalita': cloud, `local_external` (proprio server, predefinito `http://localhost:8888`), `local_embedded` (daemon + PostgreSQL integrato in `~/.hindsight/profiles/<profilo>`).
- Fatti di privacy dalla disclosure del plugin: in cloud e local_external ogni turno, e ogni modifica a MEMORY/USER, e' inviato all'API configurata; `local_embedded` richiede comunque una chiave LLM per l'estrazione (qualsiasi endpoint compatibile OpenAI, anche llama.cpp, vLLM, LM Studio): per un uso interamente locale puntarlo a un modello locale. Se l'estrazione e' puntata a un fornitore ospitato (es. Groq), il testo della pratica va a quel fornitore.
- Controllo: `auto_retain` e' true di default - impostarlo a false e usare la modalita' a strumenti (`hindsight_retain` chiamato deliberatamente) per pratiche sensibili; una bank per pratica; `trusted_project_dirs` ristretto.
- Fuori da Hermes: Hindsight ha anche vie MCP/SDK/CLI e installer per Claude Code, quindi la stessa bank puo' servire piu' assistenti.

### Regole di memoria
`memory.write_approval: true` ove disponibile; le scritture in attesa (`/memory pending`) non sono memoria finche' non approvate. Verificare la voce nello stesso profilo, poi richiamarla in una nuova sessione. Non salvare segreti, numeri di documento, accuse come fatti. Pratiche diverse non condividono bank o vault.

## Struttura cartelle (menu completo - creare solo cio' che serve al caso)
```text
<codice-pratica>/
  PROJECT.md  README.md  glossary.md  contacts.md
  00-admin/        mandato, lettera di incarico, verifica conflitti, procure,
                   registro parcelle/costi, KYC/copie documenti (riservato), informative privacy, consensi
  01-intake/       racconto del cliente, obiettivi/priorita', questionario, segnalazioni di rischio urgente, note primo colloquio
  02-people/       registro parti, registro figli, terzi, rappresentanti, testimoni
  03-evidence/
    originals/ (sola lettura)  extracted/  translations/ (giurate vs di lavoro)  exhibits/ (numerati)
    comms-exports/ (WhatsApp, email, SMS)  media/ (foto, audio, video)
    financial/ (banca, carte, fisco, buste paga, pensioni)  property/ (atti, locazioni, registri immobili/veicoli)
    school-medical/ (riservato)  evidence-index.md  hash-manifest.csv  chain-of-custody.md
  04-chronology/   master-timeline.md  residence-history.md  travel-log.md  employment-history.md
  05-law/          jurisdiction-map.md  statutes/ (copie datate)  case-law/  court-rules-forms/
                   eu-instruments/  foreign-law-notes/  authority-log.md  freshness-check.md
  06-finance/      income-expenses.md  assets-liabilities.md  property-register.md  pensions-benefits.md
                   tax-position.md  valuations/  maintenance-calc/  scenarios.xlsx  reconciliation-log.md
  07-entities/     <societa'>/ visura, statuto, elenco soci, bilanci, verbali,
                   finanziamenti, parti correlate ; group-chart.md
  08-children/     bozze piano genitoriale  calendari  scuola  salute  spese  registro consegne  registro comunicazioni
  09-strategy/     issues.md  options-scenarios.md  negotiation-positions.md  settlement-terms.md  risk-register.md
  10-drafts/       atti, repliche, istanze, lettere, accordi; intestazione: versione | stato | revisore | data
  11-correspondence/ cliente  controparte  tribunale  terzi ; in-out-log.md
  12-procedure/    deadlines.md  hearings.md  orders/  filings-receipts/  service-log.md
  13-review-pack/  pacchetto per l'avvocato: indice, cronologia, questioni, prospetto finanziario, domande aperte
  14-agent-ops/    AGENTS.md  CLAUDE.md  skills/  prompts/  memory/ (export vault)  decisions.md
                   task-board.md  run-logs/  approvals-log.md  evals/  cost-log.md  access-log.md
  15-closure/      relazione di chiusura, piano di conservazione, registro cancellazioni
```
Guida alla scelta: minimo = `PROJECT.md`, `03-evidence`, `04-chronology`, `05-law`, `06-finance`, `10-drafts`, `13-review-pack`, `14-agent-ops`. Aggiungere `07-entities` se esiste un interesse societario, `08-children` se ci sono minori, `12-procedure` dopo il deposito. Non pre-creare cartelle vuote.
