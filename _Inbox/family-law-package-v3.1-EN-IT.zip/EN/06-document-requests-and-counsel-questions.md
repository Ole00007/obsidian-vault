# 06 - General document-request matrix and questions for counsel (v3)

Reusable for any separation/divorce matter. Worked example: Rasing separation - German company and Hong Kong company are examples of the "entity" rows; replace with the entities of the new case.

## How to use
1. Tick the blocks that apply (A-H). 2. For each row fix: legal basis, relevance, period, source, route (voluntary / via counsel / court), owner, due date, status. 3. Store in `evidence-index.md`; log gaps in `open-questions.md`.

## Request matrix
| Block | Document | Purpose | Tier | Typical source |
|---|---|---|---|---|
| A Identity and status | marriage certificate; IDs, residence certificates; permit/visa; children's certificates | competence, applicable law, key dates | P1 | civil registry, client |
| A | marriage contract / property-regime election / choice-of-law agreement | governing regime | P1 | notary, client |
| B Procedure | prior orders and proceedings between parties (any country) | lis pendens, consistency | P1 | courts, client |
| C Income (each spouse) | tax returns (3 yrs); payslips; invoices/VAT records; benefits | support, disclosure | P1 | tax authority, client |
| C | director contracts, bonuses, expense policies, company-paid costs (car, housing, travel) | real resources | P2 | employer/entity |
| D Banking | bank/card/financial statements (3 yrs), all accounts incl. foreign and joint | disclosure, tracing | P1 | banks |
| D | loans, mortgages, guarantees; money transfers between spouses/entities | liabilities, flows | P2 | banks, client |
| E Property | deeds, registry extracts, leases, vehicle/vessel registers; valuations | assets, classification | P1/P2 | land registries, client |
| F Business interests (per entity) | registry extract (visura / Handelsregister / HK Companies Registry); shareholder list / register of members; articles and shareholder agreements | ownership, control | P2 | registries |
| F | acquisition / transfer / capital-increase papers; payment proof | date and funding of acquisition | P2 | notary, entity |
| F | annual accounts with P&L; profit-appropriation and dividend resolutions; shareholder-loan agreements and ledgers | profit vs distribution vs debt | P2/P3 | entity |
| F | related-party contracts; group chart; intra-group transfers | flows between entities | P3 | entity, counsel |
| G Pensions & insurance | pension statements, life/health insurance, severance (TFR) | assets, support | P2 | funds, insurers |
| H Children | school/health costs; residence and care history; communication log | arrangements, child support | P1 | client, schools |

Tiers: P1 = normally required in the proceeding; P2 = needed to prove ownership/income, request through counsel; P3 = lawyer decides after P1/P2 review (proportionality).

## Questions for counsel (general)
1. Competence and law: which court; which law governs divorce, property, maintenance, children; does 2016/1103 apply to this marriage?
2. Key dates: which dates does the court treat as decisive (separation, dissolution of community, valuation)?
3. Ownership: what do reliable registry/corporate documents show per entity?
4. Claim type: shares themselves, their value, reimbursement, or other?
5. Support: which income and benefits count, in which procedure?
6. Obtaining records: who can lawfully request what, by which route; fees; foreign-registry practicalities?
7. Foreign counsel / valuer / accountant: needed for which entity or issue?
8. Urgency: is there evidence (not suspicion) for preservation measures?
9. Children: arrangements and costs; any safety concern?
10. Settlement: which items are negotiable, in what order, with what documents attached?

### Entity-specific add-ons (examples from Rasing case)
- German company: shareholder list (GmbHG 40), accounts and appropriation resolutions (sec. 29), information route (51a-51b), German counsel for corporate questions.
- Hong Kong company: Companies Registry extracts (members, directors, annual return), local counsel, link to the German entity proven by documents only.

## Instruction to counsel
> Please assess which documents are required in this proceeding and whether further company or foreign records can lawfully be requested. Separate evidence on ownership, matrimonial-property treatment, actual personal income, and grounds for further investigation. Identify missing documents and the production route per jurisdiction.

## Research prompt (for the assistant)
> Analyse spouse rights over business interests and income in a separation involving entities in [countries]. Decide applicable law per issue, apply transitional rules, separate ownership/value/profit/dividend/pay/loans, attribute disputes, verify each legal point in a current official source. Claim no automatic half ownership, no automatic access to books, no proven concealed income. Deliver a conditional rights matrix, evidence, tiered document requests, competing explanations, questions for counsel.
