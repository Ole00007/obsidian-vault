# 05 - Rights over business interests in separation (v3): general framework

Legal information to prepare for counsel; not a determination of entitlement. Applies to any matter where a spouse holds, manages or benefits from a company, partnership or other entity. Worked example throughout: the Rasing separation (Italian proceedings; a German company and a Hong Kong company are treated as examples; their roles and any link are to be proven from registry extracts, not assumed).

## Bottom line
Marriage does not automatically give half of a company, half its profit, or access to its books. Four separate questions: who owns the interest; whether it falls in the matrimonial regime; what money claim exists without ownership; what resources count for support.

## Fixed starting points
1. Control, ownership and benefit are different: a director (e.g. German Geschaeftsfuehrer) may own nothing; an owner may not manage; a beneficiary may hold through another entity.
2. Each entity answers to the law of its own registration for corporate rights; the marriage answers to matrimonial-property law. Map both.
3. Nothing is "established" until a document shows it. Unverified items stay UNKNOWN.

## Which law answers which question
| Issue | Check |
|---|---|
| Law of divorce/separation | Reg. (EU) 1259/2010 (Rome III); Italy participates |
| Matrimonial property | Reg. (EU) 2016/1103 for marriages/choices after 29 Jan 2019 (art. 69); earlier: national conflict rules, e.g. Italian Law 218/1995 art. 30 |
| Maintenance | Reg. (EC) 4/2009, Hague instruments; excluded from 2016/1103 |
| Corporate rights | law of the entity's seat: e.g. German GmbHG; Hong Kong company law via Companies Registry records |
| Recognition/enforcement | Brussels IIb (2019/1111) inside the EU; third-state rules (e.g. Hong Kong) need counsel in that jurisdiction |
Under 2016/1103: chosen law first (art. 22); else first common habitual residence after marriage, then common nationality, then closest connection (art. 26); the applicable law governs classification, debts, powers over property and liquidation (art. 27).

## Entity-type matrix (reuse per case)
| Entity type | Ownership evidence | Profit reaches owner as | Information route |
|---|---|---|---|
| German GmbH (example) | shareholder list (GmbHG 40), notarial transfer records | dividend after resolution (sec. 29); director pay; shareholder-loan interest | shareholder rights sec. 51a-51b; court route |
| Hong Kong private company (example) | Companies Registry: annual return, register of members, directors | dividends, director fees, loans | registry search (public); members' rights per HK law via HK counsel |
| Italian S.r.l./S.p.A. | visura camerale, libro soci | dividends, compensation | Italian company-law rights; counsel |
| Partnership / sole proprietor | partnership deed, VAT/tax registration | drawings, profit share | tax records; disclosure in proceedings |
| Trust / foundation / nominee | deed, register of beneficiaries | distributions | counsel in seat jurisdiction |

## Italian anchors (counsel to verify wording)
- Default community of property dissolves on legal separation when the court authorises separate living, or when consensual-separation minutes are signed before the president judge, if approved (e-Justice).
- Civil Code arts. 177-179 (community, business assets, personal property), 191 (dissolution), 194 (division). Whether fruits, business income or business assets raise deferred-community issues is a question for counsel.
- Divorce after separation: 12 months (judicial) or 6 months (consensual) uninterrupted (e-Justice).
- Proceedings attach tax returns (3 yrs), proof of rights over registered property and shares, bank/financial statements (3 yrs) (arts. 473-bis.12 ff.).

## Decision path
1. Key dates: marriage, first common residence, acquisition/transfer of interests, separation date, filing date.
2. Law per issue (table).
3. Ownership proven by documents? If not, collect before arguing.
4. Interest inside the regime? Apply governing law to acquisition date, funding, exclusions.
5. If the interest stays with the other spouse: look for an economic route (equalisation, reimbursement, settlement).
6. Separately, build a personal-resources schedule for support.
7. Multi-entity: draw `group-chart.md`; trace money between entities (loans, fees, dividends); flag related-party flows without presuming wrongdoing.

## Vocabulary of "profit"
Turnover, accounting profit, reserves, dividend, director pay, shareholder loan, share value are different. Capital is not value; equity growth is not take-home pay; a shareholder balance is a receivable/loan, not cash; missing lines in abbreviated public accounts prove nothing. Example: a German GmbH's abbreviated balance sheet shows asset and equity movements, not salaries, taxes or revenue.

## Information rights (example: GmbH)
GmbHG sec. 29 (earnings), 40 (shareholder list), 51a-51b (information, inspection, court route). Marriage alone does not prove a 51a right; shareholder status matters. The English translation may lag; use the German text. Never access private accounts or systems without lawful authority.

## Safeguards
No double counting; children's arrangements stay separate from money bargaining; every figure traceable to a document; foreign-law conclusions come from counsel qualified there.
