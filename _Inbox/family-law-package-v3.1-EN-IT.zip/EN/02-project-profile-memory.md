# 02 - Project, profile, memory, folder stack (v3.1)

## PROJECT.md
```markdown
# Family-law case preparation
Purpose: organise lawful evidence, verify law, prepare lawyer-review drafts.
Jurisdiction: Italy; decide competence/applicable law per issue.
Language: English explanations; Italian for lawyer-facing drafts; German/other terms kept beside translations.
Authority: originals beat summaries. Disputed statements = attributed allegations.
Privacy mode: local. Real facts only in private/case-context.md (permissions 0600, git-ignored). Shared instruction files hold project code, stage, rules only.
Limits: no filing, sending, settlement, payment, deletion, or access to another person's private accounts without lawful authority and action-specific approval.
Status: every legal document is a draft until lawyer-approved.
```

## Profile description (platform-neutral)
Evidence-first family-law assistant. Organises separation/divorce material, verifies jurisdiction-specific law, reconciles finances, prepares source-linked lawyer-review drafts. Escalates uncertainty, safety concerns, external actions.
Runs on any agentic infrastructure: Hermes, Claude Cowork, Claude Code, Copilot, Lexflow Elisa, Groq Bot or any other agentic assistant's infrastructure base set-up at lawyer's preference.
Rules that travel with the profile on every platform: evidence labels, gates G0-G4, autonomy ladder L0-L3, no-external-action-without-approval.
Hermes specifics: reuse the existing profile; run automation with `hermes -p <profile>`; a profile separates config, `.env`, memory, skills, sessions, gateway but is not a sandbox.

## Memory: three layers, Markdown first
| Layer | Role | Tool |
|---|---|---|
| 1 Built-in agent memory | small, bounded: preferences, project code, index paths | Hermes `USER.md`/`MEMORY.md`; CLAUDE.md in Claude tools; the platform's own memory |
| 2 External vault (source of truth) | readable, portable, lawyer-owned: decisions, chronology, issues, entity notes, glossary | Obsidian vault, one per matter |
| 3 External recall engine (optional) | fact/entity recall across sessions and tools | Hindsight (retain / recall / reflect) |

Why external: memory survives a change of assistant (Hermes -> Cowork -> Copilot -> CRM or workflow platform), can be audited, backed up, and handed to a colleague. Built-in memory is a bounded snapshot; do not make it the only record.

### Obsidian
- One vault per matter; folder = `14-agent-ops/memory/` plus notes in the case folders. Plain Markdown with frontmatter: `type, matter, status, source, date, confidence, reviewed_by`.
- Agents reach it by MCP/CLI (e.g. the Agent MCP plugin for Claude Code/Codex, `mcp-obsidian` via Local REST API - Obsidian must be open - or Open Second Brain, which supports Hermes and Claude Code). Verify each plugin's code and network behaviour before use.
- Keep the vault on an encrypted disk. No consumer cloud sync unless end-to-end encrypted and approved by the lawyer.
- Nightly export: `MEMORY.md`, `USER.md`, `decisions.md`, open tasks -> vault. Restore = copy back.

### Hindsight (Vectorize)
- Native Hermes memory provider: `hermes plugins install hindsight`, then `hermes memory setup` (or `hermes config set memory.provider hindsight`); check `hermes memory status`; disable `hermes memory off`. Pin: `hermes plugins install vectorize-io/hindsight/hindsight-integrations/hermes --force --ref <40-char-sha>`.
- Modes: cloud, `local_external` (your server, default `http://localhost:8888`), `local_embedded` (daemon + embedded PostgreSQL in `~/.hindsight/profiles/<profile>`).
- Privacy facts from the plugin disclosure: in cloud and local_external mode every turn, and every edit to MEMORY/USER, is sent to the configured API; `local_embedded` still needs an LLM key for extraction (any OpenAI-compatible endpoint, including llama.cpp, vLLM, LM Studio), so for fully local use point it at a local model. If you point extraction at a hosted provider (e.g. Groq), case text goes to that provider.
- Control: `auto_retain` defaults to true - set it false and use tool mode (`hindsight_retain` called deliberately) for sensitive matters; use one bank per matter; keep `trusted_project_dirs` narrow.
- Outside Hermes: Hindsight also has MCP/SDK/CLI routes and Claude Code installers, so the same bank can serve several assistants.

### Memory rules
`memory.write_approval: true` where available; staged writes (`/memory pending`) are not memory until approved. Verify the entry in the same profile, then recall in a fresh session. Store no secrets, ID numbers, or allegations-as-facts. Separate matters never share a bank or vault.

## Folder stack (full menu - create only what the case needs)
```text
<matter-code>/
  PROJECT.md  README.md  glossary.md  contacts.md
  00-admin/        mandate, engagement letter, conflicts check, powers of attorney,
                   fee/costs tracker, KYC/ID copies (restricted), privacy notices, consents
  01-intake/       client narrative, goals/priorities, questionnaire, urgent-risk flags, first-call notes
  02-people/       party register, children register, third parties, representatives, witnesses
  03-evidence/
    originals/ (read-only)  extracted/  translations/ (certified vs working)  exhibits/ (numbered)
    comms-exports/ (WhatsApp, email, SMS)  media/ (photo, audio, video)
    financial/ (bank, cards, tax, payroll, pensions)  property/ (deeds, leases, land/vehicle registers)
    school-medical/ (restricted)  evidence-index.md  hash-manifest.csv  chain-of-custody.md
  04-chronology/   master-timeline.md  residence-history.md  travel-log.md  employment-history.md
  05-law/          jurisdiction-map.md  statutes/ (dated snapshots)  case-law/  court-rules-forms/
                   eu-instruments/  foreign-law-notes/  authority-log.md  freshness-check.md
  06-finance/      income-expenses.md  assets-liabilities.md  property-register.md  pensions-benefits.md
                   tax-position.md  valuations/  maintenance-calc/  scenarios.xlsx  reconciliation-log.md
  07-entities/     <entity>/ registry-extract, articles, shareholder-list, accounts, minutes,
                   loans, related-parties ; group-chart.md
  08-children/     parenting-plan-drafts  schedules  school  health  expenses  handover-log  communication-log
  09-strategy/     issues.md  options-scenarios.md  negotiation-positions.md  settlement-terms.md  risk-register.md
  10-drafts/       pleadings, replies, motions, letters, agreements; header: version | status | reviewer | date
  11-correspondence/ client  opposing-counsel  court  third-parties ; in-out-log.md
  12-procedure/    deadlines.md  hearings.md  orders/  filings-receipts/  service-log.md
  13-review-pack/  lawyer-facing bundle: index, chronology, issues, financial schedule, open questions
  14-agent-ops/    AGENTS.md  CLAUDE.md  skills/  prompts/  memory/ (vault export)  decisions.md
                   task-board.md  run-logs/  approvals-log.md  evals/  cost-log.md  access-log.md
  15-closure/      closing report, retention schedule, deletion log
```
Selection guide: minimum viable = `PROJECT.md`, `03-evidence`, `04-chronology`, `05-law`, `06-finance`, `10-drafts`, `13-review-pack`, `14-agent-ops`. Add `07-entities` when a business interest exists, `08-children` when minors are involved, `12-procedure` once proceedings are filed. Pre-create nothing empty.
