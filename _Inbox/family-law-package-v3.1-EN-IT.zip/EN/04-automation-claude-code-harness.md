# 04 - Set-up: Hermes / Lexflow-Elisa + Claude Code + Cowork + others (v3.1)

Commands come from public docs and repos; confirm with `--help`. Nothing here is installed or tested. Lexflow-Elisa and Copilot behaviours are unverified: use the portable Markdown pack and check what each platform actually reads. Terminology: Groq = inference provider (a model backend, not an assistant); Grok Bot = an assistant product that Hermes can import; "Groq Bot" in the platform sentence at the end is kept as the lawyer's wording.

## Roles
- Hermes / Lexflow-Elisa: intake, scheduling, coordination, memory, messaging gateway.
- Claude Code: bounded scripts, OCR pipelines, tests; tasks arrive as files.
- Claude Cowork (lawyer): review and approval on a shared folder; sees only `13-review-pack/`.
- Copilot, Groq Bot, others: same contract - read the pack, write to `10-drafts/` or proposed diffs, never to evidence originals.
- `legal-harness-init`: writes governed AGENTS.md/CLAUDE.md blocks; not a runtime barrier.

## Portable pack (works on every platform)
`AGENTS.md` (rules, gates, ladder) + `skills/family-law-casework/` + `PROJECT.md` + vault (Obsidian) + review pack. Map per platform: Hermes -> profile instructions/SOUL.md and skills; Claude Code/Cowork -> CLAUDE.md and plugin practice profile; Copilot -> its repository/custom-instruction file; Lexflow-Elisa/Groq Bot/other -> whatever instruction file it loads. Package as an Agent Plugins v1 folder (`plugin.json`, `skills/`, `mcp.json`) where supported.

## Hermes building blocks
- Per profile: `hermes -p <profile> cron list`, `cron doctor`, `mcp add`. MCP servers and credentials are per profile.
- `hermes import-agent` (plugin `agent-importers`): preview first, `--dry-run` writes nothing. Claude Code/Codex/Cursor: instructions -> memory, MCP -> config.yaml, skills copied, `--sync` re-imports changes. Grok Bot/OpenBot: role -> SOUL.md, memories -> MEMORY/USER, skills -> `skills/grok-bot-imports/`, scheduled routines -> paused cron jobs, event routines -> a notes file; exports carrying credential-looking keys are refused; run once per Bot into the profile that should own it.
- `delegation.backend: profile_routes` (advanced-delegation plugin): subagent runs as one of your profiles with that profile's model, skills, SOUL.md. Reuses agents; adds none. Listing a profile shares its credentials with the calling profile's subagents.
- Sandboxed terminal: `hermes config set terminal.backend bubblewrap` (Linux) or `singularity`.
- `hermes inbox` (read-only view of failed cron/stalled delegations); `hermes-telegram-business` pattern = draft to owner, Send/Edit/Discard, nothing leaves without a tap.
- Langfuse tracing: keep content capture at the sanitised default or off.

## Model lanes (provider routing)
| Lane | Use for | Not for |
|---|---|---|
| Fast (e.g. Groq, `hermes plugins install groq-provider`, `GROQ_API_KEY` in `.env`, `model.provider: groq`) | OCR clean-up, triage, summaries, translation drafts, structured extraction on non-confidential or ZDR-approved data | final legal analysis, financial conclusions |
| Deep (stronger model of the lawyer's choice) | G2 law, G3 numbers, drafts for G4 | bulk low-risk work (cost) |
| Local (Ollama / llama.cpp / vLLM / LM Studio) | the most sensitive matters | tasks needing frontier quality |
Groq data handling (vendor docs): inference requests are not retained by default; inputs/outputs may be logged up to 30 days for reliability or abuse investigation unless Zero Data Retention is enabled in Data Controls; batch and fine-tuning keep data; retained data sits in US cloud buckets. The lawyer decides per matter and records it in `14-agent-ops/access-log.md`.

## Hermes MCP bridge (`hermes mcp-serve`): exposure and safe local set-up
What it does: any MCP client you connect (Claude Code, Claude Desktop, Cursor, Codex) can list and read the active profile's messaging conversations (`state.db`), poll events, send messages as your connected platform accounts, answer approvals. `--tools` (off by default) also exposes web, browser, vision, image, skills, TTS tools under your provider credentials; terminal, file, kanban tools are never exposed. Transport is stdio.

Is local safer? Yes for network exposure, no for everything else. A local, private set-up (own machine, local memory, local server) removes: inbound network reach, third-party cloud storage of history, a shared multi-user host. It does not remove: (a) the connected client sending what it reads to its own model provider; (b) the model provider receiving prompts; (c) other programs on the same machine (any local process can reach a passwordless loopback port); (d) disk theft/malware; (e) sends as your accounts if gateway accounts are connected.

Safe set-up, in order:
1. Machine: full-disk encryption (FileVault/BitLocker/LUKS); screen lock; dedicated OS user for legal work; OS firewall on.
2. Dedicated Hermes profile for the matter; `HERMES_HOME` on the encrypted volume; `.env` permissions 600; only the keys that profile needs.
3. Connect no messaging gateway account to that profile (or use a separate bot account), so the bridge has nothing to send as. Keep `--tools` off.
4. Run the bridge only on demand, from one client config, via stdio: `hermes -p <profile> mcp-serve` (MCP client args `["mcp-serve"]`). Do not wrap it in an HTTP proxy or tunnel.
5. Check no listener appeared: `lsof -iTCP -sTCP:LISTEN -n -P` (macOS/Linux) or `netstat -ano` (Windows); stop the bridge when the review ends.
6. Model path: zero-retention, EU-region provider under a signed DPA, or a local model, for the most sensitive matters.
7. Memory: Obsidian vault on the encrypted volume, no consumer sync; Hindsight in `local_embedded` with a local LLM endpoint, or `local_external` on `localhost` only; `auto_retain` off; pin the plugin to a commit SHA; the embedded daemon is fetched with uvx on first run, so install once on a trusted network.
8. Sandbox the terminal tool (bubblewrap/singularity) and keep dangerous-command prompts on.
9. Canary test: put a unique string in a dummy matter, run the workflow, check provider logs/egress (firewall or network monitor) to confirm where it goes.
10. Backups encrypted; restore drill; logs and traces contain case text, so set retention and treat them as case files.
11. The lawyer records the provider, location and legal basis for each tool in `14-agent-ops/access-log.md`.

## Permissions (start narrow)
| Connection | Permission |
|---|---|
| Matter folder | read originals; write only derived folders |
| OCR | local first; cloud needs approval |
| Legal research | official legislation/judgments; log unavailable sources |
| Company registries | public records; fees need approval |
| Email/PEC | draft-only |
| Calendar | proposals; lawyer confirms deadlines |
| CRM / automation platforms | write only via approved webhook with a payload schema; no free-text bulk export |
| Hermes MCP bridge | off by default |

## Flow
```text
authorised file -> hash/dedupe -> OCR -> verify fields -> index diff (proposed)
-> chronology/issues update -> research changed questions only -> draft
-> G4 check -> 13-review-pack -> lawyer (Cowork) -> approved release
```
Checkpoint long jobs, cap retries, set token budgets, disable unapproved provider fallback. First cron jobs are internal only: new-document digest, missing-evidence list, deadline review.

## Order of work
1 Inventory + backup. 2 Approve capability map. 3 Licence/connector review. 4 Instructions via reviewed diff. 5 Runtime permissions + bridge checks + model lanes. 6 Evals (per model lane). 7 Enable cron. 8 Restore drill. 9 Risk re-score (file 03).

## Acceptance
Evals 1-10 pass; fresh session loads instructions; backup restores; cron runs under the named profile; canary string stays inside approved paths; no external send without approval.

---
Hermes, Claude Cowork, Claude Code, Copilot, Lexflow Elisa, Groq Bot or any other agentic assistant's infrastructure base set-up at lawyer's preference.
