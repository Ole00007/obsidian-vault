# Family-law AI package v3.1 / Pacchetto AI diritto di famiglia v3.1

13 Nov 2026 - prepared by AI engineering assistance. EN/ (6 files), IT/ (6 files), this README.

## Surgical changes v3 -> v3.1
- 02: Hindsight privacy line now covers hosted extraction providers (e.g. Groq).
- 03: R1 mitigation adds provider-side Zero Data Retention; new R16 (fast/small model, weak legal reasoning); review cadence adds "model".
- 04: terminology (Groq = inference provider; Grok Bot = importable assistant); exact Grok Bot import mapping; new "Model lanes" section (fast / deep / local) with Groq data-handling facts; order of work and evals per model lane.
- README: open points resolved. 01, 05, 06 unchanged.

## Final take - AI engineering
1. Portable pack first (AGENTS.md + skill + vault + review pack); platform second. Hermes, Cowork, Claude Code, Copilot, Lexflow-Elisa or a CRM stay interchangeable.
2. Markdown vault (Obsidian) is the source of truth; Hindsight runs local with a local model, or stays off, for sensitive matters.
3. Use model lanes: fast hosted model for low-risk bulk, stronger model for law and numbers, local model for the most sensitive matters.
4. Local is safer for network exposure only; model-provider path, local processes and disk security decide real privacy.
5. Nothing is verified until inventory, evals, canary test and restore drill are done.

## Nota finale - per l'avvocato (utente Claude Cowork)
Il pacchetto e' uno strumento di preparazione, non un parere. Condividere in Cowork solo `13-review-pack/`. Decisioni che spettano a Lei: legge applicabile al regime patrimoniale; titolarita' provata degli interessi societari; natura della pretesa; redditi rilevanti per il mantenimento; via di acquisizione degli atti (nazionali ed esteri); quali fornitori di modelli usare per quali dati (conservazione, sede, DPA); accettazione dei rischi residui da 10 in su (file 03). Nessun invio, deposito o accordo parte senza la Sua approvazione.

## Open points
Lexflow-Elisa and Copilot instruction-file behaviour: unverified. Live Hermes agents/models: unverified. Article wording: counsel to check.

Hermes, Claude Cowork, Claude Code, Copilot, Lexflow Elisa, Groq Bot or any other agentic assistant's infrastructure base set-up at lawyer's preference.
Hermes, Claude Cowork, Claude Code, Copilot, Lexflow Elisa, Groq Bot o qualsiasi altra infrastruttura di assistente agentico: la configurazione di base e' a scelta dell'avvocato.
