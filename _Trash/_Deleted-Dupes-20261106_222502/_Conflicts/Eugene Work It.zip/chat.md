# WhatsApp Chat Export: Eugene Work It
Export date: November 5, 2026 at 4:38 PM

---

## April 26, 2026

[10:37 PM] **You:** If you could do some this week, would be appreciated. I'm very short cash and I ll need to pay x dentist

[11:32 PM] **Eugene Work It:** Will try

---

## April 28, 2026

[4:32 PM] **Eugene Work It:** Mika arrived

---

## May 3, 2026

[8:39 PM] **You:** I've just controlled my b.acc.I really need some  cash, Eugene

[8:39 PM] **You:** Buon appetito

[9:46 PM] **Eugene Work It:** Will send domething tomorrow

---

## May 4, 2026

[9:22 AM] **Eugene Work It:** I just moved Eur 500 to joint acvount; i hope next week another 1000

[3:37 PM] **You:** Thank you

---

## May 27, 2026

[5:30 PM] **You:** Eugene, we can't keep living in a cold war regime... not in a real one even, please...
I want to ask you for something important, and I ask it with care, respect, and with our children in mind above all else.

What is happening between us is painful, and I know it is not easy for either of us. But even if we are no longer able to continue as a couple, we will always remain the parents of our children. That is why I believe we have a responsibility to protect them as much as we can, to protect their peace, their sense of safety, and their emotional balance.

When parents separate in conflict, children often carry the deepest wounds. I do not want them to feel caught in tension, fear, silence, anger, or loyalty conflicts. I do not want this separation to become a source of lasting pain for them, or for us. I truly believe that the way we handle this now can either protect them or hurt them.

I know that two mature people can choose a different path. Even when love changes, it is still possible to part with dignity, to remain respectful, to stay united as parents, and sometimes even to preserve a human bond based on mutual care. I would really like us to try to be those parents — the kind who put the children first, who protect them from adult conflict, and who choose cooperation over war.

For this reason, I would like to ask you to join me for a first meeting with a family mediator. Not to argue, not to revisit blame, but to find a calmer and wiser way to move forward. I hope we can do this for the children, for their protection, and also to avoid more psychological pain for both of us.

I am not asking you to solve everything at once. I am only asking you to take one thoughtful step — for the children, for their wellbeing, and for the future peace of our family in its new form.

I truly hope you will consider it... and ofcourse
let me know if you prefer to chose one yourself

thx ahead, 
still mum of your children,
Sincerely Alessis

[5:44 PM] **Eugene Work It:** The children are my greatest concern, above anything else. They are now getting involved in our conversations. I have denied last week to have a coffee with you this week because i know how you behave when you don't get things your way; you humiliate and degrade me, you put a camera on my face and send it to my family and whomever and you enjoyed inflicting this on me.

[5:45 PM] **Eugene Work It:** Also yesterday you enjoyed yourself humiliating me in front of our children by saying how 'i was crying and begging you for money'.

[5:46 PM] **Eugene Work It:** Knowing that i always paid everything...i asked you for actually very little money compared to what i always paid...

[5:47 PM] **Eugene Work It:** I therefore do not trust you or your motives

[5:47 PM] **Eugene Work It:** Its humiliating me over and over again...

[5:49 PM] **You:**
> _Eugene Work It: Also yesterday you enjoyed yourself humiliating me in front of our children by saying how 'i was crying and begging you for money'._
It was a my bad reaction to what you have said... 

And here I could say more, but what for? 

To keep throwing this dirty ball back and forth?

Shall we please get 3d party no interest help 🙏 instead

[5:49 PM] **Eugene Work It:** And if you really would have the children's position as a priority, you would not behave the way you do

[5:51 PM] **Eugene Work It:** Its very simple; option 1) you stay in the house and i leave, 2) i stay in the house and you leave, 3) we both leave.

[5:51 PM] **You:** Could you please do all of us a favour: choose mediator (lawyer/ phsicologist)

[5:52 PM] **You:**
> _Eugene Work It: Its very simple; option 1) you stay in the house and i leave, 2) i stay in the house and you leave, 3) we both leave._
Ok. But we still need 2 agree on this and put detail on paper.

[5:53 PM] **Eugene Work It:** We agreed a few months ago that within 4 to 5 months we should split houses. That should be within 2 months. Which means that we both need to have some kind of income or sell assets.

[5:53 PM] **You:**
> _You: Ok. But we still need 2 agree on this and put detail on paper._
Needs 2 b done in any case.

[5:55 PM] **Eugene Work It:** And my company and me as a person are in debt with others..i have nothing left. You can get via your lawyer a judge approved investigation of all my finances to see if i'm not 'hiding money'...and i will do the same. I'm living in debt

[5:56 PM] **Eugene Work It:** In 2 months we should be living seperately and should be fully independant from each other.

[5:57 PM] **Eugene Work It:** I will however assume all costs for the children, then at least i'm sure that they will get what they need.

[6:00 PM] **Eugene Work It:** Further, some people have reached out to me, that you are bad mouthing about me. Among other issues, this is now all documented. I'm ready to take it to trial.

[6:03 PM] **Eugene Work It:** I will think about a mediator.

[6:06 PM] **Eugene Work It:**
> _You: Eugene, we can't keep living in a cold war regime... not in a real one even, please...
I want to ask you for something important, and I ask it with care, respect, and with our children in mind above all else.

What is happening between us is painful, and I know it is not easy for either of us. But even if we are no longer able to continue as a couple, we will always remain the parents of our children. That is why I believe we have a responsibility to protect them as much as we can, to protect their peace, their sense of safety, and their emotional balance.

When parents separate in conflict, children often carry the deepest wounds. I do not want them to feel caught in tension, fear, silence, anger, or loyalty conflicts. I do not want this separation to become a source of lasting pain for them, or for us. I truly believe that the way we handle this now can either protect them or hurt them.

I know that two mature people can choose a different path. Even when love changes, it is still possible to part with dignity, to remain respectful, to stay united as parents, and sometimes even to preserve a human bond based on mutual care. I would really like us to try to be those parents — the kind who put the children first, who protect them from adult conflict, and who choose cooperation over war.

For this reason, I would like to ask you to join me for a first meeting with a family mediator. Not to argue, not to revisit blame, but to find a calmer and wiser way to move forward. I hope we can do this for the children, for their protection, and also to avoid more psychological pain for both of us.

I am not asking you to solve everything at once. I am only asking you to take one thoughtful step — for the children, for their wellbeing, and for the future peace of our family in its new form.

I truly hope you will consider it... and ofcourse
let me know if you prefer to chose one yourself

thx ahead, 
still mum of your children,
Sincerely Alessis_
This message is purely written to 'demonstrate'  to others that you are the 'voice of reason', the  calm adult who tries to settle things quitely'

[6:08 PM] **Eugene Work It:** In reality; they way you act aggressively, humiliate me at each single issue, demonstrates that you not all trying to find a calm & reasonable solution.

[6:10 PM] **Eugene Work It:** Like i said; i will think about a mediator.

---

## June 7, 2026

[9:04 PM] **You:** Hi! How's it going?
RE::Plan next week, i'd like to take MON, Tue, Sat.

Then we'd need to fill in the Campo x Mika. Decide Dani June-mid July 

Rest x summer 

Start talking bout our settlement

[9:15 PM] **Eugene Work It:** Ok, then i will take the kids wedn, thursd, friday. FYI: Mika plays wednesday in Bergamo

[9:15 PM] **Eugene Work It:** You have plans for summer?

[9:20 PM] **You:**
> _Eugene Work It: You have plans for summer?_
No. 
I keep asking you to fix some x u, some x me with them

[9:20 PM] **You:** It needs to be planned

[9:21 PM] **Eugene Work It:** What is 'x'?

[9:21 PM] **You:** For/ with

[9:22 PM] **Eugene Work It:** Ok

[9:23 PM] **Eugene Work It:** I'm thinking about some weekends with them, perhaps a week.

[9:23 PM] **Eugene Work It:** And i need with Dani to Rome for new passport soon

[9:30 PM] **You:** We need to talk about concrete dates. Both Centro estive and trips

[9:31 PM] **Eugene Work It:** Ok, please go ahead

---

## June 21, 2026

[11:13 PM] **Eugene Work It:** I have enough of your aggressive attacks; the continuous shouting and verbal abuse is to much to handle. For the kids this is also unbearable.

[11:14 PM] **Eugene Work It:** We agreed in March that we both would need 4 to 5 months to get our business in order to both generate some money so we could live in separate houses.

[11:15 PM] **Eugene Work It:** So at the end of July we agreed to be separated and living in different houses.

[11:19 PM] **Eugene Work It:** Choice is as following; or you take over the rent in our current apt and i will look for another apt. Or the other way around. That decision needs to be taken soon in order for the other to have sufficient time to organise his/her apt.

[11:20 PM] **Eugene Work It:** I can of course at any time cancel the contract in this apt and organise my own apt for myself and the kids

[11:21 PM] **Eugene Work It:** You work more hours than i do; you can take care of yourself.

---

## July 9, 2026

[8:35 AM] **You:** [Forwarded] /9j/4AAQSkZJRgABAQAASABIAAD/4QCMRXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAAGSgAwAEAAAAAQAAAGQAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/AABEIAGQAZAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2wBDAAYGBgYGBgoGBgoOCgoKDhIODg4OEhcSEhISEhccFxcXFxcXHBwcHBwcHBwiIiIiIiInJycnJywsLCwsLCwsLCz/2wBDAQcHBwsKCxMKChMuHxofLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi7/3QAEAAf/2gAMAwEAAhEDEQA/APpaIHGfWnMxXtxVaKJWUv8ANg/dGT0/+vT1hRxxkepLHA/Ws92UTYDrk9KYNgOVOPammBNu5WLAdeSCP/rU1YBnnOP940W7gOOCcnvwaVHDRtED8y/MP61AIVdyACQo9SRmpwEhwR1HaoahG9yrtkCiRugC5/iPJq6W3bZP745+oqGRQBx9w8r/AIUsJDAxevKn0P8A9eopuz5GVJXXMY+rLDEyTeXljkf7Prz6msfy5Jf387bVP8Td/oO9dbcR+dAygAsOQGGQGFcrLDKHL3jbfryT9B/kV7OEqXjy9UeBj6LU+a2j+75jDMIwVtxtzwWP3j/h+FQAEnAGTTgnG5ztX9T9BQX42oMD9T9a60+kTzmus/uDYo4ZsH0AzRtj/v8A6UyinyvuTzx/l/P/ADP/0PphdzEj7qr1PpTJHAACjCfz+tJKxwMDEY7DqPc0yeHKKrsfUr7e59//AK1SvIYQXSTxu8YOc7efQUr5Rdyd+APc1KuxAFHGahDB28xuV6L/AFNTcY5f3ahCevcVy/iTWX0uGGOFlSa6kEayScpGP4nPrjNdNjjc/TsK5bxVoUuv2aR2uBPCS0YPAIPUZ7fWuGs5O/Lueplqo+3h9Y+Hr/Xqee3PiXXNH1WSFdQF9HGw54Mb9+PT04NezWE8V5aw369JlWRVHXnnn6V4Pa+E9aubtrRofK8tgJGYjC557Hnj0r220uLXTrSLTonH7lAise2BU4KE3Jua08z1+I3hFCnHDtOfVq23nbQ2nBYErgyY+ZM9ayLqyWRGnG0ydSTnAAHQCpY5w/KnkfpWgrebyOH7js3/ANevUjJp3R8hOCkrM4QsWO5jk0BS3T8T6VtXlgBP52MRkksBwRx0x71jM27gcL2FexCqpr3D5qrQdJv2n/Di5QcBd3uaNy/3B+ZpAjsMqCRS+XJ/dNVaPV/iTzT6R/A//9H6XRSAQ3Sn8vhSfmH3T6+xqISdm4owF4Y5zWZREwLZVs56H1pFymFkHbj0NW8Fz/00A4/2h/jUQUyqVbgdz6f/AF6r0ENCNKcd/wCVSjj91B36t6//AFqa7/LtjGE7+p+tHCQs/TdhR/Wkoq9x3drHOT70lvPIOSGTJ9torC+x3Esm4AkNyMfrW1DcFtRnCLvRmGSD/s1vQIY1HlqFGc46mqbEU9OtHRAsrAOOmf5GtCRSh+YFf8fY1JtgGWzkH+Ef1qcO+N0gAToFx1oAgOJgN52uOj9vxrNm0lZH+cCM/wB4fdP1FaxClVZIgQRz7H0xRvuOAqFQOwH+NVGTi7xZnOnGatNXOcfRL4t8pRh2IOKZ/Yl/6L/31XRNKinDRnPsSB+VJ58X/PNv++v/AK9brFS7I5XgKb6v7z//0vpdsTLvX7w6gd/cU0bThc5PY0FWiIZDkH7pFSCNZB5xyo7gf0qWrjEQFhljhVP3v6Ch5GlYcfL6UhPmctwo6ChmCjApX6IBoVVb587e+KdPPHIBDgYbjBxz+FZk18FzHEN7H8hWS8k3mCRydw5Ga56mJUdFqZTqpbFq1tdRivriW4WIQyMChVmLccDcCABx7nmt5Y3xuchQe5qKKcTRxyqQCT+tWcZO48n1NbqSauarXYRdq/6sc/3m/oKYBIzbmNKX+bbilZtozQ2xilecqSp9qacjlnP507OV3k7EHVj/AEpkUqvloMAdMkZNCdt2K5dgy0YL89evpUuB6VQILcsST9aTYPU/marmQWP/0/pePhWaXHlt0Hqfanb2kIZPlde3Yj2pjN5g8x+fQelNmmigge4mOxI1Ls3oFGSanmHYftEg3Rjp1T/CqktvdXGPMPkxj7xJGa80ufiVYXVzbtapcIEkO9VVczDoozu+XnkjqeBWvrWrX8HiO009/ltpolMgf7yvIxVSTnpkAenNRUWmxMtjt4FRBt09AfWV+n4etR30bXipHD+8kU/M4GB+dcdqviKe01XTdBUFE8xRdcfwuTsUe5wTWlB4r06+vksITJBbtIYll8thG7jjaH6ZJqLxceXuRo1Y1BpN4mGVl3KcgA81pwyvIPnGCOGHoa5BvG/huGR8RTeXDIY3mVG2owOPmbsM1oXHi3So57hNszPBjzBHEz7VK5DsV424PWiEIR+AdNJPQ6RiFGe9RkoiG4m+6Og/vGsO48SaXCYkDPcGWPz8W6GQiL++cdAaH1GHU447i0YNbsoMZHQj1oqVFTjcqpPlQ+4uZLhsucKOijoKtadv3Nx8uP1qKC3e5CgJtRerdM/jT2uZYy0RxGqn5cc5H6fzrmpwk5e1mzGC155MLyedJyqkqMDGKrfabj++auC/iAAMW8j+JjyaX+0If+fdaJcrd/aDbV/iP//U+jv9Mc7gqxjsGOT+nFSXVsl5aS2k/wB2aNo2x6MMHFWKTJz7Vm5X6BGNup88n4deKYrgiGOMiOQBH8wDIB4fHXHf1r1W80C71G/kjvG3pLpy24m4BE6vvDAdRgjNdiQSQc8U9OZV/E/pTTGeR/2Tq8rW95qKqb5r5J7nBGFSNSigc8gDsPWqtnpWtTXFvHfRu0iXcckkrXA8oor5+SMHAwPUZHau7kV1meWRSNxOM/WkggkupRHGOT1PpXmxqSVTRHGpvmOJsLHVZtI1LTbS0SZbq7uY1uDIAsYL4Ysp5JHUYzWhZz6ppt5rNvp9qLwloYQd4QhxCACwbquOuOfzr0m0gtrNGhhJZcncABt3Hr+NVmsDLI00e2M5wPViPUjqccV32tH3UdS0WiPI4fDl/pTxsIpLsNbxxt5M5hKyJnryMqc/h6V33hvTntrSC02rD5akuqsXVckkgFuT1q7OkqSkTDDGrmnyhQ8Xlly/pXDTvKryzOeOsrMvSzxJGSeI06Ad6wJ7hZZC6ggHHFamrSQLEtuFHmcE47VgVWLneXIFaevKibzB6UeYPSoaK4zG5//V+lQS2Qe1SKMKBUa9W+lSjoKy6FCKMUp9QcEdDQKKOoAFFwWgn+dcZ561Vuo00+zb7MNpY4Ld6t2/+vP+7/WoNX/48/xFOa0b6mcu5FbfJDEq9wCfqamY5hXP99h/OoYP9XD/ALoqU/6gf77f1pU/hRS2Q+JvMbypQHAGRuGTTmbbJ5EYCLjPyjBpkH+vP+6KV/8Aj6P+6K06AcxcrsuHUEnB6nrUFWbz/j6k+tVq8SW7OCW4UUUVIj//2Q==: Location: 44.328834533691406, 9.212422370910645 — https://maps.google.com/?q=44.328834533691406,9.212422370910645

[9:56 AM] __[Call]__

---

## July 23, 2026

[3:21 PM] __[Call]__

[7:38 PM] __[Call]__

---

## July 24, 2026

[1:10 PM] __[Call]__

---

## August 21, 2026

[3:54 PM] __[Call]__

---

## August 24, 2026

[7:37 PM] __[Call]__

---

## September 6, 2026

[11:17 AM] **Eugene Work It:** [Video]

[11:19 AM] **Eugene Work It:** [Video]

[11:20 AM] **Eugene Work It:** [Video]

[11:21 AM] **Eugene Work It:** [Image]

[11:21 AM] **Eugene Work It:** [Image]

[11:21 AM] **Eugene Work It:** [Video]

[11:23 AM] **Eugene Work It:** [Image]

[11:23 AM] **Eugene Work It:** [Image]

[5:22 PM] __[Call]__

[8:07 PM] **You:** Thanks☺️

---

## September 7, 2026

[6:40 PM] __[Call]__

---

## September 8, 2026

[3:28 PM] **You:** [Image] They called me. I think you should open the door when the bell rings these days

[3:29 PM] **Eugene Work It:** Ok, tnx

[3:29 PM] **Eugene Work It:** But only early in the morning the doorbell rang

[3:34 PM] **You:** And there was a call

[3:34 PM] **You:** To me but I had a phone on silence

[3:34 PM] **Eugene Work It:** I will open in any case the door will ring

---

## September 9, 2026

[12:04 PM] **You:** [Forwarded] [Document] lettera Rasing-Rasing.pdf

[12:04 PM] **You:** Hi, Eugene! How are you? I'd like to inform you that you should receive a "recommandata" - a latter inviting you for negotiation. Please let me and/ or avvocato  know

[12:18 PM] **Eugene Work It:** Ok, duly noted. Lets proceed with legal divorce in Russia as well.

[12:32 PM] **Eugene Work It:** Kids will be thrilled....

[5:03 PM] **You:** [Video]

[5:04 PM] **You:** [album message]

[5:04 PM] **You:** [album message]

[5:04 PM] **You:** [Image]

[5:04 PM] **You:** [Image]

[5:04 PM] **You:** [Image]

[5:04 PM] **You:** [Video]

[5:04 PM] **You:** [Video]

[5:04 PM] **You:** [Video]

[5:04 PM] **You:** [Video]

[5:04 PM] **You:** [unknown message]

[5:04 PM] **You:** [unknown message]

[5:04 PM] **You:** [unknown message]

[5:40 PM] **You:** Neighbours seam to be leaving...

[5:40 PM] **Eugene Work It:** Ok, that might create a possibility

[5:41 PM] **Eugene Work It:** Thank you for vids,

[5:41 PM] **You:** Sure

[5:41 PM] **You:**
> _Eugene Work It: Ok, that might create a possibility_
Let's keep an eye for this

[5:42 PM] **You:** If you happen to talk to a LL. 2 estimate  costs

[5:43 PM] **Eugene Work It:** I never see / talk to her, but i can ask

[5:43 PM] **You:** Better ocasionally

[5:44 PM] **You:** Let's try 2 c her within a couple of days

[5:44 PM] **You:** If not then just straightly ask

[5:48 PM] **Eugene Work It:** Ok, will try

[6:11 PM] **You:** [Video]

[6:15 PM] **You:** [Video]

---

## September 10, 2026

[12:15 AM] **You:** [Forwarded] [Video]

[6:26 AM] **You:** [Video]

[5:47 PM] **You:** [Video]

[6:32 PM] **Eugene Work It:** Uh oh.....

---

## September 11, 2026

[1:14 AM] **You:** _You deleted this message_

[2:54 PM] __[Call]__

[7:40 PM] __[Call]__

---

## September 16, 2026

[4:24 PM] __[Call]__

[7:33 PM] __[Call]__

---

## September 19, 2026

[1:36 PM] **You:** Are you still here ?

[1:43 PM] __[Call]__

[2:07 PM] __[Call]__

---

## September 21, 2026

[10:16 AM] __[Call]__

[7:32 PM] __[Call]__

[7:41 PM] __[Call]__

---

## September 24, 2026

[9:17 AM] **You:** Ps, let me know, if you and/or your lawyer have intention to start negotiating.  Thanks ahead

[10:09 AM] **You:** Or should I rather ask "when" instead of "if"?

[11:46 AM] **Eugene Work It:**
> _You: Ps, let me know, if you and/or your lawyer have intention to start negotiating.  Thanks ahead_
I replied to your lawyer yesterday morning

[12:35 PM] **You:** By email? 

I would appreciate you to keep me posted 

I do it to you

At least the min communication from your side to me as well, please 

Thx

[12:36 PM] **Eugene Work It:** In the letter from your lawyer it asks me to reply to his email, which i did. I assumed he would let you know

[12:39 PM] **Eugene Work It:** Dear Mr Romanelli,

 

With reference to your letter dated 7 September 2026 concerning the divorce between Mrs Olesia Rasing and myself, I confirm that I am willing to seek an amicable solution.

 

I would be available for a first discussion during the week of 5–9 October, preferably in the morning. Please let me know which day and time would be convenient.

 

Kind regards,
Eugene Rasing

[12:39 PM] **Eugene Work It:** And he literally just replied;

[12:39 PM] **Eugene Work It:** R: Divorce Eugene & Olesia Rasing
Dear Mr Rasing,

 

thank you for your message. I am pleased to note your willingness to reach an amicable solution.

I must clarify, however, that I act exclusively in the interest of Mrs Olesia Rasing. Under the Italian rules of professional conduct for lawyers I am not able to act for you as well, nor to discuss or negotiate the terms of the separation directly with you.

 

In particular, I cannot assist both spouses. This matter did not arise as a joint intention to separate on terms already agreed between you, but as a dispute between opposing positions; a single lawyer acting for both parties is therefore not permissible here.

 

This does not prevent an amicable outcome. A consensual solution remains fully possible, provided that you are assisted by a lawyer of your own choice. I therefore renew the request set out at the end of my letter of 7 September 2026 and ask you to appoint a lawyer without delay.

 

If it is of assistance to you, I can provide you with the names of lawyers practising in Genoa, from whom you would of course be free to choose; any lawyer so indicated would act independently and exclusively in your interest.

 

As soon as your lawyer contacts me, I will be glad to arrange a first discussion.

 

For clarity, I would add that my letter concerned the judicial separation of the spouses (separazione personale dei coniugi), which under Italian law is a distinct step preceding divorce.

 

Kind regards,

 

Enrico Romanelli

[12:41 PM] **Eugene Work It:** So now i need to spend money on a lawyer

[12:43 PM] **You:**
> _Eugene Work It: So now i need to spend money on a lawyer_
Thanks for the mails copies. 
 
As we both well aware i have proposed you millions of times to avoid this. 

The decision is yours

[12:48 PM] **Eugene Work It:** Next week i have to travel for work, so the first meeting will be after that.

[12:56 PM] **You:** Ps, pensil the calendar in and kindly answer on other questions in the Practical chat

[12:57 PM] **You:**
> _Eugene Work It: Next week i have to travel for work, so the first meeting will be after that._
Indicate what sort of meeting you intend

[12:58 PM] **Eugene Work It:** Well, the meeting of the lawyers

[2:07 PM] **You:** Ok. Let's keep each other posted

---

## September 25, 2026

[11:36 AM] **You:** Would you (or your lawyer), please, share the date/of your lawyer contacting mine? 

To avoid starting a court procedure

[11:37 AM] **Eugene Work It:** That will be next week

[11:38 AM] **Eugene Work It:** If you want to start court procedure...pse go ahead

[11:38 AM] **You:**
> _You: Thanks for the mails copies. 
 
As we both well aware i have proposed you millions of times to avoid this. 

The decision is yours_
You know the answer

---

## September 28, 2026

[4:58 PM] **You:** Can you please tell me where you have found a form to subscribe Mika to Let. I ll forward to another mum, who's asked me

[8:56 PM] __[Call]__

---

## October 10, 2026

[11:01 AM] __[Call]__

---

## October 12, 2026

[9:37 AM] __[Call]__

[12:12 PM] __[Call]__

---

## October 13, 2026

[12:29 PM] __[Call]__

[12:30 PM] __[Call]__

---

## October 15, 2026

[4:50 PM] **Eugene Work It:** FYI; my lawyer contacted your lawyer yesterday

[7:36 PM] **You:** Thanks

---

## October 19, 2026

[3:50 PM] __[Call]__

[3:55 PM] __[Call]__

---

## October 23, 2026

[7:43 PM] __[Call]__

---

## October 28, 2026

[7:21 PM] __[Call]__

---

## October 31, 2026

[4:01 PM] __[Call]__

[4:02 PM] __[Call]__
