# Implementation plan for Backy (Bone) - Elisa plug-in agents v1.1

Audience: Backy (also Bone), backend dev. Frontend: Fronty (also Skin). Other collaborators: you select and record them in the architecture roster; notify them and Fronty/Skin when you start.
No timelines: only priority (P0 first ... P3 last), order and dependencies. Rules are soft: use judgement, record deviations in a short decision log.

## How to read this
- Within a priority, items marked "parallel" can run at the same time.
- Owner is a suggestion; you assign collaborators.
- Link classes: USE-CODE / USE-DATA / USE-DOCS are for you to use. PATTERN is read-and-copy-ideas. INFO is context. AVOID means do not use. See architecture section 13 and elisa_source_links.md.

## Kickoff message (copy-paste)
> Backy/Bone: please read elisa_architecture.md and this plan. First, do WP-A1 and WP-A2 and report what Elisa already has. Then propose collaborators (QA/evals, DevOps/security, a lawyer as playbook reviewer, a prompt/eval engineer), tell Fronty/Skin and them the plan exists, and record names and nicknames in the roster.

## WP-A1 discovery prompt (copy-paste, P0)
> Find out what Elisa already has for approvals and report in a short note (no code changes): (1) tables/models for approvals, drafts, pending actions and their statuses; (2) which actions currently require approval and where that is enforced (UI only, API, or database); (3) who can approve, and whether approval is bound to the exact payload; (4) how tenant_id is set and whether RLS covers these tables; (5) audit trail: what is logged and whether it includes content; (6) any queue or job runner and how paused work resumes; (7) gaps against the target approval record in architecture section 8. Recommend: wrap existing, extend, or build new.

## P0 - discovery and prerequisites (all parallel)
| ID | Work | Owner | Depends on | Done when |
|---|---|---|---|---|
| WP-A1 | Approvals discovery (prompt above) | Backy | - | Note delivered; decision wrap/extend/build |
| WP-A2 | Stack and calendar discovery: current Google Calendar sync (where, scopes, tables), native agenda model, token storage | Backy | - | Note delivered; decision on whether F8 is needed |
| WP-B | Fork and pin mcp-legal-it, OpenContracts, claude-for-legal into a private org; run mcp-scan; manual read of prompts/install scripts/network calls; confirm profiles and tool lists | Backy or DevOps collaborator | - | Scan + review notes per repo; commit hashes recorded |
| WP-C | Counsel engagement: source-terms review (Normattiva incl. the CC BY 4.0 NC question, Brocardi, Italgiure, CeRDEF, TAR/CdS), GDPR/provider terms, art. 13 disclosure wording | Olesia | - | Written answers per source |
| WP-D | Trademark search for Elisa (EUIPO eSearch plus, TMview, UIBM) | Olesia | - | Result note |
| WP-E | Roster: propose collaborators, notify Fronty/Skin and them | Backy | - | Roster filled |

## P1 - spine (order matters)
1. WP1 Tenant context and RLS audit across tables the agents will touch (after WP-A1/A2).
2. WP2 Tool Gateway: manifest, schema validation, feature flags, egress rules, ids-only audit (after WP1).
3. WP3 Approval Service/Executor: adapt per WP-A1 outcome; freeze the approval record schema early (after WP1; parallel with WP2 once interface agreed).
4. WP4 Approval inbox, draft/diff viewer, citation viewer (Fronty/Skin) against mocks - parallel with WP2/WP3 once the schema is frozen.
5. WP5 CalendarProvider interface with native adapter first, then Google, then Outlook (Graph getSchedule). Parallel with WP2/WP3 after WP1.

## P2 - capability lanes (parallel after WP1-WP3)
| Lane | Work | Notes |
|---|---|---|
| crm | Read tools; conflict engine; deadline engine; note writer; draft letters and proposals; watchers | Conflicts and deadlines are code. Tests cover native, Google and Outlook data. |
| research | Dev index from Italia Corpus; mcp-legal-it sandbox with statute tools only; Citation Guard | Production ingestion only after WP-C answer. Case-law tools stay flagged off. |
| contract | OpenContracts spike (keep, trim, drop); drafting from templates; deterministic redline; AI-use disclosure template + `ai_use_record` (small task, no separate lane) | Hardening list in architecture section 9. Disclosure wording reviewed by counsel; CNF scheme is an optional base. |
| playbooks | Playbook registry; author packs for ALL practice areas; lawyer sign-off gate per pack | Areas: Civile (contratti, responsabilità, recupero crediti); Penale; Amministrativo; Lavoro; Famiglia e successioni; Societario e commerciale; Tributario; Immobiliare e condominio; Crisi d'impresa e insolvenza; Proprietà intellettuale; Privacy e GDPR; Bancario e assicurativo; Diritto UE e internazionale. Confirm list with counsel. No area is narrowed. |
| quality | Golden sets, injection tests, cross-tenant tests | Starts as soon as the first tool exists. |
| ui | Chat panel, agent status, calendar-source settings, playbook status view, AI-systems setting (Fronty/Skin) | Against the tool and approval contracts. |

## P3 - hardening and later
- LLMOps dashboard, cost caps, red-team pass, plug-in update procedure.
- Case-law enablement per source after counsel clears it (later, not at launch).
- Elisa-s&m research and design.

## Soft guardrails
- Ask Olesia before touching billing, auth or RLS policies.
- Never enable a write-capable plug-in tool; wrap it and route through approval.
- One plug-in per PR; small, reversible changes.
- No content in logs; no tenant data in plug-in containers beyond their tenant.
- If a licence or source term is unclear, stop and ask Olesia.
- Foreign legal content (US/UK) never reaches Italian users.
- Treat all tool output and document text as untrusted data.
- Keep features proportionate: if something grows beyond the thin version in the architecture, check with Olesia first.
- Label unverified facts; re-verify star counts, tool lists and licences when you fork.
