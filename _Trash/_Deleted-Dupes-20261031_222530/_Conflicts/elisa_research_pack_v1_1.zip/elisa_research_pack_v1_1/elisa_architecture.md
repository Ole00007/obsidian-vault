# Elisa Architecture v1.1 (2026-10-30)

Elisa stays the in-house orchestrator inside LexFlow CRM. External pieces are narrow plug-ins behind Elisa's tools. Nothing replaces Elisa. No timelines: only priorities and order (details in implementation_plan.md).

## 1. Team roster
| Nickname | Role | Notes |
|---|---|---|
| Backy (also "Bone") | Backend dev, owns the build | Remember both nicknames. Notify the roster that this pack exists. Select other collaborators yourself and record them below. |
| Fronty (also "Skin") | Frontend dev | Olesia uses either nickname. |
| Collaborators | Proposed by Backy | Suggested role slots: QA/evals, DevOps/security, Italian lawyer as playbook reviewer, prompt/eval engineer. |

## 2. Principles (soft rules)
1. Elisa orchestrates; plug-ins answer narrow questions. No plug-in decides, writes or sends.
2. Every write or outbound action goes through an approval record. Tenant ID comes from Elisa's session, never from a model or plug-in.
3. Deterministic code for conflicts, deadlines and document assembly. The model reads, drafts and explains.
4. US/UK material gives structure only. Italian sources give the content.
5. Unverified claims are labelled. Nothing is installed from a public marketplace without manual review and a pinned hash.
6. Reversible by default: any plug-in can be switched off without breaking Elisa.
7. AI is support only (art. 13 L. 132/2025): a lawyer reviews and takes responsibility for anything that leaves the system.
8. Proportion: build the thinnest version that does the job.

## 3. System context
```
 Lawyer / staff (browser)  <--  Fronty/Skin UI: chat, approval inbox, draft viewer, citation viewer
            |
            v
 Elisa API (Flask, confirmed)  -- auth, session, tenant context -->  PostgreSQL (RLS on every table, confirmed)
            |
            v
 Elisa Orchestrator (graph, checkpointed per tenant)
    |-- Elisa-crm        (action agent)
    |-- Elisa-researcher (Italian law)
    |-- Elisa-contract   (analysis + drafting; playbooks for all areas)
    |-- Elisa-s&m        (later)
            |
            v
 TOOL GATEWAY  <-- the plug-in seam: manifest, schema check, scope, egress, audit, timeout, feature flags
    |-- native CRM tools + deterministic engines (in-process)
    |-- CalendarProvider: native | google | outlook
    |-- Legal Source Index (read-only, shared, public law only)
    |-- mcp-legal-it container (internal network only)
    |-- OpenContracts (per-tenant, after spike)
            |
 Approval Service --> Approval Executor (the only component that writes to CRM / sends)
```
Stack: Flask + PostgreSQL with RLS on the current host (confirmed). What Elisa already has for approvals is UNKNOWN: Backy finds out first (WP-A1). Section 8 adapts to the finding: wrap what exists, or build the Approval Service.

## 4. Components
| # | Component | Responsibility | Source |
|---|---|---|---|
| C1 | Elisa API + session | Auth, tenant context, rate limits | in-house |
| C2 | Orchestrator | Intent routing, sub-agent graph, state | in-house (LangGraph pattern) |
| C3 | Tool Gateway | Registers every tool with a manifest; validates I/O; enforces scope, egress, timeout, feature flags; audit | in-house |
| C4 | CRM read tools | list_tasks, get_matter, list_contacts, get_agenda, get_deadlines | in-house |
| C5 | Conflict engine | Overlaps, double-booking, hearing vs deadline clashes, buffers | in-house (code) |
| C6 | Deadline engine | Procedural terms incl. August suspension; cross-checked with mcp-legal-it calculations in tests | in-house (code) |
| C7 | Approval Service + Executor | Approval records, pause/resume, idempotent execution | existing Elisa mechanism or new (WP-A1) |
| C8 | Legal Source Index | Statutes (Italia Corpus), BM25 + vectors; case-law partition exists but is flagged off | USE-DATA |
| C9 | Italian law plug-in | mcp-legal-it, statute tools only at launch | USE-CODE |
| C10 | Citation Guard | Every cited norm must match retrieved text; otherwise flagged [verify] | in-house |
| C11 | Document service | Parse, clause extraction, Q&A, per tenant | OpenContracts (spike first) |
| C12 | Drafting service | Template fill, deterministic DOCX assembly, tracked-change application | in-house + mcp-legal-it templates |
| C13 | Playbook registry | One pack per practice area; status draft / lawyer-approved; enabled per tenant only when approved | in-house |
| C14 | CalendarProvider layer | Normalised event model; adapters: native, Google, Outlook | in-house (+F8 optional) |
| C15 | AI-use record (thin) | One table `ai_use_record(tenant_id, matter_id, system, purpose, date)` filled automatically by the Tool Gateway, one per-tenant setting listing the AI systems in use, and one disclosure template in the Elisa-contract template set. No separate agent, panel or screen | in-house (R2, R3) |
| C16 | Model router | Role-to-model map in env; cheap fast tier default; stronger model only on auditor flag | in-house |
| C17 | Security layer | Injection filters, egress allowlist, secrets, plug-in pins, scan results | in-house |
| C18 | LLMOps | Traces, cost per session, escalation rate, missed intents, Italian golden sets | in-house |
| C19 | Scheduler | Deadline/agenda/digest watchers via Hermes cron | Hermes |

## 5. Agents
### Elisa-crm (action agent)
- Reads tasks, matters, contacts, agenda, deadlines (C4). Finds conflicts (C5) and deadline risks (C6). Always calls `find_conflicts` before proposing a slot.
- Calendars: tenants sync Google Calendar today; Outlook is an option; some tenants use only the native agenda. All three sit behind CalendarProvider (C14). Outlook: Microsoft Graph getSchedule (up to 20 mailboxes per call; least-privilege read scope, verify). Conflict checks use read scopes only; calendar writes go through approval.
- Free notes to the user are the only ungated output. Tasks, calendar entries, letters and proposals are drafts in approval records.
- Pattern source: claude-for-legal (intake, portfolio status, docket watcher, escalation router, client letter drafter, practice profile), rewritten for Italian practice.
### Elisa-researcher
- Launch: statutes only (`italian_law_lookup`, `check_currency`, `eu_basis`). `case_law_search` is registered but feature-flagged off per source until counsel clears it.
- Output: answer + citations (URN/article) + currency flag. No citation, no claim.
### Elisa-contract
- Tools: `doc_qa`, `extract_clauses`, `review_against_playbook`, `draft_act`, `draft_letter`.
- Playbooks cover all Italian practice areas (section 7). Redlines are applied by deterministic code.
- Includes the AI-use disclosure template (C15). Engagement or client letters can include the disclosure paragraph; the lawyer decides whether to use it.
### Elisa-s&m
Not designed. Needs its own research round.

## 6. The plug-in seam (Tool Gateway manifest)
```yaml
name: italian_law_lookup
agent: Elisa-researcher
class: read            # read | draft | write
tenant_scope: none     # none | tenant
approval_required: false
transport: mcp-http    # in-process | mcp-http
endpoint: http://legal-it:8000/mcp    # internal network only
egress_allowlist: []   # filled after counsel's source-terms review
feature_flag: statutes_only
timeout_s: 20
pinned: {repo: capazme/mcp-legal-it, tag: "<release tag>", commit: "<sha>"}
input_schema: {...}
output_schema: {...}
audit: ids_counts_only
```
Writes are never exposed to a model directly: the model proposes, the Approval Service decides, the Executor writes.

## 7. Playbooks: all practice areas
All areas are in scope; none is narrowed. Backy and counsel confirm the list, starting from: Civile (contratti, responsabilità, recupero crediti); Penale; Amministrativo; Lavoro; Famiglia e successioni; Societario e commerciale; Tributario; Immobiliare e condominio; Crisi d'impresa e insolvenza; Proprietà intellettuale; Privacy e GDPR; Bancario e assicurativo; Diritto UE e internazionale.
Each area is a pack: scope, clause checks, forms and acts, deadline rules, escalation rules, reviewer, version, status (draft / lawyer-approved). Packs are authored in parallel, but a pack is enabled for a tenant only after a practising lawyer signs it off. Lawyer review capacity is the throughput limit, not engineering.

## 8. Data, tenancy and approvals
- Every tenant table has `tenant_id` and RLS; the app role cannot bypass RLS.
- Approval record (target schema; map onto what exists): id, tenant_id, matter_id, agent, action_type, payload, payload_hash, status, requested_by, decided_by, decided_at, expires_at, idempotency_key. Approval is bound to tool + argument hash + user + expiry.
- Flow: agent proposes -> draft approval record -> pause (interrupt) -> UI shows draft, diff, sources, risks -> approve / edit / reject -> Executor runs once with idempotency key -> audit (ids only).
- LangGraph rules if used: durable Postgres checkpointer; thread_id = tenant:matter:approval; the node restarts from its beginning on resume, so side effects before interrupt must be idempotent; no bare try/except around interrupt.
- Audit log stores ids, counts and dates only (clio-mcp 2.0.1 once logged client content).
- Shared Legal Source Index holds public law only. Plug-in containers see only the tenant they serve.

## 9. Security and supply chain
- Document text and web content are data, never instructions: delimited blocks, hidden Unicode/HTML stripped. Hostile text in a matter note must not trigger a tool (test).
- Plug-ins: private fork, pinned commit, `uvx mcp-scan@latest --skills` plus manual read of prompts, install scripts and network calls. Scanners are bypassable; manual review and pinning stay mandatory. Re-scan on every update.
- mcp-legal-it: internal network only, release tag not @main, statute tools only at launch.
- OpenContracts: change default admin credentials, disable telemetry, review write-capable MCP tools.
- Secrets in a secret store, per-tenant keys, none in prompts or logs.

## 10. Jurisdiction, licensing, counsel
- Primary law: Italy and EU. Art. 5 L. 633/1941 frees statutory text from copyright, but court judgments and database structure are separate questions.
- OPEN LICENCE QUESTION: the Normattiva open-data portal text says its experimental phase uses CC BY 4.0 NC (non-commercial), while other notes report CC-BY-4.0 and Italia Corpus states public domain. Until counsel answers, build and test on a private dev index; do not expose it to paying tenants.
- Launch scope: statutes only. Case law (Italgiure, TAR/CdS, Corte Costituzionale, OpenGA) arrives later, source by source, after counsel clears each.
- Counsel needed (Olesia names them; the local Ordine can suggest): (1) IP/IT and open-data reuse lawyer; (2) privacy/GDPR lawyer; (3) a practising avvocato versed in ordinamento forense for the art. 13 disclosure and professional secrecy.
- Art. 13 L. 132/2025: AI use in intellectual professions is instrumental and support-only, and the client must be informed in clear, simple, complete language. The CNF prepared a scheme that lawyers may use if they find it useful (optional; I have not read the scheme text). Elisa supports the duty thinly through C15 and does not carry it: the obligation is the lawyer's.
- US/UK-derived content is structure only. Common-law boilerplate must not reach Italian contracts without Italian playbooks (liability caps, indemnities, onerous clauses: arts. 1229, 1341-1342 c.c.).
- Licences: Apache-2.0 (mcp-legal-it, claude-for-legal, Vaquill), MIT (OpenContracts, clio-mcp, google-calendar-mcp, italia-corpus script), CC-BY-4.0 (HF corpus), AGPL-3.0 (Lexia, AVOID). LangGraph: read the LICENSE file at fork time.

## 11. Models and cost
Role-to-model map in env, hot-swappable. Cheap fast tier for routing and reporting, mid tier for drafting, stronger model only on auditor flag. Backy re-checks current model availability and prices at build time. Provider data terms (no training, retention, EU region) are decided per tenant before go-live.

## 12. LLMOps and evals
- Metrics: cost per conversation, escalation rate, approval accept/edit/reject rates, unverified-citation rate, top unhandled intents.
- Golden sets in Italian: research questions with verified citations; agenda scenarios (0 missed conflicts) on native, Google and Outlook data; clause sets per practice area; injection tests; cross-tenant leak tests.
- Gate tests before any plug-in version bump.

## 13. Source register (live check 2026-10-30)
USE-CODE = fork, pin, integrate. USE-DATA = ingest. USE-DOCS = read to implement. BUILD = write in-house. PATTERN = copy ideas only. INFO = context only. AVOID = do not use. Star and commit counts are snapshots; re-check at fork time. "Search result" = seen in search, not opened.
| Class | Source | Live check | Facts |
|---|---|---|---|
| USE-CODE | [LangGraph (repo + interrupt docs)](https://docs.langchain.com/oss/python/langgraph/interrupts) | OK 2026-10-30 | Check LICENSE file in repo (not shown on fetched page); ~44k stars (snapshot); tier DEFAULT |
| USE-CODE | [capazme/mcp-legal-it](https://github.com/capazme/mcp-legal-it) | OK 2026-10-30 | Apache-2.0; ~28 stars, 4 forks, single maintainer (snapshot); tier DEFAULT |
| USE-CODE | [OpenContracts](https://github.com/Open-Source-Legal/OpenContracts) | OK 2026-10-30 | MIT; ~1.5k stars (snapshot); tier DEFAULT |
| USE-CODE | [nspady/google-calendar-mcp](https://github.com/nspady/google-calendar-mcp) | OK 2026-10-30 | MIT; ~1.2k stars; tier FALLBACK |
| USE-DATA | [ahmeabd/italia-corpus](https://github.com/ahmeabd/italia-corpus) | OK 2026-10-30 | Script MIT; data stated public domain (art. 5 L. 633/1941); ~450 stars, daily updates (snapshot); tier DEFAULT |
| USE-DATA | [dossier-legal/italian-legal-corpus (Hugging Face)](https://huggingface.co/datasets/dossier-legal/italian-legal-corpus) | OK 2026-10-30 | CC-BY-4.0 (attribution required); 366k rows; tier FALLBACK |
| USE-DOCS | [Microsoft Graph getSchedule (Outlook free/busy)](https://learn.microsoft.com/en-us/graph/api/calendar-getschedule?view=graph-rest-1.0) | OK (search result, not fetched) | Microsoft docs; n/a; tier REFERENCE |
| USE-DOCS | [Legge 23 settembre 2025, n. 132 (Normattiva)](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:legge:2025;132) | OK (search result, not fetched) | Public law; n/a; tier REFERENCE |
| USE-DOCS | [Ordine Avvocati Milano - CNF informativa art. 13](https://www.ordineavvocatimilano.it/it/news/informativa-sullutilizzo-di-strumenti-di-intelligenza-artificiale-ex-art-13-legge-23-settembre-2025-n132/p100-n2904) | OK 2026-10-30 | Check scheme terms; n/a; tier REFERENCE |
| BUILD | In-house deterministic conflict + deadline engine (BUILD) | n/a | Own code; n/a; tier DEFAULT |
| PATTERN | [anthropics/claude-for-legal](https://github.com/anthropics/claude-for-legal) | OK 2026-10-30 | Apache-2.0; ~9.8k stars, ~1.9k forks (snapshot); tier DEFAULT |
| PATTERN | [claude-for-legal managed-agent-cookbooks](https://github.com/anthropics/claude-for-legal) | OK 2026-10-30 | Apache-2.0; Part of C1; tier FALLBACK |
| PATTERN | [oktopeak/clio-mcp](https://github.com/oktopeak/clio-mcp) | OK 2026-10-30 | MIT; ~26 stars; tier FALLBACK |
| PATTERN | [Vaquill-AI/ms-word-addin](https://github.com/Vaquill-AI/ms-word-addin) | OK 2026-10-30 | Apache-2.0; ~77 stars; tier FALLBACK |
| PATTERN | [Microsoft Legal Agent in Word (Frontier)](https://techcommunity.microsoft.com/blog/microsoft-copilot-blog/word-legal-agent-in-frontier/4516218) | OK 2026-10-30 | Proprietary; First-party Microsoft, Frontier preview; tier NOT RECOMMENDED (to embed) |
| INFO | [openlegaldata/awesome-legal-data](https://github.com/openlegaldata/awesome-legal-data) | OK 2026-10-30 | Check repo; ~324 stars; tier FALLBACK |
| INFO | [github.com/topics/normattiva](https://github.com/topics/normattiva) | OK 2026-10-30 | Varies; Small; tier FALLBACK |
| INFO | [dati.normattiva.it (Open Data portal)](https://dati.normattiva.it/Dati-disponibili) | OK (search result, not fetched) | CC BY 4.0 NC (per portal text; verify); n/a; tier NOT RECOMMENDED (until cleared) |
| INFO | [Ansvar-Systems/italian-law-mcp](https://github.com/Ansvar-Systems/italian-law-mcp) | OK 2026-10-30 | Apache-2.0; 1 star; tier NOT RECOMMENDED |
| INFO | [Azure-Samples/ally-legal-assistant](https://github.com/Azure-Samples/ally-legal-assistant) | OK 2026-10-30 | No licence file seen; README says free to use; ~82 stars; tier NOT RECOMMENDED |
| INFO | [Copilot Studio Gallery - Contract Review Assistant](https://microsoft.github.io/copilot-studio-gallery/solutions/contract-review-assistant/) | OK 2026-10-30 | Community; n/a; tier NOT RECOMMENDED |
| INFO | [zavora-ai/mcp-scheduling](https://github.com/zavora-ai/mcp-scheduling) | OK 2026-10-30 | Apache-2.0; 1 star; tier NOT RECOMMENDED |
| INFO | [Snyk ToxicSkills study](https://snyk.io/blog/toxicskills-malicious-ai-agent-skills-clawhub/) | OK 2026-10-30 | Article; n/a; tier REFERENCE |
| INFO | [CSA note on skill-scanner bypass](https://labs.cloudsecurityalliance.org/research/csa-research-note-ai-agent-skill-scanner-bypass-20260610-csa/) | OK 2026-10-30 | Article; n/a; tier REFERENCE |
| INFO | [Harvey](https://www.harvey.ai) | OK 2026-10-30 | Proprietary; Large vendor; tier NOT RECOMMENDED (to embed) |
| INFO | [Reddit r/legaltech - Open source and legal](https://www.reddit.com/r/legaltech/comments/1t71ev5/open_source_and_legal/) | OK 2026-10-30 | Unknown; 14 votes, 20 comments; tier NOT RECOMMENDED |
| INFO | [Legal Agent for Word Docs (legalagent.github.io)](https://legalagent.github.io/Legal-Agent-for-Word/en/) | OK 2026-10-30 | Unknown; Unrated; tier NOT RECOMMENDED |
| AVOID | [GoryNickel9/Lexia-Italian-Law-LLM](https://github.com/topics/normattiva) | OK 2026-10-30 | AGPL-3.0; 1 star; tier NOT RECOMMENDED |
| AVOID | [yellenlegal/clio-mcp](https://github.com/yellenlegal/clio-mcp) | OK 2026-10-30 | MIT; 3 stars, 3 commits; tier NOT RECOMMENDED |
| AVOID | [Unvetted ClawHub / skills.sh skills](https://snyk.io/blog/toxicskills-malicious-ai-agent-skills-clawhub/) | OK 2026-10-30 | Varies; Varies; tier NOT RECOMMENDED |

Not re-fetched (verify on first touch): Brocardi and Italgiure terms, EUIPO eSearch plus / TMview, Trail of Bits post, NVIDIA SkillSpector, mcp-scan repo, the "Mike" project (no repo URL found). The full link list is in elisa_source_links.md.

## 14. Build order (summary; work packages in implementation_plan.md)
P0 discovery and prerequisites (parallel) -> P1 spine (tenant context, tool gateway, approvals, calendar abstraction) -> P2 parallel lanes (crm, research, contract incl. AI-use disclosure, playbooks, quality, UI) -> P3 hardening, case-law enablement after counsel, Elisa-s&m.

## 15. Open items
- Elisa's existing approval mechanism unknown (WP-A1)
- Existing Google sync unknown (WP-A2)
- Counsel not yet named by Olesia
- Normattiva licence conflict (NC vs CC-BY vs art. 5) unresolved
- CNF scheme text not read; counsel reviews disclosure wording
- Trademark search not done
- Elisa-s&m not researched
- Star counts and mcp-legal-it profile/Docker details are snapshots; Backy re-verifies at fork time
- Not re-fetched: Brocardi, Italgiure, CeRDEF, TAR/CdS terms, EUIPO/TMview, Trail of Bits post, NVIDIA SkillSpector, mcp-scan repo
