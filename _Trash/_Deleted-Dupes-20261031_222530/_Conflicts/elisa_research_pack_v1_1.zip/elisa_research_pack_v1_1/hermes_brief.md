# Hermes brief: researching legal agents for Elisa (v1.1, 2026-10-30)

Records live in `elisa_research.json` (source of truth). This file holds only the logic.

## Conventions
- One Excel (human) + one JSON (Hermes source of truth) + MD brief + architecture + implementation plan + source links, in one zip; do not repeat the same table in several files
- Tiers: DEFAULT / FALLBACK / NOT RECOMMENDED (reasons); use_class tells how a link is used
- Agent names: Elisa-crm, Elisa-researcher, Elisa-contract, Elisa-s&m
- Roster: Backy=Bone (backend), Fronty=Skin (frontend); collaborators chosen by Backy
- No timelines; priorities and order only; soft guardrails
- Prefer free/low-cost, reversible; label unverified claims; check links live; prefer the thinnest feature that does the job

## Research procedure
1. Find candidates: GitHub topics, vendor repos, Microsoft/Anthropic galleries, Reddit (weak evidence), skill marketplaces (untrusted by default).
2. Open each link and read it. Label anything seen only in search results. Never state licences, counts or features from memory.
3. Run gates G1-G9 (JSON `gates`). Check for conflicting licence statements across sources (example: Normattiva open data NC vs CC-BY vs public domain). G9: prefer the thinnest feature that meets the duty or need.
4. Assign tier (DEFAULT/FALLBACK/NOT RECOMMENDED/REFERENCE) and use_class (USE-CODE/USE-DATA/USE-DOCS/BUILD/PATTERN/INFO/AVOID) with a reason.
5. Map to one agent: Elisa-crm, Elisa-researcher, Elisa-contract, Elisa-s&m.
6. Prefer deterministic code for conflicts and deadlines. Writes go through approval records; tenant ID comes from Elisa.
7. Italian law content only from Italian sources; US/UK is structure only.

## Standing decisions (JSON `decisions`)
Flask + PostgreSQL RLS; approvals unknown (discover first); calendars native + Google + Outlook; statutes only at launch; playbooks for all areas with lawyer sign-off; AI-use disclosure kept thin (template + auto record + setting); roster Backy=Bone, Fronty=Skin; no timelines.

## Open items
- Elisa's existing approval mechanism unknown (WP-A1)
- Existing Google sync unknown (WP-A2)
- Counsel not yet named by Olesia
- Normattiva licence conflict (NC vs CC-BY vs art. 5) unresolved
- CNF scheme text not read; counsel reviews disclosure wording
- Trademark search not done
- Elisa-s&m not researched
- Star counts and mcp-legal-it profile/Docker details are snapshots; Backy re-verifies at fork time
- Not re-fetched: Brocardi, Italgiure, CeRDEF, TAR/CdS terms, EUIPO/TMview, Trail of Bits post, NVIDIA SkillSpector, mcp-scan repo