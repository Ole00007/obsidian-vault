# Elisa research: source links (2026-10-30)

Opened = fetched and read on 2026-10-30; Search result only = seen in search results, verify on first touch. Not re-checked: Brocardi, Italgiure, CeRDEF, TAR/CdS terms, Trail of Bits post, NVIDIA SkillSpector, mcp-scan repo.

## USE-CODE (fork, pin, integrate)

| Source | Why | Status |
|---|---|---|
| [LangGraph (repo + interrupt docs)](https://docs.langchain.com/oss/python/langgraph/interrupts) | Matches approval rule and Hermes template. Only used if Elisa has no equivalent (see WP-A1). | Opened |
| [capazme/mcp-legal-it](https://github.com/capazme/mcp-legal-it) | Only candidate native to Italian law. Gate: source-terms review; case-law tools off until counsel clears. | Opened |
| [OpenContracts](https://github.com/Open-Source-Legal/OpenContracts) | Closest open Harvey-like layer. Spike first: keep, trim or drop. | Opened |
| [nspady/google-calendar-mcp](https://github.com/nspady/google-calendar-mcp) | Use only if WP-A2 finds no existing Google sync. | Opened |

## USE-DATA (ingest)

| Source | Why | Status |
|---|---|---|
| [ahmeabd/italia-corpus](https://github.com/ahmeabd/italia-corpus) | Cleanest statute corpus. Dev/test index first; production ingestion waits for counsel. | Opened |
| [dossier-legal/italian-legal-corpus (Hugging Face)](https://huggingface.co/datasets/dossier-legal/italian-legal-corpus) | Backup if Italia Corpus fails licence/freshness; later source for case-law metadata. | Opened |

## USE-DOCS (read to implement)

| Source | Why | Status |
|---|---|---|
| [Microsoft Graph getSchedule (Outlook free/busy)](https://learn.microsoft.com/en-us/graph/api/calendar-getschedule?view=graph-rest-1.0) | Needed for the optional Outlook sync. | Search result only |
| [Legge 23 settembre 2025, n. 132 (Normattiva)](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:legge:2025;132) | Basis for the thin AI-use record and the mandatory-approval design. | Search result only |
| [Ordine Avvocati Milano - CNF informativa art. 13](https://www.ordineavvocatimilano.it/it/news/informativa-sullutilizzo-di-strumenti-di-intelligenza-artificiale-ex-art-13-legge-23-settembre-2025-n132/p100-n2904) | Optional base for one disclosure template; counsel reviews wording. | Opened |
| [Guida al Diritto: rapporto avvocatura e IA (PDF)](https://www.ordineavvocatimilano.it/media/area-stampa/articoli/GIUSTIZIA%20DIGITALE/GENNAIO2026/Rapporto%20tra%20avvocati%20e%20IA_Guida%20al%20Diritto_24gennaio2026.pdf) | Commentary on art. 13 | Search result only |

## PATTERN (copy ideas only)

| Source | Why | Status |
|---|---|---|
| [anthropics/claude-for-legal](https://github.com/anthropics/claude-for-legal) | Best pattern source for matter/task/deadline workflows with explicit send/file gates. Copy structure, rewrite law for Italy. Italian equivalent of the practice profile = per-tenant playbook config. | Opened |
| [claude-for-legal managed-agent-cookbooks](https://github.com/anthropics/claude-for-legal) | Copy the watcher and tool-scope-lint ideas into Hermes cron + LangGraph. | Opened |
| [oktopeak/clio-mcp](https://github.com/oktopeak/clio-mcp) | Copy read-tool taxonomy, scoped credentials and READ_ONLY switch. | Opened |
| [Vaquill-AI/ms-word-addin](https://github.com/Vaquill-AI/ms-word-addin) | UX and playbook patterns only. | Opened |
| [Microsoft Legal Agent in Word (Frontier)](https://techcommunity.microsoft.com/blog/microsoft-copilot-blog/word-legal-agent-in-frontier/4516218) | Read for the deterministic-redline idea; cannot be cloned. | Opened |
| [claude-for-legal README](https://github.com/anthropics/claude-for-legal/blob/main/README.md) | Practice profile, scheduled agents, trust layer | Opened |

## INFO (context only)

| Source | Why | Status |
|---|---|---|
| [openlegaldata/awesome-legal-data](https://github.com/openlegaldata/awesome-legal-data) | Hermes discovery aid. | Opened |
| [github.com/topics/normattiva](https://github.com/topics/normattiva) | Candidate discovery only. | Opened |
| [dati.normattiva.it (Open Data portal)](https://dati.normattiva.it/Dati-disponibili) | Open licence question for counsel before production ingestion. | Search result only |
| [Ansvar-Systems/italian-law-mcp](https://github.com/Ansvar-Systems/italian-law-mcp) | Read its licensing notes only. | Opened |
| [Azure-Samples/ally-legal-assistant](https://github.com/Azure-Samples/ally-legal-assistant) | Architecture ideas only. | Opened |
| [Copilot Studio Gallery - Contract Review Assistant](https://microsoft.github.io/copilot-studio-gallery/solutions/contract-review-assistant/) | Information only. | Opened |
| [zavora-ai/mcp-scheduling](https://github.com/zavora-ai/mcp-scheduling) | Read the approval-binding idea only. | Opened |
| [Snyk ToxicSkills study](https://snyk.io/blog/toxicskills-malicious-ai-agent-skills-clawhub/) | Justifies the supply-chain rules. | Opened |
| [CSA note on skill-scanner bypass](https://labs.cloudsecurityalliance.org/research/csa-research-note-ai-agent-skill-scanner-bypass-20260610-csa/) | Justifies manual review + pinning. | Opened |
| [Harvey](https://www.harvey.ai) | Benchmark only. | Opened |
| [Reddit r/legaltech - Open source and legal](https://www.reddit.com/r/legaltech/comments/1t71ev5/open_source_and_legal/) | Weak evidence; context only. | Opened |
| [Legal Agent for Word Docs (legalagent.github.io)](https://legalagent.github.io/Legal-Agent-for-Word/en/) | Do not confuse with I1. | Opened |
| [Normattiva home](https://www.normattiva.it/) | Official database | Search result only |
| [Alexi](https://www.alexi.com/) | Name collision; benchmark | Search result only |
| [Elisa Oyj](https://elisa.com/) | Branding conflict research | Search result only |
| [EUIPO search tools](https://www.euipo.europa.eu/en/search) | eSearch plus and TMview for trademark check | Search result only |

## AVOID

| Source | Why | Status |
|---|---|---|
| [GoryNickel9/Lexia-Italian-Law-LLM](https://github.com/topics/normattiva) | Do not embed. | Opened |
| [yellenlegal/clio-mcp](https://github.com/yellenlegal/clio-mcp) | Prefer F7 as reference. | Opened |
| [Unvetted ClawHub / skills.sh skills](https://snyk.io/blog/toxicskills-malicious-ai-agent-skills-clawhub/) | Install only after manual review + pin. | Opened |
