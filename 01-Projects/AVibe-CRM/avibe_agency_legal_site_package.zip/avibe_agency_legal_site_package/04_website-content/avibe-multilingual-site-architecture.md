# AVIBE AGENCY — Multi-Page Site Architecture

## Navigation
- Home
- Services
  - CRM & Automation
  - Websites & Landing Pages
  - AI Assistants & Chatbots
  - Video & AI Video
  - Social Media & Content
  - Analytics & Dashboards
  - SEO / AEO / GEO
- Pricing
- How We Work
- Resources
  - Digital Readiness & Project Planning
  - Regime Forfettario: Practical Information
  - Specialist Network & Referrals
- Case Studies
- About
- Contact / Book a Discovery Call
- Legal: Privacy · Cookies · Terms

## Messaging guardrails
Use: “digital systems, practical project guidance, qualified-professional referrals.”
Do not use: “we provide legal advice,” “we do accounting,” “we guarantee grants/tax savings/rankings,” “best lawyers/accountants.”

## Resource page: specialist network
**Heading:** When a digital project needs a specialist

**Copy:** Building a site, CRM or AI workflow often reveals adjacent questions: business structure, contracts, privacy, bookkeeping, taxation or sector regulation. AVIBE helps clients organise the project context and, where appropriate, facilitates introductions to independent qualified specialists. AVIBE does not provide legal, tax or accounting advice. Any specialist engagement is optional and is contracted directly between the client and the chosen professional.

## Conversion path
1. Home CTA: `Plan your digital system`.
2. Intake form: service need, industry, stage, current stack, desired result, budget range, deadline, consent.
3. Triage: standard digital project / needs specialist referral / hybrid.
4. Discovery call.
5. Proposal + SOW + relevant price sheet.
6. Delivery workspace and approval log.

## Content rules
- Publish price ranges, not a fake fixed quote for complex work.
- Every service page: problem, deliverables, process, exclusions, starting price, FAQ, CTA.
- Every legal/tax-adjacent page: clear disclaimer and referral boundary.
- Use consent-controlled analytics and footer legal links.
