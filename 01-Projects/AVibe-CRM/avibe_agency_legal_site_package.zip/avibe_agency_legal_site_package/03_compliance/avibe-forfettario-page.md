# AVIBE — Regime Forfettario Information Page

## Public-page purpose
Explain AVIBE’s invoicing position clearly and professionally. Do not provide individual tax advice or present AVIBE as an accounting/tax practice.

## Recommended Italian copy
# Trasparenza fiscale e collaborazioni professionali

AVIBE AGENCY opera, ove applicabile, in **regime forfettario**. I corrispettivi per i servizi professionali sono fatturati secondo la normativa applicabile al regime forfettario e non sono soggetti a IVA.

In fattura può comparire la seguente dicitura: `Operazione effettuata ai sensi dell’art. 1, commi da 54 a 89, della Legge n. 190/2014 e successive modificazioni. Operazione non soggetta ad IVA.`

Per fatture elettroniche di importo superiore alla soglia prevista dalla legge può essere applicata l’imposta di bollo, indicata separatamente in fattura ove dovuta.

## How AVIBE can help
AVIBE can help entrepreneurs clarify digital project requirements, organise operational information, prepare website/CRM/automation documentation and identify when specialist advice is needed. AVIBE does **not** provide tax, accounting or legal advice and does not replace a commercialista, CAF or avvocato.

Where a client needs qualified support, AVIBE may facilitate an introduction to an independent commercialista, accountant, lawyer or other specialist from its professional network, selected by relevance to the request. The client remains free to choose any professional and agrees terms directly with that professional.

## English short version
AVIBE may operate under Italy’s regime forfettario where applicable; invoices are not subject to VAT under the applicable legal regime. AVIBE provides digital and operational support, not tax/accounting/legal advice. When appropriate, AVIBE can introduce clients to independent qualified professionals; clients remain free to choose and contract directly with them.

## Required fields before publishing
- `[P.IVA]`, `[C.F.]`, legal name, address, PEC and billing email.
- Whether statutory stamp duty is charged to client.
- Confirmed wording from commercialista.
- Partner-referral policy, conflict-of-interest/disclosure policy and consent process.
