# Lexflow — Cookie Consent Implementation Summary

For Italian/EU visitors, use opt-in consent before loading non-essential analytics, advertising, session recording or tracking embeds. First-layer actions must include equally accessible `Accept all`, `Reject non-essential`, and `Manage preferences`. No pre-ticked toggles. Closing the banner means necessary-only. Include persistent footer `Cookie Settings`.

## Categories
| Category | Default | Consent |
|---|---:|---:|
| Strictly necessary | on | no |
| Functional | off | yes |
| Analytics | off | yes |
| Marketing | off | yes |

## Required text
**Title:** Your privacy choices  
**Body:** Lexflow uses strictly necessary cookies to make the website work. With your permission, we use optional cookies and similar technologies to understand site use and measure or personalise marketing. You can accept all, reject non-essential cookies, or choose by category. Change your choice at any time in Cookie Settings.

Before deployment, scan production, publish a truthful cookie register, block tags technically before consent, document vendors/transfers, and test consent withdrawal. Reference: https://www.garanteprivacy.it/home/docweb/-/docweb-display/docweb/9677876
