# AVIBE AGENCY — Legal, Services and Website Content Package

This archive consolidates the contract/template, price-list, cookie-consent, forfettario and site-implementation materials developed in this conversation.

## Use order
1. Complete `01_contracts` master terms and select the relevant service SOW.
2. Use `02_price-lists` as a starting commercial catalogue; quote the exact scope in the SOW.
3. Publish the information pages in `04_website-content` only after legal/tax details and partner-referral wording are reviewed.
4. Use `05_hermes` to build AVIBE’s current one-page landing site into a secure multilingual website.
5. Copy this archive into the Obsidian vault according to `06_obsidian`.

## Important boundaries
- These are B2B-oriented commercial templates, not a substitute for a final review by an Italian avvocato/commercialista.
- Do not describe AVIBE as a law firm, accountant, CAF or commercialista unless it holds the required qualification/authorisation.
- AVIBE may provide digital, workflow and general informational guidance, then introduce a client to an independent, suitable qualified professional. The client remains free to choose any professional.
- Never publish invented partner lists, qualifications, grant eligibility claims, prices, tracking vendors or tax details.

## Archive index
- `01_contracts`: master agreement, service work-order templates and DPA intake checklist.
- `02_price-lists`: standalone catalogue of starting prices.
- `03_compliance`: Lexflow cookie/CMP implementation and AVIBE forfettario content.
- `04_website-content`: information architecture and page copy.
- `05_hermes`: implementation prompt and agent routing.
- `06_obsidian`: canonical vault structure and operating rules.
