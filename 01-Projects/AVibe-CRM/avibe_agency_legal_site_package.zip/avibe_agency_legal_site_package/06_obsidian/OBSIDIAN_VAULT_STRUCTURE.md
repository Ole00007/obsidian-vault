# AVIBE Obsidian Vault — Canonical Structure

```text
AVIBE-OS/
├── 00_Inbox/
├── 01_Brand/
│   ├── Positioning.md
│   ├── Voice-and-Messaging.md
│   └── Visual-Identity.md
├── 02_Services/
│   ├── CRM-Automation.md
│   ├── Websites-Landing-Pages.md
│   ├── AI-Assistants-Chatbots.md
│   ├── Video-AI-Video.md
│   ├── SMM-Content.md
│   ├── Analytics.md
│   └── SEO-AEO-GEO.md
├── 03_Commercial/
│   ├── Price-Lists/
│   ├── Proposals/
│   ├── SOWs/
│   └── Change-Orders/
├── 04_Legal-Operations/
│   ├── Contract-Masters/
│   ├── Privacy-Cookies/
│   ├── Forfettario/
│   └── Referral-Network-Policy/
├── 05_Website/
│   ├── Content-Source/
│   ├── IA-and-SEO/
│   ├── Hermes-Prompts/
│   └── Release-Logs/
├── 06_Partners/
│   ├── Commercialisti/
│   ├── Lawyers/
│   └── Referral-Intake/
├── 07_Clients/
├── 08_SOPs/
├── 09_Decisions-Log/
└── 99_Archive/
```

## Operating rules
- Canonical content is Markdown in Obsidian; the website consumes an approved export/copy, not random local copies.
- Naming: `YYYY-MM-DD_AVIBE_Topic_v01.md`.
- Use frontmatter: `status`, `owner`, `language`, `source`, `last_reviewed`, `publishable`, `sensitivity`.
- `publishable: false` for contract masters, personal tax identifiers, partner personal data, client data and internal pricing logic.
- Every website release creates a note in `05_Website/Release-Logs` linking source notes and Git commit/PR.
- Every final client project is archived with a brief, approved SOW, deliverables, approval evidence and final handover note.
