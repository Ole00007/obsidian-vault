# AVIBE AGENCY — Starting Price List

> All prices are starting prices in EUR, excluding approved third-party costs. Exact price is defined by the SOW. Use the forfettario invoice wording where applicable.

## Product, CRM and Web
| Service | Unit | From |
|---|---:|---:|
| Discovery workshop | 2 hours | €250 |
| CRM architecture blueprint | project | €650 |
| CRM foundation setup | project | €1,200 |
| CRM automation | workflow | €180 |
| Standard integration | integration | €450 |
| CRM dashboard | dashboard | €250 |
| CRM training | 90 min | €180 |
| CRM support | month | €450 |
| Chatbot discovery | 2 hours | €250 |
| Prompt/conversation design | assistant | €550 |
| RAG assistant configuration | assistant | €1,200 |
| Website chatbot deployment | project | €650 |
| AI workflow/agent | workflow | €750 |
| Landing page build | page | €850 |
| Marketing website build | page | €650 |
| CMS setup | project | €750 |
| Basic technical SEO setup | project | €450 |

## Content and Growth
| Service | Unit | From |
|---|---:|---:|
| Video discovery/concept | 2 hours | €250 |
| Script/storyboard | asset | €300 |
| On-location filming | hour | €150 |
| Full shoot day | up to 8 hours | €1,200 |
| Basic social short edit | video | €90 |
| Advanced Reel/Short | video | €180 |
| Long-form edit, up to 10 min | video | €450 |
| AI video asset | short asset | €250 |
| Social-media audit | brand/up to 3 channels | €650 |
| 90-day social strategy | project | €900 |
| Monthly content calendar | month | €450 |
| Community management | month | €500 |
| Monthly reporting | month | €250 |
| Paid-social setup | campaign | €450 |
| Paid-media management | month | €600 or `[X]%` spend |
| Measurement plan | project | €650 |
| GA4/GTM baseline | property | €550 |
| Custom event | event | €120 |
| Analytics dashboard | dashboard | €450 |
| Technical SEO audit, 100 URLs | site | €850 |
| SEO roadmap | project | €650 |
| Keyword/topic cluster | cluster | €350 |
| On-page optimisation | page | €120 |
| AEO/GEO audit | site | €950 |
| Local SEO / GBP setup | location | €450 |
| Consulting | hour | €85 |

## Optional retainers
| Plan | Monthly fee | Included hours |
|---|---:|---:|
| Care Lite | €250 | 3 |
| Care Standard | €450 | 6 |
| Care Growth | €850 | 12 |
| Fractional Digital Operations | €1,500 | 24 |
