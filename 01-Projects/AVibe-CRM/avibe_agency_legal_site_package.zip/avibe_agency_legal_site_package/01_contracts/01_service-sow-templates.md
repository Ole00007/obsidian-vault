# AVIBE — Service SOW Templates

Use this with Master Terms. Complete the common fields, then paste the relevant service scope.

## Common SOW
**SOW no.:** `[NUMBER/YEAR]` · **Client:** `[LEGAL NAME]` · **Project:** `[NAME]` · **Start/target delivery:** `[DATES]` · **Client approver:** `[NAME/EMAIL]` · **Channel:** `[EMAIL/NOTION/SLACK]`

| Item | Scope / result | Quantity | Price | Acceptance condition |
|---|---|---:|---:|---|
| `[ITEM]` | `[DETAIL]` | `[QTY]` | `€[X]` | `[TEST/APPROVAL]` |

**Excluded:** `[LIST]`  
**Included revisions:** `[NUMBER]`  
**External costs:** `[LIST/BUDGET/WHO PAYS]`  
**Payment:** advance `€[X]`; milestone `€[X]`; final `€[X]`.

## CRM Building
Include: platform; users; pipelines; custom objects/fields; automations; integrations; import source/record volume; reports; training; support period. Exclude data cleansing and unsupported platform migrations unless priced. Acceptance: agreed configuration and test cases work; no critical defect blocks core flow.

## CRM Adoption
Include: audit; user interviews; process/SOPs; training; optimisation sprint; adoption dashboard; review cadence. State that management ownership, user discipline, adoption rate and sales outcomes remain client responsibilities.

## Chatbot / AI assistant
Include: purpose, audience, channels, language, model/provider, knowledge sources, RAG volume, integrations, human handoff, blocked topics, allowed actions, testing pack and support. Require human review of outputs. No autonomous message, booking, spending, record update or sensitive-data action without express SOW permission.

## Website / Landing page
Include: domain, platform, pages, languages, CMS, copy owner, assets, forms, analytics, CMP, SEO deliverables, hosting/deployment, browser matrix and post-launch support. Exclude legal compliance certification and guaranteed SEO outcomes. Acceptance: agreed pages/forms/integrations work in agreed current browser matrix.

## Video / AI video
Include: audience/CTA; final assets; format, duration, resolution; language/subtitles; shoot date/location/hours; talent; revision count; delivery date; music/stock/voice licenses; AI tools; portfolio restriction. Client must obtain releases for people, locations and brands. State cancellation fee and overtime rate. Synthetic likeness/voice requires written authority.

## SMM
Include: channels, content volume, calendar, approval deadline, publishing, community-management hours/languages, reporting, paid-media scope and ad budget. Client has final approval of claims/promotions. Do not guarantee reach, growth, platform availability or sales.

## Analytics
Include: KPIs; GA4/GTM; event list; dashboard; CRM attribution; reporting cadence; CMP/consent configuration. Client owns privacy notice/cookie policy/consent responsibilities. Do not treat reports as audited accounts.

## SEO/AEO/GEO
Include: technical audit scope; URL limit; topic clusters; content briefs/pages; schema types; Local SEO locations; reporting. Define AEO as answer-focused information architecture, GEO as optimisation for generative-search usefulness. No ranking, traffic, lead or AI-citation promise. No spam, deceptive markup, fake reviews or manipulative AI content.
