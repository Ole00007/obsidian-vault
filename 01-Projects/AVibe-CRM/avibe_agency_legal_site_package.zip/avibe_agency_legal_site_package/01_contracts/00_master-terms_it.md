# AVIBE AGENCY — Condizioni Generali (IT)

**Fornitore:** AVIBE AGENCY, operata da Olesia Rasing. P.IVA `[NUMERO]`; C.F. `[NUMERO]`; sede `[INDIRIZZO]`; PEC `[PEC]`; email `[EMAIL]`.

1. Ogni progetto è regolato dalle presenti Condizioni Generali e da un Ordine di Lavoro (OdL) firmato. Prevalgono: Change Order approvato, OdL, Condizioni Generali, proposta richiamata.
2. AVIBE opera quale professionista indipendente; non garantisce ricavi, ranking, reach, lead, finanziamenti, approvazione di piattaforme o accuratezza degli output AI.
3. Il Committente fornisce materiali, accessi, licenze, claim, approvazioni e un referente autorizzato; ritardi del Committente prorogano ragionevolmente le scadenze.
4. Sono inclusi solo i servizi indicati nell’OdL. Nuovi deliverable, revisioni, integrazioni, lingue, formati, giornate di ripresa, budget media, fonti dati o requisiti tecnici richiedono approvazione scritta con prezzo e impatto temporale.
5. Pagamenti standard: 50% acconto, 40% al milestone concordato, 10% prima di consegna o lancio; progetti brevi 50%/50%. Scadenza fattura `[7/14]` giorni. Costi terzi approvati esclusi.
6. Il Committente invia entro 5 giorni lavorativi un unico elenco di feedback specifici; in assenza il deliverable è accettato. Extra revisioni e cambi di direzione sono a pagamento.
7. Dopo saldo integrale, il Committente ottiene licenza non esclusiva, mondiale e perpetua sui deliverable finali pagati per la propria attività. AVIBE mantiene know-how, template, prompt, librerie, workflow, file sorgenti/progetto e strumenti interni salvo espressa pattuizione. Asset di terzi soggetti alle proprie licenze.
8. AVIBE può mostrare nel portfolio lavori finali già pubblici, salvo vincolo scritto di riservatezza.
9. Il Committente è responsabile della liceità dei dati. Se AVIBE tratta dati per conto del Committente, occorre DPA ex art. 28 GDPR prima del trasferimento. Output AI da verificare sempre; azioni autonome rilevanti solo con incarico separato.
10. Riservatezza reciproca: 3 anni; segreti commerciali finché tali.
11. Nei limiti di legge, responsabilità AVIBE limitata ai compensi pagati per l’OdL nei 6 mesi precedenti; esclusi danni indiretti/consequenziali e disservizi di terzi.
12. In caso di annullamento il Committente paga attività svolte, work in progress e impegni autorizzati non recuperabili. Legge italiana; Foro di Genova per B2B, salvo norme inderogabili del consumatore.

Luogo/data `[CITTÀ, DATA]` · AVIBE ____________________ · Committente ____________________
