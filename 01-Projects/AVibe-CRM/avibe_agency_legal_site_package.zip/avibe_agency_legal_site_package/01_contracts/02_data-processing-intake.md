# AVIBE — GDPR / DPA Intake Checklist

Complete before personal data is accessed or uploaded.

| Field | Required detail |
|---|---|
| Controller | Client legal entity and privacy contact |
| Processor | AVIBE AGENCY / Olesia Rasing |
| Purpose | CRM, chatbot, analytics, website, support, etc. |
| Duration | Project term + retention/deletion period |
| Data subjects | Leads, users, employees, customers, etc. |
| Categories | Contact details, messages, CRM data, analytics data, etc. |
| Special-category / minors data | Default: prohibited unless expressly approved |
| Systems/subprocessors | Hosting, CRM, cloud, AI model, analytics, email, automation |
| International transfers | Provider country and documented transfer safeguard |
| Security | MFA, least privilege, encryption, backups, audit log, deletion |
| End-of-project action | Return / export / delete and evidence |

Execute a legally reviewed Article 28 GDPR DPA where AVIBE processes data on the client’s instructions.
