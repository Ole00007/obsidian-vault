# AVIBE AGENCY — Master Terms (EN)

**Provider:** AVIBE AGENCY, operated by Olesia Rasing. P.IVA `[NUMBER]`; C.F. `[NUMBER]`; address `[ADDRESS]`; PEC `[PEC]`; email `[EMAIL]`.

## Core terms
1. Each project is governed by this Master Terms document and a signed Work Order (SOW). Priority: approved Change Order, SOW, Master Terms, referenced proposal.
2. AVIBE is an independent provider. No employment, partnership, agency, exclusivity or guarantee of revenues, rankings, reach, leads, funding, platform approval or AI accuracy is created.
3. The client supplies timely, accurate and lawful materials, approvals, credentials, licences, claims and a single authorised approver. Client delays reasonably extend deadlines.
4. Only work expressly listed in the SOW is included. New deliverables, revisions, integrations, languages, formats, shoot days, ad budgets, data sources and technical requirements need written approval stating price and timing impact.
5. Default payment: 50% advance before work; 40% at agreed build/review milestone; 10% before final handover or launch. Short projects may use 50%/50%. Payment is due within `[7/14]` days. Approved external costs are additional.
6. Client has five business days to submit one consolidated, specific feedback list. Otherwise delivery is accepted. Revisions beyond the included number, changes of direction and post-approval changes are chargeable.
7. After full payment, client receives a perpetual, worldwide, non-exclusive licence for its business use of final paid deliverables. AVIBE retains background materials, know-how, templates, prompts, libraries, workflows, source/project files and internal tools unless an SOW expressly transfers them. Third-party assets remain subject to their licences.
8. AVIBE may show publicly released final work in its portfolio unless written confidentiality/portfolio restriction applies.
9. Client is responsible for lawful personal-data collection and use. If AVIBE processes data solely on client instructions, execute an Article 28 GDPR DPA before transfer. AI output requires human review; autonomous impactful actions require separate scope and approval.
10. Mutual confidentiality lasts three years after termination; trade secrets remain protected while secret.
11. AVIBE’s aggregate liability for an SOW is limited, to the maximum permitted by law, to fees paid under it in the preceding six months. No indirect/consequential loss, lost profits, data loss or third-party-platform loss is recoverable where law permits.
12. On client cancellation, client pays completed work, work in progress and approved non-refundable commitments; advance is credited against those amounts. Italian law applies; B2B forum is Genoa, subject to mandatory consumer rules.

**Place/date:** `[CITY, DATE]`  
**AVIBE:** ____________________  
**Client/name/role:** ____________________
