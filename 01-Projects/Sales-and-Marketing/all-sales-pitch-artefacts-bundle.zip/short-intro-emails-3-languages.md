# Short intro emails

## English

Subject: Files attached

Hi,

Please find attached the full template pack, including the multilingual sales pitch materials in English, Italian, and Russian, in both Markdown and Word formats.

Best regards,

## Italiano

Oggetto: File in allegato

Ciao,

In allegato trovi il pacchetto completo dei template, inclusi i materiali multilingue per sales pitch in inglese, italiano e russo, sia in formato Markdown sia Word.

Cordiali saluti,

## Русский

Тема: Файлы во вложении

Здравствуйте,

Во вложении направляю полный пакет шаблонов, включая многоязычные материалы sales pitch на английском, итальянском и русском языках, в форматах Markdown и Word.

С уважением,
