# Machine-readable handoff

`research_data.json` contains the canonical research tables, with matching CSV exports for filtering or agent ingestion. This is a research/specification package; no runtime, production policies or completed integration tests are included.

## Files and semantics

- **research_data.json**: 21 competitors, five buyer segments, seven workflows, 12 control records, 16 proposed tasks, 24 evaluation specifications, 34 questions and source registers.
- **action_contract.schema.json**: Draft 2020-12 schema for action, decision and disclosure records. Schema validity alone does not prove authorization, state consistency or a valid timestamp relationship.
- **policy_pack_proposed.json**: disabled, unreviewed policy specification. The human-readable conditions are not executable code and must not be evaluated by an LLM.
- **synthetic_examples.json**: three schema examples using dummy commitments, invalid demonstration references and no real client data.
- **CSV exports**: UTF-8, quoted fields; array-valued cells such as dependencies contain JSON arrays. Read with a CSV parser rather than splitting on commas.

## Trust boundaries

All tasks and reviewer assignments are proposals; an agent must not treat this file as permission to send, install, deploy, change RLS or ingest private client material. Resolve `n.a.`, null owners and counsel gates before activation.

Authentication supplies authoritative tenant and actor values; model-supplied values are not trusted. The implementation must additionally check cross-record consistency, approvals, policy freshness, resource versions, expiry ordering, decision authenticity, replay and execution state.

## Reading order for agents

Read `00_START_HERE.md`, the relevant report, and `05_engineering_handoff.md` before selecting tasks. Start with T01 and T02; legal-source research is not a substitute for T03's qualified review.

The workbook is a human editing surface, but the JSON/CSV are snapshots rather than a live two-way synchronization. If a user changes a workbook value, reconcile it into the canonical JSON and regenerate dependent files instead of allowing competing versions.
