# Elisa control-layer handoff for Backy, Hermes and collaborators

Proposed implementation contracts | 30 October 2026 | Not production-ready code

This handoff authorizes no production changes by itself. It equips the team to start discovery, mocks and isolated implementation work; all tasks remain proposed, and changes to billing, authentication, RLS, external messaging or production data require the project owner's explicit scope approval.

## Backy's first prompt

```text
Inspect the actual Elisa/LexFlow repository read-only. Do not assume Flask,
Postgres, LangGraph, RLS or an existing approval service.

Return:
1. Repository/branch/commit and stack with evidence paths.
2. Auth/session tenant derivation and tenant membership checks.
3. Approval tables/models, state transitions, reviewer authority and enforcement.
4. Every path that can mutate CRM/calendar, send messages, export files or invoke
   third-party tools, including cron, workers, shell and direct SDK calls.
5. Secrets and network ownership: can the agent bypass the proposed executor?
6. Tenant boundaries for SQL, vectors, blobs, cache, checkpoint, logs and backups.
7. Existing calendar providers and supported account types.
8. Current audit fields, sensitive content, retention and incident handling.
9. Existing CNF/disclosure functionality and evidence of implementation.
10. Recommendation: wrap, extend or replace each relevant control, with tests.

Do not print secrets or private client content. Use synthetic fixtures.
Mark unknowns explicitly. Propose small reversible PRs; ask before changing
auth, RLS, billing or production integrations.
```

## Ownership and sequencing

- **Olesia**: confirms buyer, pilot workflow, exclusions, spending authority and counsel appointments.
- **Backy / Bone**: owns discovery, normalized action contracts, executor enforcement and adapter design; proposes additional collaborators.
- **Fronty / Skin**: builds review inbox, readable diff, policy reasons, expiry and unknown-execution states against mocks after schema agreement.
- **Italian practising lawyer**: reviews legal workflows, disclosure and expected outputs; remains unnamed until appointed.
- **Privacy/IP counsel**: reviews data flows, transfers, source rights and retention; one firm may cover multiple legal roles if competent.
- **QA/security collaborator**: owns adversarial tests, tenant isolation and bypass testing; not presumed appointed.
- **Hermes**: coordinates approved tasks, evidence and test reports; must not activate plugins, ingest client data or send roster messages without permission.

Do not notify collaborators automatically merely because the old preview said to do so. Prepare the message and obtain authorization for named recipients and exact content.

## Minimal service contracts

`data/action_contract.schema.json` defines a normalized action envelope and policy decision. These are integration contracts, not a ready authentication protocol; the server derives identity and tenant context and rejects any caller attempt to replace them.

- **Evaluate**: `POST /v1/actions/evaluate` accepts a proposed action through a trusted adapter and returns allow, deny or require_approval plus rule IDs, policy version, reason codes and expiry.
- **Approve**: `POST /v1/approvals/{id}/decisions` requires an authenticated authorized human and a conditional version check; no LLM may set `decided_by`.
- **Execute**: only an internal executor accepts an execution reference, loads authoritative state, checks authorization and replay protections, then accesses provider credentials.
- **Reconcile**: a worker resolves ambiguous external outcomes using provider identifiers and read-back; absence of a response is not proof of non-execution.
- **Evidence**: a permissioned export links action, policy, human decision, attempts and observed outcome without leaking other tenants' data.

All endpoint names are proposals. Align them with the actual architecture rather than introduce a second control plane if an existing one can satisfy the contract.

## Data model to map onto existing tables

| Entity | Required information | Key constraint |
|---|---|---|
| ActionIntent | tenant, actor, matter, tool/version, payload commitment, destination, object version, data labels, idempotency key | Trusted context and immutable proposal |
| PolicyDecision | action, policy version, rule IDs, disposition, expiry, reason codes | Bind to evaluated proposal; no model override |
| Approval | decision/action, reviewer, role, approved hash, timestamps, revocation, expiry | Role-authorized, single bounded action |
| ExecutionAttempt | action, attempt ID, provider request ID, outcome, reconciliation state | Unknown outcome is a first-class state |
| EvidenceRecord | actor refs, event type, ordered sequence, commitments, policy/approval refs | Access-controlled, tamper-evident, purpose-limited |
| Disclosure | template/version, system inventory, purposes, professional approval, delivery evidence | Acknowledgement separate from lawful basis |
| SourceRights | source, acquisition route, licence, allowed operations, attribution, review | Code rights separate from data/source rights |
| PolicyPack | jurisdiction, profession, workflow, legal bases, effective dates, reviewer, tests | Unreviewed pack cannot be activated |

Migrations must be based on discovery. A schema draft is not permission to replace current tables.

## State transitions

```text
proposed -> evaluated
evaluated -> denied | awaiting_approval | authorized
awaiting_approval -> rejected | expired | revoked | authorized
authorized -> executing               [revalidate all constraints]
executing -> succeeded | failed | execution_unknown
execution_unknown -> succeeded | failed | manual_reconciliation
```

`expired`, `revoked`, `rejected` and `denied` cannot flow directly to execution. Changing the proposal produces a new evaluation and, when required, a new approval.

## Canonicalization, authority and replay

Define canonical encoding before hashing: stable key ordering, Unicode policy, numeric representation and attachment-byte digests. Distinguish harmless display normalization from a semantic mutation; never normalize away a recipient, decimal or legal-document change.

Use a server-owned decision ID or signed capability with audience and expiry, backed by authoritative revocation/state. Do not let a runtime invent an `allow` response; decision authenticity and freshness require service authentication and replay protection.

An approved action must still be denied if authority, tenant membership, policy version or resource version changed. Enforce uniqueness/atomic transitions in storage, and test concurrent approval/execution requests.

## Source and model controls

The allowlist needs individual tools and acquisition routes. For mcp-legal-it, a `normativa` profile is broader than statutes-only, so launch tools must be enumerated and case-law access disabled ([repository](https://github.com/capazme/mcp-legal-it)).

Store statute/source version and effective date, retrieval time, licence route and attribution alongside citations. Model availability and provider terms are checked at release; avoid hardcoding the old preview's model names as current defaults.

No unreviewed marketplace skill, repository installation script or provider route should run with client secrets. Pin code, image digests, transitive dependencies, scanner/rules and policy packs; scan results are not a substitute for constrained execution.

## Calendar adapter contract

Normalize native, Google and Outlook into availability intervals with source, timezone, last sync time and freshness status. Deduplicate overlapping calendars and distinguish busy, tentative, out-of-office, unknown and working-hours constraints.

For Microsoft getSchedule, use least-privilege permissions verified for the chosen account mode; handle the 20-entity and less-than-62-day bounds, and do not promise personal-account support ([API permissions](https://learn.microsoft.com/en-us/graph/api/calendar-getschedule?view=graph-rest-1.0), [limits](https://learn.microsoft.com/en-us/graph/outlook-get-free-busy-schedule)). Calendar availability does not establish statutory procedural deadlines or guarantee that a proposed slot remains free at execution.

## Launch acceptance gates

- **Identity and isolation**: spoofed tenant, unauthorized matter, checkpoint, vector, blob and worker access fail; no cross-tenant content in export or telemetry.
- **Enforcement**: direct-provider, shell and alternative-SDK bypass attempts are blocked for the covered deployment; unsupported paths are disclosed.
- **Approval integrity**: recipient, content, attachment, policy and object mutations invalidate approval; revocation and expiry are enforced server-side.
- **Concurrency/recovery**: duplicate execution attempts, crashes and ambiguous provider responses cannot cause blind repeated sends.
- **Disclosure**: generate, review, deliver, version and supersede records; distinguish acknowledgement from consent and authority.
- **Legal quality**: counsel-reviewed expected answers and temporal citations; unsupported legal questions escalate instead of fabricating.
- **Operational safety**: denial on policy outage for consequential actions, kill switch, rollback, backup restore and incident drill.
- **User value**: measure review-inclusive time, edits, false blocks, abandoned approvals and support load, not just model cost.

The companion evaluation cases are test specifications with expected outcomes, not passed tests. Security claims should state the tested scope and environment.

## Copy-paste briefs for the other agents

### Hermes coordinator

```text
Read 00_START_HERE, 05_engineering_handoff and data/research_data.json.
Treat all backlog items as proposed. Resolve dependencies in ID order, not by
inventing dates. Ask Olesia to confirm owners and the first workflow. Keep legal
review gates separate from engineering completion. Do not install plugins,
activate policies, ingest client documents, send messages or alter production.
Return a concise queue: ready discovery tasks, blocked tasks, required decisions.
```

### Fronty interface

```text
Using synthetic examples only, mock the action diff, responsible reviewer,
policy reasons, cited sources, disclosure delivery status and approval expiry.
Include denied, changed-payload, revoked, policy-unavailable and
execution_unknown states. Do not display an overall "legally compliant" badge.
Do not build around assumed database schemas before Backy confirms contracts.
```

### QA and security

```text
Convert evaluation_cases.csv into runnable tests after Backy's stack inventory.
Add at least one bypass attempt per supported execution route, cross-tenant tests
for every store, and race/replay/timeout tests. Use independent expected legal
results approved by the practising lawyer, not another model as sole oracle.
Report environment, versions, scope, failures and untested routes.
```

### Legal-policy reviewer

```text
Review the exact workflow, data-flow map, source routes and client disclosure.
For each proposed control, mark: statutory obligation, conditional obligation,
professional requirement, contractual requirement, or product risk policy.
Specify jurisdiction, effective date, owner and evidence needed. Resolve
uncertainty explicitly; do not approve a generic "all business AI" policy pack.
```
