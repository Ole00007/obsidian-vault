# The compliance mini-harness: build a bounded control layer

Product and regulatory assessment | 30 October 2026

There is a viable experiment here, but the phrase “legal compliance for all agentic harnesses” promises too much. My recommendation is a deterministic policy-and-evidence service around instrumented business actions, with narrow professional policy packs and explicit limits on what it can see or stop.

## What to build

Build a small policy decision service, an enforcement adapter at the executor, a human-review record and an evidence exporter. Use an LLM to draft explanations or suggest classifications only; a qualified owner approves legal interpretations and deterministic rules decide execution.

The first product outcome is: “No covered client-facing action executes with changed parameters, a missing authority, an unapproved data destination or an invalid approval, and the firm can reconstruct the decision.” That is testable; “makes your agents legally compliant” is not.

The proposed control flow is shown in `diagrams/control_boundary.svg`: instrumented runtime → enforcement adapter → policy decision → authorized executor → protected business system. Review and evidence are separate supporting paths; an observability feed is not an enforcement path.

## Where portability ends

| Integration | Can inspect? | Can stop before execution? | Commercial promise allowed |
|---|---|---|---|
| Elisa-controlled executor | Yes, for covered routes | Yes, if credentials/network prevent bypass | Enforced covered workflows |
| Instrumented Python/Node tool wrapper | Yes | Only if every execution path is wrapped and bypass is excluded | Enforced tested adapter scope |
| MCP proxy | MCP calls routed through it | Only routed calls; not shell/browser/direct SDK calls | MCP-scope controls |
| Model gateway | Model traffic through it | Can block that traffic, not arbitrary later actions | Model-boundary controls |
| OpenTelemetry/exported traces | After-the-fact visibility | No, by itself | Monitoring and evidence only |
| Closed third-party SaaS without an execution hook | Limited exported evidence | Not established | Register/assess, not enforce |
| Unmanaged local agent with broad credentials | Incomplete | No universal guarantee | Unsupported for enforcement |

These are proposed engineering boundary definitions, not claims of tested compatibility. A framework adapter is supported only after a conformance test demonstrates deny, approval, timeout, retry, cancellation and bypass behavior.

## Legal applicability: obligations are not universal

- **Italian professional AI use**: Art. 13 L.132/2025 limits AI to instrumental/supporting activities, with professional intellectual work predominant, and requires clear, simple and exhaustive information about the AI systems used. The text applies to intellectual professions, not only lawyers; implementation for accountancy needs the appropriate professional review ([Gazzetta Ufficiale, Art. 13](https://www.gazzettaufficiale.it/atto/serie_generale/caricaArticolo?art.versione=1&art.idGruppo=2&art.flagTipoArticolo=0&art.codiceRedazionale=25G00143&art.idArticolo=13&art.idSottoArticolo=1&art.idSottoArticolo1=10&art.dataPubblicazioneGazzetta=2025-09-25&art.progressivo=0)).
- **GDPR**: lawful basis, purpose limitation, minimization, processor contracts, security and international-transfer analysis remain relevant; special-category and criminal-offence data require separate analysis. DPIAs and Article 22 safeguards are conditional on the processing and decision context, not automatically triggered by every assistant ([GDPR](https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng)).
- **AI Act classification**: intended purpose and roles matter; Annex III's judicial use category concerns judicial authorities or use on their behalf and comparable ADR, not every ordinary law-firm research assistant. Other uses such as employment or creditworthiness may trigger different categories, so a legal/accounting label cannot settle classification ([AI Act, Article 6 and Annex III](https://eur-lex.europa.eu/eli/reg/2024/1689/oj/eng)).
- **AI Act timetable**: the reviewed 2026 amendment sets relevant Chapter III high-risk application dates at 2 December 2027 for Article 6(2)/Annex III and 2 August 2028 for Article 6(1)/Annex I; it also amends AI-literacy wording and provides a specific 2 December 2026 transition for Article 50(2) for systems placed on the market before 2 August 2026. Do not convert that transition into a blanket postponement of all transparency obligations ([Regulation 2026/1744](https://eur-lex.europa.eu/eli/reg/2026/1744/oj/eng)).
- **Human oversight and logging**: Articles 12, 14 and 26 contain requirements for high-risk systems, not a universal requirement to approve every AI write or keep every agent trace for six months. A universal approval gate can still be a product risk policy, but should be labelled as such ([AI Act](https://eur-lex.europa.eu/eli/reg/2024/1689/oj/eng)).
- **Breach response**: GDPR Article 33 gives the controller a conditional 72-hour supervisory notification duty from awareness and requires the processor to notify the controller without undue delay; an agent product should not collapse these into one clock ([GDPR](https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng)).

Counsel must approve role classification, data-processing purposes and the release policy. The service can gather evidence and enforce configured technical conditions, but cannot determine all professional duties, certify substantive advice or transfer the professional's responsibility to software.

## The CNF module: useful, if kept small

The actual CNF template describes potential support uses, GDPR/deontological duties, lawyer checking of outputs and sources, and signatures/acknowledgement; the Milan Bar describes it as an optional usable schema, not a mandatory exact form ([Milan Bar announcement](https://www.ordineavvocatimilano.it/it/news/informativa-sullutilizzo-di-strumenti-di-intelligenza-artificiale-ex-art-13-legge-23-settembre-2025-n132/p100-n2904), [template](https://www.ordineavvocatimilano.it/media/news/OTTOBRE2025/schema%20informativa%20IA.docx)).

My proposed module is a disclosure lifecycle within matter administration, not a new autonomous legal agent. It should create a draft from a counsel-approved template, record the actual systems/purposes used, obtain professional approval, record delivery and version history, and signal when relevant system use changes.

- **Store**: template ID/version/hash, firm and responsible professional, client/matter reference, covered purposes, system IDs, approved wording, approved_by/at, delivered_at/channel/evidence_ref, acknowledgement status, superseded version and counsel review reference.
- **Separate states**: drafted → professional-approved → delivered → acknowledged if applicable → superseded. A missing acknowledgement is not automatically a statutory invalidity; counsel determines the workflow policy.
- **Never conflate**: disclosure, client acknowledgement, GDPR lawful basis, consent where applicable, processing contract and authority to send.
- **Keep deployment truthful**: do not sign a template assertion that the system already meets GDPR/deontological requirements unless the actual configuration supports it.
- **Accountancy variant**: use a separately reviewed professional template rather than replacing “avvocato” mechanically throughout the CNF form.

## Product architecture and policy precedence

The gateway needs trusted identity and tenant context from authentication, not from model arguments. Each candidate action is normalized with tool/version, tenant, user, data labels, source rights, destination, payload commitment, object version, policy version and expiry before evaluation.

Use `deny > require_approval > allow`; an uncertainty or unavailable required control fails closed for consequential actions. A reviewer cannot override a hard denial by pressing approve; any exception is a separately authorized, versioned policy change.

An approval binds the canonical payload, attachments, recipient/destination, tenant, user, tool and policy version. Before execution, re-check identity, authority, expiry, revocation, current resource version and policy status; a changed payload requires a new decision.

Treat approval as authorization for a bounded action, not proof of exactly-once delivery. Use an idempotency key, transactional outbox where applicable, provider reconciliation and an `execution_unknown` state after ambiguous external timeouts; do not blindly resend emails or payments.

## Evidence without a new privacy problem

Keep operational logs content-minimized and separate from encrypted, purpose-limited evidence objects. Retain a payload commitment and protected evidence reference sufficient for authorized reconstruction; raw client text does not belong in broad telemetry or prompts sent to monitoring vendors.

Hashes are not anonymization and low-entropy values can be guessed, so consider tenant-keyed commitments and controlled access. Retention should have purpose-specific durations, deletion rules, legal holds and backup handling; signed/hash-chained records are tamper-evident under their trust assumptions, not proof that an underlying statement was true.

## Business model options

All numbers below are proposed pricing tests, not observed customer willingness to pay or approved offers. Keep model cost, implementation services and ongoing legal policy maintenance visible.

| Model | Buyer and unit | Experiment | Assessment |
|---|---|---|---|
| Embedded Elisa add-on | Firm/workspace | Test €99 and €199/month, with a bounded workflow and allowance | Best first validation |
| Builder/API licence | Vendor + active tenant or decision volume | Test €500/month platform minimum, scoped tenants and overage | Best scale path after portability proof |
| Enterprise deployment | Organization + governed workflows + support | Paid discovery, then custom contract | Attractive later; heavy obligations |
| Consultancy-only | Project/fixed deliverable | Source inventory, policies and evidence setup | Useful cash flow; not recurring product proof |
| Per-disclosure form | Document | Do not lead with it | Easy to copy; encourages compliance theatre |

Avoid charging for every blocked action as the central value metric. Prefer a workspace/workflow allowance with predictable limits, optional volume tiers and an auditable cost report.

## Validation gates and stop conditions

These are recommended experiment criteria, not evidence already achieved. The business should earn the next investment by meeting them.

- **Problem gate**: at least five structured buyer interviews include real current work, budget owner and a recent failure or costly review task; at least three agree to a priced pilot.
- **Value gate**: three firms repeatedly complete the same workflow; median total handling time including review falls by at least 25% against a measured baseline, without increased material error.
- **Safety gate**: zero unauthorized execution or cross-tenant exposure in the defined adversarial test set; measure false blocks and human-review load separately, and do not extrapolate “zero” to all possible attacks.
- **Portability gate**: one non-Elisa runtime passes the same conformance suite with no bespoke policy fork.
- **Economics gate**: recurring direct costs, including allocated legal policy maintenance and human support, fit the chosen price; support intensity must decline with repeat deployments.
- **Stop or pivot**: buyers want only a free template, integrations cannot prevent bypass, reviewers do not trust the evidence, or maintenance/assurance cost overwhelms subscription value.

## My take

Build the smallest demonstrable controlled workflow and make the evidence portable before making the product universal. The likely business is a vertical policy pack plus adapters and managed assurance, not a second general-purpose harness.

Buy or reuse commodity gateway/security capabilities where they fit, but verify enforcement and deployment terms. KLA's pre-action approvals/evidence, NeuralTrust's gateway controls and Langdock's inexpensive governance add-on make a generic compliance wrapper a weak standalone position ([KLA](https://kla.digital/), [NeuralTrust](https://neuraltrust.ai/pricing), [Langdock](https://www.langdock.com/pricing)).
