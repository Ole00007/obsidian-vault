# Agentic harnesses and AI assistants in Italy/EU

Decision report | 30 October 2026

The attractive opportunity is not another broad AI chat product. My assessment is that the better entry point is a repeatable professional workflow with controlled execution, visible human responsibility and exportable evidence, while leaving research and foundation-model capabilities to existing products.

## Define the market before comparing it

These are working analytical categories, not a claim that vendors use the terms consistently. A system can occupy several categories, so adding their revenues would double-count the market.

- **Harness/runtime**: executes the agent loop, tools, memory, permissions, retries and persistence. Hermes and LangGraph illustrate different implementations of this layer ([Hermes](https://hermes-agent.nousresearch.com/), [LangGraph](https://github.com/langchain-ai/langgraph)).
- **AI personal/work assistant**: the user-facing work surface that uses company context, connectors and agents. Dust, Langdock and Mistral offer combinations of these capabilities ([Dust](https://dust.tt/pricing), [Langdock](https://www.langdock.com/pricing), [Mistral](https://www.mistral.ai/pricing)).
- **Vertical assistant**: packages domain sources and professional workflows. Lexroom emphasizes Italian legal research, matter documents and drafting; TeamSystem and Genya embed AI into accounting software ([Lexroom](https://www.lexroom.ai/), [TeamSystem](https://www.teamsystem.com/commercialisti/teamsystem-studio/), [Genya](https://www.wolterskluwer.com/it-it/solutions/genya/genya-per-commercialisti)).
- **Governance/control layer**: inventories, evaluates, blocks, approves or records AI activity. NeuralTrust, Holistic AI and KLA explicitly market overlapping controls, so this is not an empty category ([NeuralTrust](https://neuraltrust.ai/pricing), [Holistic AI](https://www.holisticai.com/), [KLA](https://kla.digital/)).

“Agentic” should be tested by demonstrating tool use, state changes, recoverability and permissions, not accepted from a product headline. Research copilots, deterministic automation and autonomous agents remain different operational propositions even when marketed together.

## Demand evidence, without inflating TAM

Eurostat reports that 20.0% of enterprises with at least ten employees or self-employed persons in the surveyed sectors used AI in 2025, versus 13.5% in 2024; this is broad AI adoption, not harness adoption and not a survey of solo practices ([Eurostat](https://ec.europa.eu/eurostat/web/products-eurostat-news/w/ddn-20251211-2)). ISTAT reports 16.4% for Italian enterprises with at least ten employees in 2025, versus 8.2% in 2024, and 53.1% for large enterprises ([ISTAT](https://www.istat.it/wp-content/uploads/2025/12/Statreport_ICT2025.pdf)).

Cassa Forense's 2025 report records 233,260 members in 2024, including 216,884 active members; its January 2025 Censis survey found 27.5% reporting daily professional AI use, with over 28,000 respondents ([Cassa Forense](https://www.cassaforense.it/media/munf4vli/rapporto-avvocatura-2025.pdf)). The commercialisti profession had 119,050 registered professionals at the end of 2025 according to its 2026 report ([Fondazione Nazionale di Ricerca dei Commercialisti](https://www.fondazionenazionalecommercialisti.it/node/1911)).

These are people and survey populations, not independent purchasing organizations. Do not multiply all registered professionals by a firm subscription, treat survey adoption as paying demand, or describe software revenue scenarios as the measured size of the Italian agent market.

No reliable, non-overlapping Italy/EU revenue series for this specific emerging category was established in this research. The workbook therefore provides transparent bottom-up commercial scenarios, not an invented market valuation; a global TAM is intentionally outside the confirmed scope.

## Competitor groups and business models

The complete 21-row matrix is in the workbook and CSV. The following groups explain the commercial pressure rather than claiming a market-share ranking.

### Horizontal platforms and runtimes

- **Claude / Cowork**: Team includes Cowork and Claude Code, with Standard seats at $20 per seat/month billed annually or $25 monthly; the page also lists Premium and usage-based enterprise/managed-agent options. EU eligibility for each capability is not established by this pricing page, so treat it as a platform benchmark pending local feature confirmation ([Claude pricing](https://claude.com/pricing)).
- **ChatGPT Business**: markets task-oriented ChatGPT Work, Codex and always-on Dots for Premium users in eligible markets; the reviewed page has no public price and does not identify EU eligibility for Dots. Include it as a substitute and distribution benchmark, not as a verified Italy-wide deployment option for every feature ([ChatGPT Business](https://chatgpt.com/business/business-plan/)).
- **Langdock**: seats plus workflow/API usage and a governance add-on; the page displays €25 per standard user/month excluding VAT and governance at €3.50 per user/month, free until 1 January 2027, with annual and volume variants. Its governance already includes agent approval, policy templates and update checks; MCP governance is labelled “coming soon” ([Langdock pricing](https://www.langdock.com/pricing)).
- **Dust**: seat-and-credit model; the FAQ gives Pro at €30 monthly or €24 per seat/month billed yearly and Max at €150 monthly or €120 yearly-equivalent, excluding VAT. API usage is separately priced, while enterprise adds deployment and contractual controls; connector limits are inconsistent across parts of the page and should be confirmed ([Dust pricing](https://dust.tt/pricing)).
- **n8n**: execution-based pricing rather than per-step or per-user charging; Starter is €20/month billed annually for 2,500 executions and Pro €50 for 10,000, with self-hosted Business and custom Enterprise options. The page lists human approval for tool calls and enterprise credential/logging features, so an approval button alone is weak differentiation ([n8n pricing](https://n8n.io/pricing/)).
- **Microsoft Copilot Studio**: agent-building and distribution inside the Microsoft ecosystem, with seat, prepaid-credit and pay-as-you-go options; the Italian page displays €187.20/month for a 25,000-credit pack but also a market-availability warning. Treat the displayed amount as a page snapshot and local purchasability as unresolved, not as a validated Italian quote ([Microsoft Italy](https://www.microsoft.com/it-it/microsoft-copilot/microsoft-copilot-studio)).
- **Mistral**: the fetched current pricing page is branded Mistral Vibe and lists Pro at $14.99/month, Team at $24.99/user/month, API usage and custom enterprise deployments. Do not silently relabel the current page “Le Chat” or infer EU-only processing from the brand's origin ([Mistral pricing](https://www.mistral.ai/pricing)).
- **Hermes**: MIT-licensed runtime with memory, skills, scheduling, tools and isolated subagents; the runtime is free, while model providers and optional hosted/Portal services have separate costs. This is an implementation substrate, not evidence of an Italy-specific regulated service or automatic safety assurance ([Hermes official site](https://hermes-agent.nousresearch.com/)).
- **LangGraph**: low-level orchestration and persistence framework with MIT code; interrupt/resume mechanisms need a durable checkpointer and careful idempotency. Its licence and control-flow primitives do not supply Elisa's business authorization policy ([licence](https://github.com/langchain-ai/langgraph/blob/main/LICENSE), [interrupt documentation](https://docs.langchain.com/oss/python/langgraph/interrupts)).

### Legal verticals

- **Lexroom**: the most immediately relevant Italian benchmark in this set, with research, document analysis, matter context and drafting; the page lists a starting price of €99/month on an annual contract excluding VAT for one module/user, up to 200 documents and a Word add-in. Its claim of more than 20,000 European daily professional users is vendor evidence, not independently audited adoption; “zero hallucinations, zero risks” must not be repeated as a verified property ([Lexroom](https://www.lexroom.ai/)).
- **One LEGALE Expert AI**: conversational research, document analysis and draft opinions grounded in Wolters Kluwer authored and official content; the reviewed feature page does not establish price or contract unit. Its source-content advantage is more relevant than superficial chat-interface similarity ([One LEGALE](https://www.wolterskluwer.com/it-it/solutions/one/onelegale-ai/one-ai-assisstant)).
- **Legora**: markets collaborative legal work and an agent that plans, executes, reviews and delivers; its site offers a live demo but no public price. Its qualitative customer study is described as covering 30 customers across nine countries, not a measured European market share ([Legora](https://www.legora.com/)).
- **Harvey**: markets agents, professional workflows, in-house use and shared Spaces with governance/ethical walls, with named customer testimonials including Deutsche Telekom, Repsol and Cuatrecasas; pricing is not established by the reviewed homepage. This is an enterprise professional-work benchmark, not proof of Italian procedural-law coverage ([Harvey](https://www.harvey.ai/)).
- **Microsoft Word Legal Agent**: Frontier availability in Word for Windows, with tracked redlines and a deterministic edit-resolution layer; it explicitly does not replace professional legal judgment. It is a workflow/distribution substitute for a custom contract-editing experience, not an open component to fork ([Microsoft product announcement](https://techcommunity.microsoft.com/blog/microsoft-copilot-blog/word-legal-agent-in-frontier/4516218)).

### Accountancy verticals

- **TeamSystem Studio AI**: AI is integrated into bookkeeping, reconciliation, financial statements, tax and payroll workflows; the site offers a quote rather than a public price. The page describes both suggestions and automatic activities but does not establish which actions execute without review ([TeamSystem](https://www.teamsystem.com/commercialisti/teamsystem-studio/)).
- **Genya Expert AI**: integrated preparation, checking and tax-return support, including ministerial instructions and an agent, with the professional remaining central to decisions; public pricing and specific external APIs were not established. Its incumbent workflow ownership is a stronger moat than generic model access ([Genya](https://www.wolterskluwer.com/it-it/solutions/genya/genya-per-commercialisti)).
- **Dext France**: document collection, extraction, classification, reconciliation and anomaly identification; accountant subscription pricing varies with the number of client files, but amounts are not published on the reviewed page. More than 2,000 firms and 290,000 businesses in France are vendor claims, as are its accuracy and security assertions ([Dext France](https://dext.com/fr)).
- **Pennylane**: integrated finance/accounting with AI listed on its homepage, but neither the homepage nor pricing page establishes general autonomous-agent execution. French business plans shown are €7/€14/€24/€79 per month excluding tax, with conditions including one user and 1,200 annual invoices; those are not accounting-firm licence prices ([Pennylane](https://www.pennylane.com/fr), [business pricing](https://www.pennylane.com/fr/tarifs)).

### Direct and adjacent compliance competition

- **NeuralTrust**: direct overlap on gateway enforcement, permissions, tool/MCP protection, PII detection and monitoring; Free and $49/month Standard plans combine quotas or wallet credits with usage charges, excluding model-token charges. A standalone commodity security gateway would compete against an already low-priced entry point ([NeuralTrust](https://neuraltrust.ai/pricing)).
- **KLA**: the closest conceptual overlap reviewed, with pre-execution policy decisions, human approvals and sealed evidence bundles through Python/Node SDK or other integration routes. Its displayed activity figures are explicitly examples and must not be mistaken for production traction; pricing is not public ([KLA](https://kla.digital/)).
- **Holistic AI**: enterprise inventory, assessments, monitoring, governance and supervisory agents, sold through demos with no public price on the reviewed page. It competes against the enterprise-control vision, while website capability claims still need technical validation ([Holistic AI](https://www.holisticai.com/)).

## Which buyer should come first?

The comparisons below are analyst judgments for this project, not market statistics. They reflect the need to demonstrate a workflow and its controls before selling a horizontal platform.

| Buyer | Attractive reason | Main obstacle | Proposed role |
|---|---|---|---|
| Small Italian law firms using Elisa | Concrete matter, disclosure, draft and approval workflow; accessible design-partner test | Budget sensitivity; manual review must still save time | First pilot buyer |
| Small accounting practices | Repeated client-document and exception workflows | Deep incumbent integration; country-specific filing and bookkeeping rules | Second vertical discovery |
| Agent builders / vertical SaaS vendors | Embeddable API, multi-tenant contracts, one integration can reach many firms | Demand proof, SDK support, ability to bypass | Productization buyer after pilots |
| Enterprise legal/finance teams | Larger governance need and potential contract value | Procurement, deployment, assurance and vendor-review burden | Later design partner, not initial default |
| General businesses using many AI agents | Broad potential surface | Unclear urgent use case; shadow-AI visibility and inaccessible execution paths | Do not lead with this segment |

Prefer one small-firm administrative workflow over an initial substantive-law specialty: document intake, a client/matter summary, a draft response and controlled dispatch. This preserves all practice areas as the long-term catalogue without claiming that every practice-area playbook is launch-ready.

For accountancy, the comparable first workflow is client-document collection and exception triage, with a draft query to the client. Do not initially automate tax filing, ledger posting, payroll decisions or payments; investigate the incumbent integration route and reviewer responsibility first.

## Positioning, content and commercial opportunity

My proposed positioning is: “For Italian professional firms and the software builders serving them, Elisa's control layer connects AI work to the responsible professional, the permitted data use, the approved action and a reviewable evidence record.” This is a proposed value proposition, not a claim of current capability.

The defensible asset would be tested Italian workflow packs, policy-to-evidence mappings, adapter conformance tests and operational experience. A CNF form alone, a prompt saying “follow GDPR,” a wrapper around an LLM, or a generic approval inbox is insufficient.

Recommended content experiments are a worked Art. 13 disclosure lifecycle, a demonstrated changed-recipient approval rejection, a readable source-licence register and an honest “what we cannot intercept” integration matrix. These are hypotheses about useful content, not SEO gaps proven by keyword or traffic data; no systematic social, SEO or publishing-frequency audit was performed.

## Commercial sizing and validation

Use paid pilots to measure willingness to pay and support cost before extrapolating. Suggested tests are €99 versus €199 per firm/month for the embedded workflow, and a separate €500/month platform minimum hypothesis for builders; none is a market price or approved tariff.

The workbook's illustrative cases use 25, 100 and 300 paying firms at €149/month, producing annual recurring revenue of €44,700, €178,800 and €536,400 respectively. These are arithmetic scenarios, excluding VAT, services revenue and churn, not estimates of obtainable market size.

Validate with a paid workflow, not an enthusiasm survey: ask the buyer to supply a representative case, nominate a reviewer, accept the integration boundary and choose between a priced pilot and continuing with current tools. A commercial “go” should require repeatable value, sustainable support and an independently integrated second runtime, not only Elisa working in a demo.
