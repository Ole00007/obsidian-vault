# The questions that must survive a tough review

Working challenge sheet | 30 October 2026

The suggested answers below are my recommendations, not answers attributed to you or Backy. Use the “proof required” column to prevent a confident verbal answer from substituting for evidence.

## Questions for Olesia

| ID | Question | Recommended answer to test | Proof required |
|---|---|---|---|
| Q01 | Are we selling a useful controlled workflow or relief from fear of regulation? | A controlled workflow with measurable time savings and evidence; no compliance guarantee. | A buyer names the workflow and pays to solve it. |
| Q02 | Who signs the first contract and owns the budget? | A managing partner/operations owner in a small Italian firm, not “all business users.” | Named buyer, purchasing authority and price response. |
| Q03 | Why would they pay when a disclosure template is free? | For actual-use tracking, approval enforcement and reconstructable evidence integrated with work. | Demonstration using a real representative process. |
| Q04 | What will we deliberately refuse to automate? | Pilot excludes filings, payments, final advice and unsupported deadline calculations. | Product boundary accepted in writing. |
| Q05 | Will you accept one workflow first while keeping all practice areas on the roadmap? | Yes, practice-area breadth does not imply simultaneous activation. | Named first workflow and pack activation rule. |
| Q06 | What is the maximum tolerable human support and legal maintenance per account? | Define a direct-cost ceiling before setting a permanent price. | Measured support time and allocated counsel cost. |
| Q07 | Are the prospective 7–10 law-firm contacts still available? | Reconfirm access; previous interest is not a pilot commitment. | Named consenting contacts and current interview access. |
| Q08 | Who owns professional policy updates and emergency suspension? | Named qualified counsel plus a technical release owner; neither role is an anonymous “agent.” | Engagement, responsibility matrix and fallback reviewer. |
| Q09 | Can we stop building if buyers will not pay? | Yes; use paid-pilot and portability gates before standalone investment. | Written go/no-go criteria. |
| Q10 | Which claim will we refuse to put on the homepage? | “Compliant with all laws,” “zero risk,” and “works with every harness.” | Approved messaging and terms. |

## Questions for Backy

| ID | Question | Acceptable answer shape | Proof required |
|---|---|---|---|
| Q11 | What already exists for approvals, auth and execution? | Inventory first; wrap, extend or replace with reasons. | File paths, migrations, tests, sequence diagram. |
| Q12 | What stops an agent calling a provider directly? | No provider credentials in agent context; restricted network and executor-only access. | Attempted bypass fails in a test. |
| Q13 | Can one tenant resume another tenant's graph or read its vectors? | Denied at every storage/load boundary, not just thread-name prefixing. | Adversarial cross-tenant tests. |
| Q14 | What happens if the user approves then the recipient changes? | Old decision becomes invalid; fresh review required. | Payload/recipient/attachment mutation tests. |
| Q15 | What if the provider executes but times out? | Unknown state, reconcile, no blind retry. | Simulated accepted-but-timeout fixture. |
| Q16 | Can a reviewer approve an action forbidden by policy? | No; exception requires a separately authorized policy process. | Deny-precedence test. |
| Q17 | What if the policy service is down? | Consequential actions fail closed; safe reads follow explicit degraded-mode rules. | Fault-injection test and user message. |
| Q18 | Which tools are enabled by `normativa` and which are actually allowed? | Explicit tool and source-route allowlist; case-law routes disabled. | Pinned manifest and negative tests. |
| Q19 | What exactly is in logs, checkpoints and backups? | Content-minimized telemetry plus protected evidence with retention and access policies. | Sample exports and deletion/restore tests. |
| Q20 | Can the same rule work in Hermes and Elisa without rewriting it? | Shared action schema and conformance suite; runtime adapters only. | Second-runtime integration test. |
| Q21 | Is the CNF module in code or only in a document? | State the actual implementation and test status, including delivery evidence. | PR/test references, no narrative substitution. |
| Q22 | Who can update a tool, scanner, model or legal pack? | Controlled change, pinned versions, regression evaluation and rollback. | Release manifest and failed-update drill. |

## Questions for counsel and professional reviewers

| ID | Question | Answer required before release | Proof required |
|---|---|---|---|
| Q23 | What does Art. 13 require for this actual workflow and client relationship? | Approved disclosure content, timing, system identification and change handling. | Signed policy note and reviewed template. |
| Q24 | Which party is controller/processor and which purpose applies to each data flow? | A per-flow assessment, including provider retention, access and transfers. | Data-flow map, DPA/subprocessor review. |
| Q25 | Does the intended use trigger AI Act high-risk obligations or a change of provider role? | Case-specific role/purpose classification under current law. | Versioned applicability record. |
| Q26 | Which legal sources may we download, transform, embed and redistribute? | Source-route-specific answer, separate from code licence. | Rights register with permitted uses and conditions. |
| Q27 | What must we retain, delete or hold, and who can inspect it? | Purpose-specific schedule and incident process. | Approved retention and access policy. |
| Q28 | Who may approve each class of professional action? | A role matrix based on actual responsibility, not merely admin privilege. | Named professional owner and delegated limits. |

## Questions for customer discovery

| ID | Question | Strong evidence | Weak answer to challenge |
|---|---|---|---|
| Q29 | Show your last case where AI output needed checking or correction. | Real workflow, artifacts, review effort and consequence. | “AI compliance is important.” |
| Q30 | What do you already pay for and what would this replace? | Current tools/costs, renewal owner and alternative. | “There should be a budget.” |
| Q31 | Would you pay €99 or €199/month for this bounded workflow? | Priced pilot commitment with scope. | Free trial interest without a buyer. |
| Q32 | What would make you reject the product after using it? | Specific false blocks, delays, evidence gaps or privacy conditions. | “It must be perfect.” |
| Q33 | How many actions can your reviewer realistically handle? | Baseline volume, queue capacity and escalation owner. | “A human will check everything.” |
| Q34 | Would you accept a vendor-neutral layer outside your current software? | Approved API route, data contract and implementation owner. | “It integrates with everything.” |

## Suggested opening exchange

Olesia: “I want to support legal and accountancy firms without narrowing the long-term vision.” My challenge: keep that vision, but name the first paid action chain and the actions we will not support; otherwise each new sector multiplies professional, integration and testing obligations.

Backy: “We already have an approval table.” My challenge: show that the executing service rejects a stale, cross-tenant, changed-recipient or replayed approval; a table or a modal alone does not establish enforcement.

Counsel: “Use the CNF template.” My challenge: approve the actual system inventory, data flows and delivery process too; a correct form cannot make an incorrect technical statement true.
