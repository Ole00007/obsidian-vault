# Agentic assistants and the Elisa compliance opportunity

Italy/EU decision and engineering pack | 30 October 2026 | Review v2.0

## Decision in one paragraph

My recommendation is a conditional **go for an Elisa-embedded professional AI control layer**, not a go for a universal compliance harness. Start with client-document intake, draft preparation and approved delivery in small Italian legal firms; retain accountancy and enterprise requirements as separate expansion tracks, not simultaneous launch commitments.

## Read in this order

- **01_market_report.md**: market categories, 21 benchmark products/projects, business models, buyer comparison, positioning and market-sizing limits.
- **02_mini_harness_assessment.md**: product thesis, legal applicability, integration boundaries, business-model experiments and kill criteria.
- **03_elisa_architecture_review.md**: corrections to the supplied preview and pasted planner discussion, including the CNF module and Normattiva licensing.
- **04_questions_and_answer_bar.md**: difficult questions for Olesia, Backy, counsel and prospective customers; recommended answers are hypotheses, not recorded decisions.
- **05_engineering_handoff.md**: discovery prompt, architecture contracts, release gates, responsibilities and agent briefs.
- **06_source_links_and_audit.md**: separate source list, including every entry in the supplied source list and corrected verification statuses.
- **agentic_market_workbook.xlsx**: editable sheets for competitors, buyer choices, workflows, controls, backlog, evaluation cases, questions, and illustrative economics.
- **data/**: matching CSV/JSON for agent ingestion. `research_data.json` is the canonical structured research file; build contracts and examples are separate.
- **diagrams/**: standalone SVG and PNG diagrams for humans, with textual equivalents in the reports.

## What this pack is, and is not

The input files were the architecture preview v0.9 and the source-links document, together with the pasted account of later v1 changes. The final five-file v1 ZIP and Elisa source code were not supplied; this pack is an independent review and proposed upgrade, not a verified patch to that missing ZIP or evidence that any module has been implemented.

All engineering recommendations are proposed and unapproved until assigned and accepted. No production application, provider integration, legal sign-off, penetration test, paid pilot or customer interview was performed.

## Evidence rules

Vendor claims are labelled as claims; prices are page snapshots, not quotations. `n.a.` means not established from the reviewed evidence, not that a capability is absent.

Legal statements are research inputs for qualified Italian/EU counsel, not a legal opinion or certification. Primary law and official documentation take precedence over repository summaries; proposed company controls are deliberately separated from statutory obligations.

## Important corrections

- **Normattiva**: the complete page describes CC BY 4.0 from 1 January 2026, following an earlier non-commercial experimental phase; the old “NC may block commercial use” conclusion was based on an incomplete passage. Source-route, attribution, third-party material and access terms still need review ([official licensing page](https://dati.normattiva.it/Dati-disponibili)).
- **CNF**: the actual template exists and was read; it covers supporting uses, professional review and client acknowledgement, not an automated certificate of GDPR compliance ([official template](https://www.ordineavvocatimilano.it/media/news/OTTOBRE2025/schema%20informativa%20IA.docx)).
- **AI Act**: use the amended timetable, not a cached summary of the original 2024 dates; the reviewed 2026 amendment changes relevant high-risk dates to 2 December 2027 and 2 August 2028 ([Regulation 2026/1744](https://eur-lex.europa.eu/eli/reg/2026/1744/oj/eng)).

## Deliverable contract

The primary decision is whether to validate, build, partner or stop, as of 30 October 2026. The scope is Italy/EU demand and compliance, comparing small professional firms, enterprise teams and agent/SaaS builders; international products are included only as relevant benchmarks or implementation dependencies, not as a US/UK legal-market study.

Reports carry the reasoning and citations; the workbook enables filtering and sensitivity changes; machine files carry identifiers, dependencies, evidence classes and approval gates. Illustrative revenue scenarios are not TAM estimates or forecasts, and no inferred firm counts or unverified adoption rates are used as market facts.
