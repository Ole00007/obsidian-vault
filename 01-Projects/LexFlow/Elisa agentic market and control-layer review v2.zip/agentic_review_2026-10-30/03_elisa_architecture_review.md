# Elisa planner review: good direction, not a build-ready specification

Architecture review | 30 October 2026

The supplied preview has a sound separation between orchestration, narrow tools and controlled execution. Its major weakness is that several safety properties are stated as principles rather than enforced, testable contracts; the pasted v1 summary improves scope disclosure but does not prove that implementation changed.

## What I would retain

- **Elisa remains the orchestrator**: external components should not replace the existing product identity or own unrestricted credentials.
- **Deterministic execution**: conflict checking, document mutations and authorization belong in code, with human-reviewed domain rules.
- **Tenant-neutral public-law index**: keep it physically/logically distinct from matter documents and derived tenant content.
- **Approval binding**: the preview already anticipates payload hashes, expiry and idempotency; make this an executable security boundary.
- **Evidence labels and reversible plugins**: preserve unverified labels, pinned dependencies, kill switches and staged enablement.

These judgments review the supplied documents, not source code. The presumed Flask/Postgres/RLS stack, current approval mechanism, hosting and collaborators remain unverified until Backy provides repository evidence.

## Corrections to the planner's claims

| Issue | Finding | Proposed change |
|---|---|---|
| Normattiva non-commercial blocker | The full official page explicitly moves from the experimental NC phase to CC BY 4.0, including from 1 January 2026 ([licensing page](https://dati.normattiva.it/Dati-disponibili)). | Replace the blanket commercial-use warning with source-route attribution/access review. Use synthetic fixtures until the selected route is approved; “private dev” is not a universal licence exception. |
| Judgments outside Art. 5 | Article 5 itself refers to official acts and does not expressly state the preview's categorical exclusion of judgments ([Article 5](https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:legge:1941-04-22;633~art5)). | Remove the categorical claim. Review official text, database rights, editorial material, privacy and access conditions separately with counsel. |
| `normativa` means statutes-only | The repository says this profile also includes Brocardi, Italgiure, TAR/CdS, CGUE and other sources ([mcp-legal-it](https://github.com/capazme/mcp-legal-it)). | Enumerate permitted tool IDs and source routes; disable case-law tools explicitly. A profile label is not a licence or launch-scope boundary. |
| Graph permission | The raw permission table lists Calendars.ReadBasic for work/school delegated and application access; delegated personal Microsoft accounts are unsupported ([getSchedule reference](https://learn.microsoft.com/en-us/graph/api/calendar-getschedule?view=graph-rest-1.0)). | Test both authorized modes and classify account type. Avoid claiming all Outlook users are supported. |
| Graph batch/window | getSchedule supports up to 20 entities and a period shorter than 62 days; returned details depend on permissions/sharing ([Graph overview](https://learn.microsoft.com/en-us/graph/outlook-get-free-busy-schedule)). | Batch, cap intervals, handle throttling and strip subjects/locations when only free/busy is needed. |
| CNF module added | The template is confirmed, but neither attached preview nor pasted narrative demonstrates deployed code ([CNF schema](https://www.ordineavvocatimilano.it/media/news/OTTOBRE2025/schema%20informativa%20IA.docx)). | Specify and test a disclosure lifecycle; mark “proposed” until implemented and accepted. |
| AGPL means avoid | AGPL allows commercial use; Section 13 creates source-offer obligations for modified versions used over a network ([GNU AGPL](https://www.gnu.org/licenses/agpl-3.0.en.html)). | Classify Lexia as copyleft/legal-fit review, not inherently unsafe or unusable. Integration boundaries affect the analysis. |
| LangGraph licence unknown | The actual licence file is MIT ([LICENSE](https://github.com/langchain-ai/langgraph/blob/main/LICENSE)). | Record the licence at the pinned commit; do not rely on mutable `main`. |
| Stars/commits demonstrate trust | The supplied counts are snapshots, not an independent security test. | Remove them from release criteria; require source review, pinned digest, tests and a vulnerability/update owner. |
| OpenContracts telemetry default | The current README describes telemetry and opt-outs but does not explicitly establish the default in the extracted page ([OpenContracts](https://github.com/Open-Source-Legal/OpenContracts)). | Inspect configuration at the chosen commit rather than repeat a default claim. Disable unneeded telemetry and replace documented demo credentials. |
| Entire Anthropic repo is US-only | The README includes US-specific workflows but does not define the entire repository as a single jurisdiction ([README](https://github.com/anthropics/claude-for-legal/blob/main/README.md)). | Review individual skills/connectors; never transplant substantive foreign-law content without jurisdiction checks. |

## Architecture defects that should block a consequential-action release

### Authorization cannot be a graph pause

A LangGraph interrupt pauses execution and resumes a node from its beginning; it is not, by itself, an authorization system ([LangGraph interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts)). Backy must demonstrate authorization at the executor, independent of the model's proposed action and independent of a UI boolean.

Persist the proposal before review, authenticate the reviewer and check their authority, bind the decision to the action and policy, then revalidate before execution. A changed attachment, recipient, resource version or legal-policy version invalidates the old approval.

### RLS is necessary but not the whole tenant boundary

The preview's tenant-prefixed thread ID is a naming convention, not an access-control mechanism. Require authorization when loading checkpoints, object storage, vector results, caches, exports, background jobs and evidence, as well as SQL rows.

Backy should verify application roles cannot bypass RLS, test table-owner behavior, constrain service credentials and check pooled connection context/reset semantics. A passing SQL test does not prove a search index, worker or document export is tenant-safe.

### “Every write needs approval” needs a precise scope

The system must write internal drafts, checkpoint state and audit metadata to function. Classify internal authorized storage separately from consequential business mutations; otherwise the design recurses into approval records needing their own approvals.

Suggested pilot policy: authenticated in-tenant reads are allowed under data rules; draft/checkpoint storage is system-authorized and tenant-scoped; external sends and business-record mutations require specific approval; payments and filings are disabled. A model's `class: read` label must never control the actual permission.

### Prompt sanitization is not isolation

Stripping hidden Unicode or comments is not a security boundary and may damage relevant legal text. Preserve original document bytes, parse into a quarantined representation, treat content as untrusted, constrain tools and egress, and test hostile documents against an authoritative executor.

Scanner bypasses have been documented, so a clean scan should be one input rather than a safety certificate ([CSA research note](https://labs.cloudsecurityalliance.org/research/csa-research-note-ai-agent-skill-scanner-bypass-20260610-csa/)). Pin the scanner and ruleset as well as the dependency; `@latest` is unsuitable for reproducible release evidence.

### Citation validity has multiple layers

The fact that a string matches a retrieved source does not establish that it supports the proposition, is legally current for the relevant date, or applies to the jurisdiction and facts. Add source identity, temporal version, jurisdiction, pinpoint, quotation accuracy, claim support, conflicting authority and human-review status.

Do not present “No citation, no claim” as meaning every administrative sentence requires legal authority. Apply the strict rule to substantive legal propositions, and distinguish inability to retrieve evidence from a negative legal conclusion.

### Procedural deadlines need an independent oracle

A deterministic calculation is only as reliable as its encoded legal rules. Cross-checking Elisa against another implementation of the same interpretation can reproduce the same error.

Keep authoritative source/version, trigger event, notification method, proceedings type, holidays, suspension applicability and exceptions in the test case. A practising lawyer must sign off independent expected results; unsupported cases return “requires review,” not an invented date.

### Exactly-once external actions are not guaranteed

An idempotency key cannot guarantee a remote provider supports deduplication. A timeout after acceptance must become `execution_unknown` until reconciled, not an automatic resend.

Separate intent, attempt, provider response and final observed state. Use transactional outbox semantics for local durable work, reconcile calendar IDs/email IDs, and define cancellation/compensation per provider.

## Keep CNF, reduce other launch scope

The CNF feature is not overload when it is a small versioned document/evidence lifecycle. It becomes overload if it grows into an autonomous legal adviser, a complete GDPR suite or a universal register of every tool the firm uses outside Elisa.

Retain all practice areas in the product roadmap as requested, but enable only independently reviewed packs. Parallel engineering cannot remove the counsel capacity constraint, and “all in scope” must not mean “all legally approved at launch.”

OpenContracts should remain a spike, not a required platform dependency: compare a small extraction service against its broader document platform, including storage, queues, tenant isolation and patching obligations. Do not automatically adopt per-tenant full instances without assessing cost and operational load.

## The revised release ladder

| Gate | Deliverable | Exit evidence |
|---|---|---|
| P0 Discovery | Actual stack, current controls, source rights, data flows | Backy inventory and counsel issue register; no production mutation |
| P1 Enforcement foundation | Tenant-bound executor, normalized actions, policy decisions | Deny/bypass, identity, tenant and replay tests |
| P2 One workflow | Intake → summary/draft → review → approved delivery | End-to-end evidence bundle and ambiguous-timeout recovery |
| P3 Professional readiness | CNF lifecycle, evaluated citations, incident/retention controls | Counsel-approved policy pack and pilot acceptance |
| P4 Portability | Second runtime adapter | Same policy and conformance tests, no policy fork |
| P5 Expansion | Accounting/enterprise and more legal packs | Separate demand, integration and professional sign-offs |

No calendar delivery promises are embedded in this ladder. Legal effective dates elsewhere in the pack are evidence, not project schedules.

## Verdict on the planning session

The planner made useful architectural choices but treated too many “read the repo,” “add a module,” and “use approvals” statements as if they were implementation-grade decisions. The licensing reversal shows why complete primary-source text, evidence provenance and a correction log are product requirements, not documentation extras.

I would send Backy the discovery brief and blocking tests before sending a broad build mandate. The first success criterion is one safely bounded workflow that produces understandable evidence, not the number of agents, plugins or practice areas assembled.
