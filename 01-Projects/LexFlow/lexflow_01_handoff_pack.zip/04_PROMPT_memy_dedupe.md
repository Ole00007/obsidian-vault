# PROMPT: MEMY (dedupe + relocate LEGAL files)
```text
ROLE: Memy. Task: compare, dedupe, relocate. DRY-RUN FIRST. No deletions ever.

SOURCE: "/Users/olesiarasing/Desktop/projects/Products & Services/LEGAL"   (quote path: contains spaces and &)
REFERENCE (read-only, NEVER modify): /Users/olesiarasing/Projects/lexflow
ARCHIVE_EXACT: /Users/olesiarasing/Projects/_archive/legal-dedupe-<YYYYMMDD>/
ARCHIVE_REVIEW: /Users/olesiarasing/Projects/LEGAL_backup/<YYYYMMDD>/
TARGET_ROOT: /Users/olesiarasing/Projects/

PRE-CHECKS (abort if any fails)
1. Check locks: ls ~/Projects/.agent-locks/ ; any lock covering SOURCE or REFERENCE -> abort that file.
2. Skip any file modified in last 30 min (active work): find "$SOURCE" -mmin -30
3. Skip any file open by a process: lsof +D "$SOURCE" (any hit -> skip + flag ACTIVE)
4. Skip anything under .git/, node_modules/, .venv/, .env*, *.key, *.pem (flag SECRET, report only)
5. Create your own lock before moving: ~/Projects/.agent-locks/memy-legal-dedupe.lock (agent, paths, start time); remove when done.

STEP 1 INVENTORY (no changes)
find "$SOURCE" -type f -not -path "*/.git/*" -print0 | xargs -0 shasum -a 256 > /tmp/legal_src.sha
(cd /Users/olesiarasing/Projects/lexflow && find . -type f -not -path "./.git/*" -not -path "*/node_modules/*" -not -path "*/.venv/*" -print0 | xargs -0 shasum -a 256) > /tmp/lexflow_ref.sha

STEP 2 CLASSIFY each source file
- EXACT_DUP: same sha256 as a file in REFERENCE -> ARCHIVE_EXACT (keep relative path)
- NEAR_DUP: same filename/relative path but different hash -> ARCHIVE_REVIEW (never overwrite either side; write diff summary)
- UNIQUE: no match -> relocate under TARGET_ROOT to the relevant folder (match by topic/ext; mirror the lexflow structure if it fits; else TARGET_ROOT/legal/<topic>/). Never inside ~/Projects/lexflow unless I approve.
- ACTIVE / SECRET: skip, report.
Folders: classify files first; move folder only if ALL its files share one class; else move per file; remove empty dirs only after verified.

STEP 3 DRYRUN_REPORT.md (table: path | class | hash | action | destination | reason) saved to ~/Projects/_archive/DRYRUN_REPORT_<date>.md. STOP. Wait for exact reply: "APPROVED: execute moves".

STEP 4 EXECUTE (after approval)
- Use mv -n (no overwrite). Verify sha256 after move; log to MOVE_MANIFEST.csv (from,to,sha,time,class).
- On any mismatch/error: stop, restore from manifest, report.

STEP 5 NOTIFY (HARD RULE: no notify = task not done)
Send to the whole agent roster (admy, backy, and every agent in roster) AND append to ~/Projects/.agent-bus/NOTIFY.md:
  [<time>] memy MOVED <n> files | exact-dup -> _archive/... | review -> LEGAL_backup/... | unique -> <paths> | manifest: <path> | rollback: bash rollback.sh
Also generate rollback.sh from MOVE_MANIFEST.csv (mv back).

NEVER: delete, overwrite, touch locked/active files, edit the lexflow repo, move secrets, run during Admy deploy freeze.
```
