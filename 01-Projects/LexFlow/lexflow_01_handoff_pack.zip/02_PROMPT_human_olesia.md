# Your runbook (Olesia)

## 1. Save files (see 00_README_ORDER.md)

## 2. Unzip
```bash
mkdir -p ~/Projects/lexflow-handoff && cd ~/Projects/lexflow-handoff
unzip ~/Downloads/lexflow_01_handoff_pack.zip -d pack1
unzip ~/Downloads/lexflow_02_memory_architecture_pack.zip -d pack2
open pack2/docs/lexflow_memory_architecture.html
```

## 3. Feed order
1. Paste `03_PROMPT_admy_orchestrator.md` to Admy. Wait for report (SHA, tests, URL, rollback).
2. Reply `APPROVED: governance PR` to Admy.
3. Confirm Admy: "no agent active on Desktop LEGAL files" -> then paste `04_PROMPT_memy_dedupe.md` to Memy.
4. Review Memy's dry-run report (`DRYRUN_REPORT.md`) and reply `APPROVED: execute moves`.

## 4. Your approval checklist
- [ ] Deploy URL works, rollback command tested
- [ ] gitleaks clean
- [ ] Dry-run report: no files with `ACTIVE` flag
- [ ] retention periods: send to lawyer/DPO (D9)

## 5. Quick checks
```bash
cd ~/Projects/lexflow && git status -sb && git log -1 --oneline
gitleaks detect --source . --no-banner
```
