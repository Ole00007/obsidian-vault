# ADR v2 (2026-10-26)
| ID | Decision | Status | Revisit on EVENT |
|---|---|---|---|
| D1 | P0: merge, test, push, deploy; no new features | ACTIVE | deploy verified + rollback tested |
| D2 | Postgres = system of record | FIXED | never |
| D3 | Memory = Obsidian only; Hindsight bank per workspace deferred | DEFERRED | 2nd tenant has live data |
| D4 | Source IDs in Obsidian; rules in GitHub | ACTIVE | - |
| D5 | MCP + OAuth2 deferred | DEFERRED | tenant wants own agent / external CRM |
| D6 | Scoped REST API (service accounts, scopes) | NEXT | D1 done |
| D7 | Adapter spec | DEFERRED | first legacy CRM confirmed |
| D8 | PostgreSQL RLS on top of workspace_filter() | NEXT | D1 done |
| D9 | Retention periods | TBD | lawyer/DPO confirms |

Gaps closed: GDPR/git permanence (G1), LLM provider DPA/ZDR (G2), prompt injection (G3), deterministic legal deadlines (G4), consent for WhatsApp/drip (G5), cost caps/kill switch (G6), agent evals (G7), backup restore replays deletion ledger (G8), stale memory (G9), secret scanning (G10).
