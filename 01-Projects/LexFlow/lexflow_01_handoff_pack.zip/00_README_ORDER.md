# Pack 1: Handoff (read order)

## Where to save in Perplexity
| File | Save in | Why |
|---|---|---|
| 00_README_ORDER.md | AGENTIC ARCHIT space | generic runbook |
| 01_ADR_v2.md | AGENTIC ARCHIT space | reusable architecture decisions + triggers pattern |
| 02_PROMPT_human_olesia.md | AGENTIC ARCHIT space | your operating runbook |
| 03_PROMPT_admy_orchestrator.md | LexFlow space | LexFlow-specific orchestration |
| 04_PROMPT_memy_dedupe.md | LexFlow space | LexFlow repo housekeeping |
| Pack 2 (all) | LexFlow space | LexFlow memory architecture |
| Pack 2 / code/memory_gateway.py + gdpr rule | copy to AGENTIC space as pattern | reusable |

## Feed order to Hermes/Admy
1. Pack 2 `config/*` + `docs/*` (context, read-only)
2. 03_PROMPT_admy (P0 deploy -> governance PR)
3. 04_PROMPT_memy (dedupe) -- only after Admy confirms "no active work on LEGAL files"
4. Everything else is EVENT-TRIGGERED (config/triggers.yaml)

## Hard rules (all agents)
1. Move/rename/delete a file => NOTIFY the whole roster (see memy prompt, section Notify).
2. Never move a file another agent is working on (lock check).
3. Never delete; move to archive.
4. No PII/secrets in GitHub.
