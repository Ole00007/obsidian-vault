#!/usr/bin/env bash
set -e
mkdir -p ~/Projects/.agent-locks ~/Projects/.agent-bus ~/Projects/_archive ~/Projects/LEGAL_backup
touch ~/Projects/.agent-bus/NOTIFY.md
[ -f ~/Projects/.agent-bus/ROSTER.md ] || cp "$(dirname "$0")/ROSTER.md" ~/Projects/.agent-bus/ROSTER.md
echo "agent bus ready"
