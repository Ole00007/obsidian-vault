# Agent roster (edit names/channels)
| Agent | Role | Notify channel |
|---|---|---|
| admy | main orchestrator LexFlow | NOTIFY.md + <channel> |
| memy | memory / file housekeeping | NOTIFY.md + <channel> |
| backy | backend | NOTIFY.md + <channel> |
| <add others> | | |

HARD RULES: (1) any move/rename/delete => append to NOTIFY.md and message every agent above. (2) never touch files with a lock in ~/Projects/.agent-locks/. (3) never delete; archive.
Lock file format: `<agent>-<task>.lock` containing agent, paths, start time.
