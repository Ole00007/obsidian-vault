#!/usr/bin/env python3
"""fill_template.py — Template SITE-AUDIT 1_ENNEFEX (v3.1, oct 2026)
Usage:
  python3 fill_template.py            # writes ./dist/ (multi-page site: pages + css/ + assets/ + images/)
  python3 fill_template.py --single   # also writes ./dist/audit-single.html (one file; menu, hamburger, language toggle, images inlined)
Edit config.json first. Free-text hints in [square brackets] must be replaced by hand in the HTML pages.
"""
import base64, json, re, shutil, sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parent
DIST = ROOT / "dist"
PAGES = ["index", "tecnico", "canali", "faq", "competitors", "seo", "crescita", "roadmap"]
cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))

def fill(text):
    for k, v in cfg.items():
        text = text.replace("{{" + k + "}}", v)
    return text

def main():
    if DIST.exists():
        shutil.rmtree(DIST)
    DIST.mkdir()
    for sub in ("css", "assets", "images"):
        shutil.copytree(ROOT / sub, DIST / sub)
    left = set()
    for k in PAGES:
        fn = "index.html" if k == "index" else k + ".html"
        s = fill((ROOT / fn).read_text(encoding="utf-8"))
        left.update(re.findall(r"\{\{([A-Z0-9_]+)\}\}", s))
        (DIST / fn).write_text(s, encoding="utf-8")
    if left:
        print("WARNING: placeholders without a value in config.json:", sorted(left))
    print("Written:", DIST)
    if "--single" in sys.argv:
        build_single()

def build_single():
    idx = (DIST / "index.html").read_text(encoding="utf-8")
    head = re.search(r"<head>(.*?)</head>", idx, re.S).group(1)
    head = re.sub(r'<link rel="stylesheet" href="\./css/[^"]+">', "", head)
    css = "".join((DIST / "css" / f).read_text(encoding="utf-8") for f in ("base.css", "style.css", "extra.css"))
    brand = re.search(r'<a class="brand".*?</a>', idx, re.S).group(0).replace('href="./index.html"', 'href="#index" data-pg="index"')
    footer = re.search(r"<footer.*?</footer>", idx, re.S).group(0)
    lang_btn = re.search(r'<button[^>]*data-lang-toggle.*?</button>', idx, re.S).group(0)
    menu_btn = re.search(r'<button class="menu-toggle".*?</button>', idx, re.S).group(0)
    def img_uri(m):
        p = DIST / "images" / m.group(1)
        return "data:image/png;base64," + base64.b64encode(p.read_bytes()).decode()
    navs, bodies = "", ""
    for k in PAGES:
        fn = "index.html" if k == "index" else k + ".html"
        h = (DIST / fn).read_text(encoding="utf-8")
        main_ = re.search(r'<main class="page">(.*?)</main>', h, re.S).group(1)
        main_ = re.sub(r'\./images/([\w.-]+)', img_uri, main_)
        for kk in PAGES:
            f2 = "index.html" if kk == "index" else kk + ".html"
            main_ = main_.replace(f'href="./{f2}"', f'href="#{kk}" data-pg="{kk}"')
        label = re.search(r'<a href="\./%s"[^>]*>(.*?)</a>' % re.escape(fn), h, re.S).group(1)
        navs += f'<a href="#{k}" data-pg="{k}">{label}</a>\n      '
        bodies += f'<div class="pg" id="pg-{k}" data-pg-id="{k}">{main_}</div>'
    menu_js = (DIST / "assets" / "menu.js").read_text(encoding="utf-8")
    growth_js = (DIST / "assets" / "growth.js").read_text(encoding="utf-8")
    js = """(function(){var root=document.documentElement,ids=%s;
function show(id,s){if(ids.indexOf(id)<0)id=ids[0];document.querySelectorAll('.pg').forEach(function(e){e.hidden=e.getAttribute('data-pg-id')!==id});
document.querySelectorAll('.site-nav [data-pg]').forEach(function(a){if(a.getAttribute('data-pg')===id)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current')});if(s!==false)window.scrollTo(0,0)}
document.querySelectorAll('[data-pg]').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();show(a.getAttribute('data-pg'))})});
var lang='it';function setLang(l){lang=l;root.setAttribute('data-lang',l);root.setAttribute('lang',l);var b=document.querySelector('[data-lang-toggle]');if(b)b.textContent=l==='it'?'🌐 EN':'🌐 IT'}
document.querySelector('[data-lang-toggle]').addEventListener('click',function(){setLang(lang==='it'?'en':'it')});
var btn=document.createElement('button');btn.className='back-to-top';btn.setAttribute('aria-label','Torna su / Back to top');btn.textContent='↑';
btn.addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'})});document.body.appendChild(btn);
window.addEventListener('scroll',function(){btn.classList.toggle('visible',window.scrollY>400)},{passive:true});
var h=(location.hash||'').replace('#','');setLang('it');show(ids.indexOf(h)>=0?h:ids[0],false)})();""" % json.dumps(PAGES)
    out = f"""<!DOCTYPE html>
<html lang="it" data-lang="it">
<head>{head}<style>{css}</style></head>
<body>
<header class="site-header"><div class="site-header__inner">{brand}<div class="header-right"><nav class="site-nav" id="site-menu" aria-label="Menu">{navs}</nav>{lang_btn}{menu_btn}</div></div></header>
<main class="page">{bodies}</main>
{footer}
<script>{js}</script>
<script>{menu_js}</script>
<script>{growth_js}</script>
</body></html>"""
    (DIST / "audit-single.html").write_text(out, encoding="utf-8")
    print("Written:", DIST / "audit-single.html")

if __name__ == "__main__":
    main()
