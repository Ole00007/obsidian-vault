# WhatsApp Chat Export: PRACTICAL & EFFICIENT
Export date: November 5, 2026 at 5:11 PM

---

## October 16, 2025

[3:43 PM] **You:** [Voice message]

[3:44 PM] **You:** [Voice message]

[3:53 PM] **Eugeje italian:** [Voice message]

[4:11 PM] **You:** [Voice message]

[4:12 PM] **You:** [Voice message]

[4:20 PM] **Eugeje italian:** [Voice message]

[5:34 PM] **You:** [Voice message]

[5:34 PM] **You:** [Voice message]

[5:35 PM] **You:** [Voice message]

[5:39 PM] **Eugeje italian:** [Voice message]

[5:39 PM] **Eugeje italian:** [Voice message]

[5:43 PM] **You:** [Voice message]

[5:46 PM] **You:** [Voice message]

[5:48 PM] **Eugeje italian:** [Voice message]

[6:55 PM] **You:** could you please bring me the key (in cantina) just in case

[7:04 PM] **Eugeje italian:** Ok

[7:09 PM] **You:** Thanks. Also the toth brushes and a tooth paste please

[7:31 PM] **Eugeje italian:** Ok

[7:36 PM] **You:** Ciabatte only for Dani. I have one in the car x myself

[7:36 PM] **Eugeje italian:** Ok

[7:47 PM] **You:** If you have headphones 🎧 for Dani

[7:52 PM] **Eugeje italian:** Will check

[8:14 PM] **Eugeje italian:** I will be late; 1 hour in traffico in genova

[8:20 PM] **You:**
> _Eugeje italian: I will be late; 1 hour in traffico in genova_
Blin

[8:22 PM] **You:** Wish 🤞it passes fast

[8:22 PM] **You:** Have you called Marco?

[8:28 PM] **You:**
> _You: Thanks. Also the toth brushes and a tooth paste please_
And toilet 🚻 🙏🏻🙏🏻here they dave the trees..📃

[9:33 PM] **Eugeje italian:**
> _You: And toilet 🚻 🙏🏻🙏🏻here they dave the trees..📃_
Ok

[9:34 PM] **Eugeje italian:**
> _You: Have you called Marco?_
Mika almost finished dinner; will then come asap

---

## October 19, 2025

[10:42 AM] **You:** We'll be released in the noon

[10:42 AM] **You:** How's the ⚽?

[11:54 AM] **Eugeje italian:**
> _You: We'll be released in the noon_
Ok

[11:54 AM] **Eugeje italian:**
> _You: How's the ⚽?_
Good

---

## October 20, 2025

[5:46 PM] **You:** I would like to take a break, please

I don't know what you wrote me there

And I m not sure i can handle it

[5:46 PM] **You:** I ll read it latter

[5:47 PM] **You:** Back to practical things

[5:47 PM] **You:** Make me yourself an appointment

[5:47 PM] **You:** But not tonight

[5:48 PM] **You:** You were clearly not ready for a quite talk

[5:48 PM] **You:** Now I'm not

[5:48 PM] **You:** Propose a time

[5:48 PM] **You:** And hope that i will show up

[5:48 PM] **You:** Unlike you 🤞🏼🤞🏼🙃🤞🏼🤞🏼🤞🏼

[6:30 PM] **Eugeje italian:**
> _You: I would like to take a break, please

I don't know what you wrote me there

And I m not sure i can handle it_
We can take a break of course

[6:36 PM] **Eugeje italian:** If there is no other possibility than divorce, than i very much regret it, and i think it is an enormous pity for all involved, but then there is for the moment no need to meet. We can communicate by message.

[6:45 PM] **You:**
> _Eugeje italian: If there is no other possibility than divorce, than i very much regret it, and i think it is an enormous pity for all involved, but then there is for the moment no need to meet. We can communicate by message._
These are your words, not mine

[6:45 PM] **You:** You do keep pushing for your way again

[6:45 PM] **You:** I see things different

[6:45 PM] **Eugeje italian:** I thought you wanted to take a break

[6:46 PM] **You:** And you once again show me

[6:46 PM] **Eugeje italian:** So why don't we take a break ?

[6:46 PM] **You:** That no compromise

[6:46 PM] **You:** Not a step forward

[6:46 PM] **You:**
> _Eugeje italian: So why don't we take a break ?_
Sure

[6:47 PM] **You:**
> _Eugeje italian: If there is no other possibility than divorce, than i very much regret it, and i think it is an enormous pity for all involved, but then there is for the moment no need to meet. We can communicate by message._
Why do you write this then? Doesnt look like a break

[6:48 PM] **You:** It looks like you want another round of emotional draining

[6:48 PM] **You:** And mind that

[6:48 PM] **You:** You didn't give me a break for once

[6:48 PM] **Eugeje italian:** Its very much a break, its proposing to avoid these emotion draining meetings

[6:48 PM] **You:** You just keep pushing your way!!!!

[6:48 PM] **You:** You say one thing

[6:49 PM] **Eugeje italian:** I don't push,

[6:49 PM] **You:** And then with a next message immediatamente after you do completly the oposite!

[6:49 PM] **Eugeje italian:** Its fine, we do meeting; now time for a break?

[6:49 PM] **You:** Don't you see that this is precisely what makes me so unhappy?!

[6:50 PM] **You:** This is precisely why i feel you don't give a flying fuck about what i need

[6:50 PM] **You:** Only

[6:50 PM] **You:** Your way possible

[6:50 PM] **You:** Not even this chat is clean anymore

[6:51 PM] **Eugeje italian:** I just suggested messaging instead of a meeting? Thats all

[6:51 PM] **You:**
> _Eugeje italian: I just suggested messaging instead of a meeting? Thats all_
Whatever

[6:51 PM] **You:** Goodluck

[6:52 PM] **You:** Send me your meeseges and your lawyer then

[6:52 PM] **You:** Because a bit of respect and a civilised conversation

[6:52 PM] **You:** Is too much to ask

[6:53 PM] **You:** Feelings are too much to be shared

[6:53 PM] **Eugeje italian:** You drop this bomb on me, and expect me to be happy?

[6:53 PM] **You:** And BEING NOT HAPPY OF treated for 2% id not allowed

[6:53 PM] **You:** Buy👋🏻

[6:53 PM] **You:** By

[6:54 PM] **You:**
> _Eugeje italian: You drop this bomb on me, and expect me to be happy?_
By👋🏻

[6:54 PM] **You:** Poor you

[6:54 PM] **You:**
> _Eugeje italian: You drop this bomb on me, and expect me to be happy?_
And here you, ready to attack

[6:54 PM] **You:** Nock yourself diwn

[6:54 PM] **Eugeje italian:** Who is attacking?

[6:54 PM] **Eugeje italian:** Break...?

[6:54 PM] **You:** I'm done

[6:54 PM] **You:** You dont want to talk

[6:55 PM] **You:** Then spare me pf these messy messages

[6:55 PM] **You:** I really deserve at lest a bit of piece of mind

[6:56 PM] **Eugeje italian:**
> _You: I really deserve at lest a bit of piece of mind_
Of course, but perhaps i also?

[6:59 PM] **You:**
> _Eugeje italian: If there is no other possibility than divorce, than i very much regret it, and i think it is an enormous pity for all involved, but then there is for the moment no need to meet. We can communicate by message._
You've restarted

[7:04 PM] **You:** [Voice message]

[7:05 PM] **You:** [Voice message]

[7:05 PM] **You:** [Voice message]

[7:06 PM] **You:** [Voice message]

[7:06 PM] **Eugeje italian:** Of course you have a house, lets take break

[7:06 PM] **Eugeje italian:** I stopped already long time ago

[7:07 PM] **Eugeje italian:** The emotional drain is entirely on my side; and i will be the one who leaves

[7:08 PM] **You:** [Voice message]

[7:09 PM] **You:** [Voice message]

[7:12 PM] **Eugeje italian:** Where did i threaten you..??

[7:14 PM] **Eugeje italian:** You keep using these words as threatening & agression; show me where i 'threatened' you?

[7:14 PM] **Eugeje italian:** By suggesting texting instead of meeting? Is that a threat now?

[7:15 PM] **Eugeje italian:** I'm living in fear because each little things offsets you and you get very angry with me for weeks, months

[7:17 PM] **Eugeje italian:** _This message was deleted_

[7:18 PM] **Eugeje italian:** I just suggested texting...thats all...and again i'm the worst, most lousy asshole on mother earth....

[7:19 PM] **Eugeje italian:** _This message was deleted_

[7:19 PM] **Eugeje italian:** _This message was deleted_

[7:20 PM] **Eugeje italian:** _This message was deleted_

[7:20 PM] **Eugeje italian:** _This message was deleted_

[7:20 PM] **Eugeje italian:** _This message was deleted_

[7:30 PM] **Eugeje italian:** Never mind; for the sake of all of us,  i will only text practical things

[7:39 PM] **Eugeje italian:** I'm going supermarket now

---

## October 22, 2025

[12:06 PM] **Eugeje italian:**
> _You: Send me your meeseges and your lawyer then_
Here you already asked for it; you can contact my lawyer at s_avakov@atplaw.com

[3:50 PM] **You:** I take a break chatting
Thx 4 understanding

[3:54 PM] **Eugeje italian:** Ofc

[3:55 PM] **Eugeje italian:** I guess until tomorrow; then you will find another reason to be angry with me 🤣🤣🤣

[4:55 PM] **You:** Keep trying to triger))

[4:55 PM] **You:** Switch the shit please

[4:56 PM] **You:** Change the disque

[4:56 PM] **You:** Re-start

[4:56 PM] **You:** Talk to yr best friend

[4:56 PM] **You:** Or mum

[4:56 PM] **You:** Or chat gpt

[4:56 PM] **You:** You making me arrive late

[4:57 PM] **You:** Compromising safety

[5:05 PM] **Eugeje italian:** Please drive safe

[5:06 PM] **Eugeje italian:**
> _You: You making me arrive late_
How do i do that...??

[5:07 PM] **Eugeje italian:**
> _You: Compromising safety_
You are behind the wheel; you have responsibility at the moment for your safety and mika's

[5:07 PM] **Eugeje italian:** And i didn't start this morning this big fight

---

## January 5, 2026

[2:56 PM] **You:** I kindly ask you to try and stop the negative flow in the other chat. I will read it latter, if you want. Now I'm busy trying to help you,  no matter what you say.

As i know this is important for you.

I would however appreciate you not diluting and devaluating what's important for me

[2:57 PM] **You:** If however you do so it's your choice, but then we'll never get out of spiral big fight

[2:58 PM] **You:** Lots of energy waisted

[2:58 PM] **You:** And I still need some also for Dani

[2:58 PM] **You:** I go out with her now

[3:00 PM] **Eugeje italian:** I appreciate your help, i really do

[3:01 PM] **You:** So please return me a favour

[3:18 PM] **Eugeje italian:** If you mean the explanation of 'how', as given to you a year ago, but now on paper; i will do that

[3:42 PM] **You:**
> _Eugeje italian: If you mean the explanation of 'how', as given to you a year ago, but now on paper; i will do that_
Ps do

[6:46 PM] **Eugeje italian:** Please also read the other chat;

[6:47 PM] **Eugeje italian:** _This message was deleted_

[6:49 PM] **Eugeje italian:** _This message was deleted_

[6:53 PM] **You:** [Voice message]

[6:53 PM] **Eugeje italian:** _This message was deleted_

[6:53 PM] **You:** [Voice message]

[8:57 PM] **You:** [Image]

[8:59 PM] **You:** [Image]

[9:00 PM] **You:**
> _You: Image_
Opened an account for DR

[9:06 PM] **Eugeje italian:**
> _You: Opened an account for DR_
For Daniella?

[9:07 PM] **Eugeje italian:** I'm not sure i follow

---

## January 6, 2026

[3:03 AM] **You:**
> _Eugeje italian: For Daniella?_
Yes

[11:08 AM] **You:** [Image]

[11:08 AM] **You:** Ps check yrs. Yrs also in minus. They charge -7€/ month

[2:07 PM] **You:** Daniiii!!

[2:07 PM] **You:** Any news?

[2:07 PM] **You:** She doesn't rispond

[2:24 PM] **Eugeje italian:** She is still there

[2:25 PM] **Eugeje italian:** According to the app

[2:25 PM] **You:** yes. she called me back

[2:25 PM] **Eugeje italian:** Ok

[2:29 PM] **You:** _You deleted this message_

[7:07 PM] **Eugeje italian:** I have just moved Eur 4300 to my bank in NL, thank you, much appreciated

[7:09 PM] **Eugeje italian:** May i kindly ask you when and how much you can send the coming few days?  Jan 14th is my deadline with the bank....

[7:20 PM] **You:** Another 11 in a couple of  days. The rest depends on Kucoin

[7:25 PM] **Eugeje italian:** That would be very good, thank you

[7:30 PM] **You:**
> _Eugeje italian: That would be very good, thank you_
Sure

[10:17 PM] **Eugeje italian:**
> _You: Another 11 in a couple of  days. The rest depends on Kucoin_
So...we now see how much worth is your promise. Another 'tornado' and you let me sink

[10:27 PM] **Eugeje italian:**
> _You: Sure_
'Sure' doesn't mean much, does it?

[10:35 PM] **You:** as well as your two years

[10:36 PM] **You:** of different stories

[10:36 PM] **You:** never too straight

[10:36 PM] **Eugeje italian:** Same story, never changed

[10:36 PM] **Eugeje italian:** Now....you want to keep fighting...?

[10:36 PM] **You:** what is worse: one chatting another or another stalking?

[10:37 PM] **You:** breaking all the boundaries of privace?

[10:37 PM] **You:** won't mention the rest

[10:37 PM] **Eugeje italian:** I never had any access to yr social media

[10:37 PM] **You:** i took a burden to create for you a little "elefant story" to explain feelings

[10:38 PM] **Eugeje italian:** But i knew smth was going on....so i contacted them

[10:38 PM] **You:** you: BULLING)))

[10:38 PM] **You:** thank

[10:38 PM] **You:** keep going

[10:38 PM] **You:** and aagin

[10:38 PM] **You:** you ve just sais "divorse"

[10:38 PM] **You:** be a man

[10:38 PM] **You:** take an action

[10:39 PM] **Eugeje italian:** You want me to file for divorce?

[10:39 PM] **You:**
> _Eugeje italian: But i knew smth was going on....so i contacted them_
who !!!

[10:39 PM] **You:**
> _Eugeje italian: You want me to file for divorce?_
you ve said this

[10:39 PM] **You:**
> _Eugeje italian: You want me to file for divorce?_
but let's take a pause here

[10:39 PM] **Eugeje italian:**
> _You: who !!!_
These guys...you didn't read any of my messages???

[10:39 PM] **You:**
> _You: who !!!_
who?

[10:39 PM] **Eugeje italian:** I explained the whole thing

[10:40 PM] **You:**
> _Eugeje italian: These guys...you didn't read any of my messages???_
how on earth you followed and which guys?

[10:40 PM] **You:** i really have no clue

[10:40 PM] **Eugeje italian:** Ok....read my messages...i explained it all

[11:14 PM] **Eugeje italian:**
> _You: what is worse: one chatting another or another stalking?_
I don't know....lets see...if i remember correctly you were chatting with a  young attractive guy, who is living close bye, talking about having sex outside yr relationship, invite him for coffee...and then you invited him to Milan...didn't you? while you told me you wanted to invite Lesya...🤣🤣🤣

[11:15 PM] **Eugeje italian:** Was it not something like that...?

[11:15 PM] **Eugeje italian:** You have the messages....you wanna share them?

[11:15 PM] **You:**
> _Eugeje italian: I don't know....lets see...if i remember correctly you were chatting with a  young attractive guy, who is living close bye, talking about having sex outside yr relationship, invite him for coffee...and then you invited him to Milan...didn't you? while you told me you wanted to invite Lesya...🤣🤣🤣_
WHY IN THIS CHAT?

[11:15 PM] **Eugeje italian:** Or was he lying?

[11:16 PM] **Eugeje italian:** He made it all up?

[11:17 PM] **You:** go ahead

[11:17 PM] **You:** but better there

[11:17 PM] **Eugeje italian:** You wanna share all these chats..?

[11:17 PM] **You:** sure

[11:17 PM] **Eugeje italian:** How you wanted to invite Lesya....?

[11:17 PM] **You:** why not

[11:18 PM] **Eugeje italian:** Go ahead

[11:18 PM] **You:**
> _Eugeje italian: How you wanted to invite Lesya....?_
now i'm a tat puzzled

[11:18 PM] **Eugeje italian:** But....it will not change anything

[11:18 PM] **You:**
> _Eugeje italian: But....it will not change anything_
what?

[11:19 PM] **Eugeje italian:**
> _You: now i'm a tat puzzled_
No need to be puzzled....you told me that you wanted to invite Lesya....but if i understood it correctly...you asked this guy, didn't you?

[11:21 PM] **You:**
> _Eugeje italian: No need to be puzzled....you told me that you wanted to invite Lesya....but if i understood it correctly...you asked this guy, didn't you?_
?

[11:21 PM] **Eugeje italian:** You remember right?....young attractive guy, lots of muscles....zillions of images of himself near the pool....

[11:21 PM] **You:**
> _Eugeje italian: You remember right?....young attractive guy, lots of muscles....zillions of images of himself near the pool...._
?

[11:22 PM] **Eugeje italian:** You didn't talk to him about sex, outside yr marriage,....and invited him to milan...?

[11:22 PM] **You:**
> _Eugeje italian: You didn't talk to him about sex, outside yr marriage,....and invited him to milan...?_
?

[11:22 PM] **Eugeje italian:** No....no memory at all?🤣🤣

[11:22 PM] **You:**
> _Eugeje italian: No....no memory at all?🤣🤣_
?

[11:23 PM] **You:** ok. i had enough

[11:23 PM] **Eugeje italian:** Me 2

[11:23 PM] **You:** ps go ahead

[11:25 PM] **Eugeje italian:** Nothing of such a conversation took place...? Its all 'made up'?

[11:26 PM] **Eugeje italian:** Its all my imagination....i'm sick in my mind?

[11:26 PM] **Eugeje italian:** You tell yr husband that 100 times...and he will start to try to find smth out

[11:27 PM] **You:** this is precisely what you said yourself

[11:27 PM] **Eugeje italian:** Because smth was clearly off

[11:27 PM] **You:** you are pushing

[11:27 PM] **You:** hard

[11:27 PM] **You:** for a very wrong result

[11:27 PM] **Eugeje italian:** You started this conversation...not me

[11:27 PM] **You:** or maybe for a right one]

[11:28 PM] **Eugeje italian:** You started sunday accusing me of things i had nothing to do with...zero

[11:28 PM] **Eugeje italian:** And within 10 minutes of raging you told me you wanted to split up

[11:29 PM] **You:** how can i trust a man who thinks this is easy (story about my father)?

[11:29 PM] **You:** shall i call your mother?

[11:29 PM] **Eugeje italian:** The 'easy' was not related to that?

[11:29 PM] **You:** this is the only thing which stoppes you

[11:29 PM] **Eugeje italian:**
> _You: shall i call your mother?_
Go ahead

[11:29 PM] **You:**
> _Eugeje italian: Go ahead_
tomorrow

[11:29 PM] **You:** if you want

[11:30 PM] **You:** or we go to a lawyer

[11:30 PM] **Eugeje italian:** Make sure...that you tell her the full story....

[11:30 PM] **You:** just as you wanted

[11:30 PM] **Eugeje italian:** You started this...last sunday...not me

[11:31 PM] **You:** good night

[11:33 PM] **Eugeje italian:** You want cup of tea?🙂

[11:34 PM] **Eugeje italian:** No need to fight...this is useless, really

[11:34 PM] **Eugeje italian:** All that negative emotion...after a few nice months of growing towards each other..getting better at talking

[11:35 PM] **Eugeje italian:** Really....this is so useless

[11:35 PM] **Eugeje italian:** _This message was deleted_

[11:40 PM] **You:** This is the best moment to separate

[11:41 PM] **Eugeje italian:** Ok

[11:41 PM] **You:**
> _Eugeje italian: I'm not even angry...not the slightest actually_
You put all this here not even being angry

[11:41 PM] **Eugeje italian:** Ofc i'm angry

[11:41 PM] **You:** I dont like a man like this near me

[11:41 PM] **You:** Sorru

[11:41 PM] **Eugeje italian:** Ofc i was hurt

[11:41 PM] **You:** Here

[11:42 PM] **You:**
> _You: I dont like a man like this near me_
Enough

[11:42 PM] **You:** I had enough

[11:42 PM] **Eugeje italian:** Who you think you are talking to?

[11:42 PM] **Eugeje italian:** Ok

[11:42 PM] **You:** Goodnight

[11:42 PM] **You:** And let's take a coffee

[11:42 PM] **You:** Non angree

[11:42 PM] **Eugeje italian:** Why coffee?

[11:42 PM] **You:** Quiete coffee

[11:43 PM] **Eugeje italian:** You want to divorce; socall a lawyer

[11:43 PM] **You:**
> _You: Quiete coffee_
Because i like so

[11:43 PM] **Eugeje italian:** No need for coffee

[11:43 PM] **You:** But you can take a tea

[11:43 PM] **You:** Goodnight, Eugene

[11:43 PM] **Eugeje italian:** You wanna divorce, ok, then call a lawyer

[11:44 PM] **Eugeje italian:** No need for any coffee anymore....ever

[11:44 PM] **You:**
> _Eugeje italian: You wanna divorce, ok, then call a lawyer_
You always want me to do a neat-greaty, right?))

[11:44 PM] **You:** Ok

[11:44 PM] **You:** As you please

[11:44 PM] **You:** I m out

[11:44 PM] **Eugeje italian:** You wanna sink me now with my apt....you wanna now divorce

[11:45 PM] **Eugeje italian:** Why have a coffee?

[11:47 PM] **Eugeje italian:** Interesting how easy you want to divorce...some tornado's...and thats it

[11:47 PM] **Eugeje italian:** Fully disregard whatever we accomplished the last few months.....

[11:47 PM] **You:** People grow

[11:48 PM] **You:** In what they do

[11:48 PM] **Eugeje italian:** And based on accussations nothing to do with me

[11:48 PM] **You:** You apparently in "pushing hard"

[11:48 PM] **Eugeje italian:** Who is pushing here??

[11:48 PM] **Eugeje italian:** Really?

[11:48 PM] **You:** Me in being mo resilient

[11:48 PM] **Eugeje italian:** You read your own messages?

[11:48 PM] **You:** But this is toxic

[11:49 PM] **Eugeje italian:** Who was shouting at the top of her lungs 2 nights ago?

[11:49 PM] **Eugeje italian:**
> _You: But this is toxic_
Yes...indeed

[11:49 PM] **You:** Just like to make kids of 9 and 12 yo watch breaking abad

[11:49 PM] **You:** And the rest of the violent and aggressive stuff

[11:49 PM] **You:** And I don't like

[11:50 PM] **You:** It

[11:50 PM] **Eugeje italian:** Ah...so i'm a bad father now?

[11:50 PM] **You:** And I had enough

[11:50 PM] **Eugeje italian:** Really, you go this way??

[11:50 PM] **You:** And I dont want to fight

[11:50 PM] **You:** And I want to talk quitely

[11:50 PM] **Eugeje italian:**
> _You: And I dont want to fight_
Oh....but now you changed the situation

[11:50 PM] **You:** With lawyer or without

[11:50 PM] **You:** But this is not working

[11:50 PM] **You:** And will never do

[11:51 PM] **You:** Let me put it neutral

[11:51 PM] **You:** Because we are too different

[11:51 PM] **Eugeje italian:** So...call a lawyer and file for divorce then

[11:53 PM] **Eugeje italian:**
> _You: And the rest of the violent and aggressive stuff_
You mean you shouting to them 10 times/day?

[11:54 PM] **Eugeje italian:** Who is pushing hard?

[11:54 PM] **Eugeje italian:** You ever read yr own messages?

[11:54 PM] **Eugeje italian:** Who is accusing me if all things, who is shouting?

[11:56 PM] **Eugeje italian:**
> _You: And will never do_
If you don't want...keep digging up the past...of course it won't work

---

## January 7, 2026

[12:37 PM] **You:** I pick up Mika, btw

[1:19 PM] **You:** Ps let him in

[1:19 PM] **You:** I'm with Olga on the phone

[1:19 PM] **Eugeje italian:** I'm not home

[1:19 PM] **You:** Ah ok

[7:10 PM] **You:** [Forwarded] Buonasera e buon anno, il week end del 17/18 gennaio si terrà la seconda tappa del Fitp Junior Program a Arenzano e Voltri. Ditemi se siete interessati per procedere all'iscrizione, grazie

[7:13 PM] **You:** Buonasera e buon anno, Reguardo il Fitp Junior faccio sapere presto. invece per l'allenamento di domani: è tutto regolare? grazie

[7:13 PM] **You:** [Forwarded] Si si, certo

[7:20 PM] **Eugeje italian:** Ok, tnx

---

## January 8, 2026

[7:36 PM] **Eugeje italian:** Thank you for yr contributions / loan; much appreciated 🙏

[8:48 PM] **You:** I'll need to wait for Kucoin

[8:49 PM] **You:** But from another account i'd still send you in small batches

[9:09 PM] **Eugeje italian:** Ok, thank you

[9:09 PM] **Eugeje italian:** I hope in 8 - 10 weeks to send it back

---

## January 9, 2026

[11:25 AM] **You:** Morning. Hope, all is fine. How's Dani?

[11:32 AM] **You:**
> _Eugeje italian: I hope in 8 - 10 weeks to send it back_
Just sent another 6k. 

Hope on. + 5 from Lessia 2day. 

Hope 2 b able to sort some more from my trading account 

But not easy with the burse..and really not funny to close positions with -50-80%...

thank you

[11:34 AM] **You:** Speaking of extra costs: Revolute charges 1% for a Crypto/ FIAT (in this case €) transaction 😬

[11:35 AM] **You:** Could you, please, check what's the commission of your Coinbase?

[11:37 AM] **You:** [Image]

[11:38 AM] **You:**
> _You: Image_
This should be by 2night incl the 5 from Lessia

[11:39 AM] **You:** How are you set with the  rest?

[11:39 AM] **You:** Just x me 2 understand 2 ask someone again or not

[11:40 AM] **You:** From my trading accounts like i said i'll try
 
I try every day, bit by bit, in some positions

[11:41 AM] **You:** But u understand what a pain 2 close in such a minus...😬🥵

[11:43 AM] **You:** I have around 400 k r from credit card in rub but it's like 10% -12% on all the transactions 2 bring it over to Revolute (depending on the day)

[11:45 AM] **Eugeje italian:** Hi, thank you very much!

[11:45 AM] **Eugeje italian:** I will ask my brother for 5 more, then we don't need to get from Lessia

[11:46 AM] **Eugeje italian:** With yr 6 which you just send me, i should be able to pay it off

[11:47 AM] **Eugeje italian:** I took all from my company account...so i can't pay german taxes now...but thats a smaller issue than the apt

[11:48 AM] **You:**
> _Eugeje italian: I will ask my brother for 5 more, then we don't need to get from Lessia_
I think better keep it just in case

[11:48 AM] **You:** Just make sure to pay Lessia back on time

[11:49 AM] **Eugeje italian:** Let me ask my brother

[11:49 AM] **You:** Well u can leave 1k on joint acc

[11:49 AM] **You:** [Voice message]

[11:50 AM] **Eugeje italian:**
> _You: Just sent another 6k. 

Hope on. + 5 from Lessia 2day. 

Hope 2 b able to sort some more from my trading account 

But not easy with the burse..and really not funny to close positions with -50-80%...

thank you_
I know, its terrible

[11:51 AM] **You:** [Voice message]

[11:51 AM] **Eugeje italian:** I will try to find out the%

[11:52 AM] **You:** [Voice message]

[11:52 AM] **You:** [Voice message]

[11:52 AM] **You:** [Voice message]

[11:54 AM] **Eugeje italian:** Yes, she was relatively fine...her nose was quite blocked, but she could clean it

[11:55 AM] **Eugeje italian:**
> _You: Just make sure to pay Lessia back on time_
Ofc,  end of month i have some incoming money; we can pay her back first

[11:57 AM] **Eugeje italian:** I think you can stop sending more. I will be at zero, but i have my credit card, and with incoming money in 3 weeks..i should be fine

[11:57 AM] **Eugeje italian:** Thank you very much for all yr support, really appreciated

[12:09 PM] **Eugeje italian:** With yr 6ke i'm there...i will pay the bank today

[12:11 PM] **Eugeje italian:** I will pay you back, incl all these costs of course. In 2 months i should have received sufficient from china.

[12:41 PM] **You:**
> _Eugeje italian: I think you can stop sending more. I will be at zero, but i have my credit card, and with incoming money in 3 weeks..i should be fine_
Let me know just in case

[12:41 PM] **You:**
> _Eugeje italian: Thank you very much for all yr support, really appreciated_
Ofcourse

[12:43 PM] **You:**
> _Eugeje italian: I will pay you back, incl all these costs of course. In 2 months i should have received sufficient from china._
Let's see how it goes for you. You know i don't expect this to come back. I'd do it anyway.

[12:44 PM] **You:** Hope all will be resolved with your ugly bank today!🙏🏻

[12:44 PM] **You:** Ps, let's me know

[1:00 PM] **Eugeje italian:**
> _You: Let's see how it goes for you. You know i don't expect this to come back. I'd do it anyway._
No worries; its really just a loan; you need to have that money back, and you will. The reserve in China is not small...its just that it takes a lot of time to send to me

[1:01 PM] **Eugeje italian:** Last yr i received 270 ke from china; 150ke for the apt, 120 for living expenses / car etc

[1:03 PM] **Eugeje italian:**
> _You: Let me know just in case_
I now have the funds; i'm paying them today

[1:08 PM] **Eugeje italian:** _This message was deleted_

[1:49 PM] **You:**
> _Eugeje italian: Last yr i received 270 ke from china; 150ke for the apt, 120 for living expenses / car etc_
Car 24 (+ the Mercedes), 95k a y?🫣 

Are there some business travelling expenses included?

[1:50 PM] **Eugeje italian:** No expenses,

[1:51 PM] **Eugeje italian:** I also take money from germany...living expenses incl holidays etc is like 100

[1:52 PM] **You:** Approx 2,2-2.3?k rent + utilities? = around 26/27?

[1:53 PM] **Eugeje italian:** Shall we perhaps not have that discussion right now..? You are supposed to be on a little holiday...better enjoy it

[1:53 PM] **Eugeje italian:** We can now breath out as the apt is saved...thanks again for yr support 🙏

[1:54 PM] **Eugeje italian:** Have fun over there💃

[1:55 PM] **Eugeje italian:** Making lunch for mika

[1:55 PM] **You:** 1,3 fix kids sport 
0.5 some school charges
0,7 let
..
Still: 120-24-30=66k

Holidays?

[1:55 PM] **You:**
> _Eugeje italian: Have fun over there💃_
Will do thx

[1:55 PM] **You:**
> _Eugeje italian: We can now breath out as the apt is saved...thanks again for yr support 🙏_
Sure

[1:55 PM] **Eugeje italian:** Its a lot in food, lunches, etc...lot of small things

---

## January 18, 2026

[6:23 PM] **You:** Would you pick Dani up or should i do it

[6:23 PM] **You:** ?

[10:51 PM] **Eugeje italian:** I will bring them to school tomorrow

[10:55 PM] **You:** Ok

---

## January 19, 2026

[10:23 AM] **You:** Hi! How are you?

Shall we meet tomorrow  around 12.30/13
 
Or morning around 9 (i have an appointment at 10.15 at Sampierdarena)

[10:23 AM] **You:** I'll take Mika to calcio ⚽️ today

[10:24 AM] **Eugeje italian:**
> _You: I'll take Mika to calcio ⚽️ today_
Can i please take him?

[10:24 AM] **Eugeje italian:** 🙏

[10:24 AM] **You:** Ok. Then i'll do Wednesday

[10:25 AM] **Eugeje italian:**
> _You: Hi! How are you?

Shall we meet tomorrow  around 12.30/13
 
Or morning around 9 (i have an appointment at 10.15 at Sampierdarena)_
We can talk now

[11:31 AM] **You:** thanks for this conversation. 
i throghly appreciated it

[11:37 AM] **Eugeje italian:** Me too...somehow....

---

## January 21, 2026

[11:59 AM] **You:** [Image]

[11:59 AM] **You:** They put your email to download results

[12:03 PM] **Eugeje italian:** Ok, thank you

---

## January 22, 2026

[1:10 PM] **You:** Hi there 
Are you home when Dani's coming?

[1:12 PM] **Eugeje italian:** Hi, yes, i will be home

[1:16 PM] **You:** Ok. Thanks

[3:06 PM] **You:** I'll pick up Mika

[3:09 PM] **Eugeje italian:** Ok, tnx

[5:13 PM] **You:** [Forwarded] [Audio]

[5:13 PM] **You:** [Voice message]

[5:14 PM] **You:** [Voice message]

[5:18 PM] **Eugeje italian:** Sure, i will look, but he never mentioned a baseball cap, just a winterhat, which indeed he might not need

[5:18 PM] **Eugeje italian:** I can look for a sweater / hoodie

[5:19 PM] **Eugeje italian:** With 12 pple, like 120 euro?

[5:19 PM] **Eugeje italian:** No extra Neft gun...2 enough?

[5:20 PM] **Eugeje italian:** Diletta seems to have 5...which now is the reference😁

[5:20 PM] **You:**
> _Eugeje italian: Sure, i will look, but he never mentioned a baseball cap, just a winterhat, which indeed he might not need_
He mentioned it to me in the shop

[5:20 PM] **You:** But there were no no e ones there

[5:20 PM] **Eugeje italian:** Ah, ok

[5:21 PM] **You:**
> _Eugeje italian: No extra Neft gun...2 enough?_
No

[5:21 PM] **You:** Hoodie w pants, cap, t-shirt?

[5:21 PM] **Eugeje italian:** I will look

[6:13 PM] **Eugeje italian:** https://www.armani.com/it-it/cart/

[6:13 PM] **Eugeje italian:** I know he likes this

[6:17 PM] **Eugeje italian:** https://www.armani.com/it-it/ea7/tuta-core-identity-boy-in-cotone-cod-7B000031-AF10380-MC004/?xse_prod_code=7B000031_AF10380_MC004&xse=sm_el_23adad9c1c454fed8d51faa7ec88d123

[6:46 PM] **Eugeje italian:** https://www.nike.com/it/t/felpa-con-cappuccio-in-confortevole-fleece-jordan-a-BgEXJIup/IO2563-010?_gl=1*h8uplv*_up*MQ..*_gs*MQ..&gclid=CjwKCAiAssfLBhBDEiwAcLpwfkPvSXtyy84ZCuQhYc1KxaVXd2e0KP2Kz9EbTjBMzoRI0IItPjGbCRoCuMYQAvD_BwE&gclsrc=aw.ds&gbraid=0AAAAADq9vlMg_Cv47GLQb7ae3iT1-vX0W

[7:01 PM] **Eugeje italian:** From addidas i can't find much

[7:10 PM] **You:** Ok.. I'll check Adidas

---

## January 23, 2026

[12:57 PM] **You:** [Voice message]

[1:17 PM] **Eugeje italian:** Ok, thank you

[1:17 PM] **Eugeje italian:** Shall i bring him to calcio today?

[1:52 PM] **You:**
> _Eugeje italian: Shall i bring him to calcio today?_
Ok

[3:26 PM] **You:** Can we agee x 2row & day after 4 Mika's ⚽:

You: tomorrow 
Me: Sunday?

[4:01 PM] **Eugeje italian:** Can i not watch both games?

[4:02 PM] **Eugeje italian:** Then i can come sunday just to watch

---

## January 25, 2026

[4:29 PM] **Eugeje italian:** [Image]

[4:30 PM] **Eugeje italian:** You better take it, i don't think i will use it

[9:00 PM] **Eugeje italian:** FYI; we bought today for Dani, as little present for Mika's BD. 2 legami lamps and a fairy light

[9:09 PM] **You:**
> _Eugeje italian: FYI; we bought today for Dani, as little present for Mika's BD. 2 legami lamps and a fairy light_
She told me.thx

---

## January 26, 2026

[1:13 PM] **You:** Hi, Eugene! I can take Mika today to ⚽

[1:14 PM] **You:** Thx foe taking them to school

[1:14 PM] **You:**
> _You: Hi, Eugene! I can take Mika today to ⚽_
Have you got his ⚽

[1:14 PM] **You:** From last year?

[1:15 PM] **Eugeje italian:**
> _You: Hi, Eugene! I can take Mika today to ⚽_
Hi, ok, can i take him wednesday?

[1:15 PM] **Eugeje italian:**
> _You: From last year?_
Should be, yes

[1:16 PM] **You:**
> _Eugeje italian: Hi, ok, can i take him wednesday?_
Sure

[1:16 PM] **You:**
> _Eugeje italian: Should be, yes_
Ok. Thx ahead foe passing it to me

[1:18 PM] **Eugeje italian:** I'm home for Dani

[1:24 PM] **You:**
> _Eugeje italian: I'm home for Dani_
Ah. Ok

[1:24 PM] **You:** Was about to get back

[3:48 PM] **Eugeje italian:** [Image]

---

## January 27, 2026

[1:18 PM] **You:** [Voice message]

[1:19 PM] **You:** [Voice message]

[1:28 PM] **Eugeje italian:** Ofc, i will pick him up, likely will play somewhere calcio.

[1:28 PM] **Eugeje italian:** I will make dinner tonight

[1:29 PM] **You:** Ok. Thx

[1:29 PM] **You:** Then i'll do 2row

---

## January 28, 2026

[1:37 AM] **Eugeje italian:** I will bring the kids to school tomorrow

[1:39 PM] **Eugeje italian:** If ok for you, mika will tomorrow not do LET, i think he asked you.

[1:40 PM] **Eugeje italian:** Today hairdresser has no time; tomorrow should be

[1:56 PM] **You:** [Voice message]

[1:57 PM] **You:**
> _Eugeje italian: If ok for you, mika will tomorrow not do LET, i think he asked you._
Or shall we take him at 3 instead of 4. Like this he'll got his compity d9nw there

[1:59 PM] **Eugeje italian:** I called for today; only possible after 4pm

[2:38 PM] **Eugeje italian:**
> _You: Or shall we take him at 3 instead of 4. Like this he'll got his compity d9nw there_
Ok

[3:05 PM] **You:** Buongiorno Olesya, 
scrivo per spiegare l'episodio della nota della scorsa settimana perché all'uscita da scuola è difficile incontrarsi.
Finita la ricreazione stavo spiegando a tutta la classe ma Mika ha continuato a lanciare la pallina di carta ai compagni senza dare importanza a quello che stavamo facendo. 

Io avviso sempre quando la ricreazione sta per finire così i bambini hanno 5 minuti per concludere i giochi e tornare a posto; quando spiego chiedo silenzio e rispetto.
Nei giorni successivi Mika non ha mostrato il diario firmato e all'ennesima richiesta di attenersi alle regole ha  pronunciato una parola gravemente offensiva  davanti alla classe. Si  è trattato di un comportamento inaccettabile, gli ho spiegato che non intendo tollerarlo.

Finalmente ha portato il diario firmato e da allora si comporta in modo rispettoso,  vivace ma educato, gli ho scritto una nota di merito.
Per me è molto importante avere una collaborazione dalle famiglie, perciò ho deciso di scrivervi anche se sono passati alcuni giorni.

Vi chiedo di controllare,  2 volte alla settimana,  il diario,  per verificare se ci sono comunicazioni. 
La ringrazio dell'attenzione, 
Annamaria Capelli

[3:06 PM] **You:** important

[3:06 PM] **You:** from Mika's main maestra

[3:06 PM] **You:** an email

[3:45 PM] **Eugeje italian:** Ok, thank you for sending; i just spoke to mika about it, and aparantly he used the word 'cazzo'.

[3:46 PM] **Eugeje italian:** Its not only at school he is using these words; i think we need to pay attention to his vocabulaire.

[5:11 PM] **You:**
> _Eugeje italian: Its not only at school he is using these words; i think we need to pay attention to his vocabulaire._
Yes

[5:11 PM] **You:** It's also the tone

[5:11 PM] **You:** Aggressive

[5:11 PM] **You:** Offensive

[5:11 PM] **You:** W lack of respect

[5:45 PM] **Eugeje italian:** Yes, and its not getting less..we would need to think how to improve this.

---

## January 29, 2026

[9:07 PM] **You:** [Voice message]

[9:07 PM] **You:** [Voice message]

[9:10 PM] **Eugeje italian:** Ok, will do

[10:12 PM] **You:** Thanks a lot for closing the party well

[10:34 PM] **Eugeje italian:** Sure, thank you for organising it all, and the nice cake, Mika loved it👍

---

## January 30, 2026

[10:49 AM] **You:** I'll pick Mija up

[10:49 AM] **You:** Hello😊

[2:11 PM] **You:** Mika's asking if you could take him to play a ball as you were telling him yesterday 

Or should i?

[2:13 PM] **Eugeje italian:** I will be home in 15 min, but he also has calcio

[2:14 PM] **You:**
> _Eugeje italian: I will be home in 15 min, but he also has calcio_
I know

[4:46 PM] **You:** Just FYI my email to maestra: Buongiorno Maestra, Grazie per scrivermi e prestare la mia attenzione sul'episodio della nota della scorsa settimana. Mi dispiace molto ché Mika si ha comportato in tale modo a scuola, che inaccettabile. 

Sono completamente d'accorda gli ho spiegato pure io che proprio non si può e non sara tollerato.
Sono anche pienamente d'accorda ch'e molto importante avere una collaborazione tra famiglie e maestre, perciò dalla settimana scorsa e poi faccio io e faccio fare anche mio marito (quando sono fuori Genova) da controllare 2 volte alla settimana il diario.  
Sono contenta pero che ultimi giorno Mika si comporta meglio, come dice lei in modo piu rispettoso,  vivace ma educato. 

La ringrazio per la nota di merito.
Mika ci teneva tanto
La ringrazio ancora per la sua gentilezza e per la sua pazienza,

[4:48 PM] **Eugeje italian:** Ok, thank you, good that you replied her👍

---

## January 31, 2026

[5:05 PM] **Eugeje italian:** FYI: i go with Dani to Ikea

[7:40 PM] **You:** Ata?
4 dinner

---

## February 1, 2026

[8:08 PM] **Eugeje italian:** Thank you for organizing the party for Mika, i think we all had a good time 👍

[8:43 PM] **You:** Thanks 🫶🏼

[8:59 PM] **Eugeje italian:** Can we have a cup of coffee tomorrow morning? Then we can initiate the divorce proceedings.

---

## February 2, 2026

[1:46 AM] **You:**
> _Eugeje italian: Can we have a cup of coffee tomorrow morning? Then we can initiate the divorce proceedings._
Sure. But Wednesday or Thursday morning please

[2:03 AM] **Eugeje italian:** Ok

[2:04 AM] **Eugeje italian:** Then wednesday

[9:12 AM] **Eugeje italian:** You might want to consider moving your car; they are going to do new asphalt there

[9:17 AM] **You:** Thanks

[12:00 PM] **Eugeje italian:** I will take Mika to calcio, and will cook tonight

---

## February 3, 2026

[12:21 PM] **Eugeje italian:** I will pick up mika

[12:40 PM] **You:** ок. do you want to take him to pitch by the chirch?

[12:45 PM] **Eugeje italian:**
> _You: ок. do you want to take him to pitch by the chirch?_
Yes

[4:08 PM] **Eugeje italian:** [Document] Avviso di pagamento 301000014321498337.pdf

[4:08 PM] **Eugeje italian:** FYI

[7:40 PM] **You:** Thx a lot

[7:40 PM] **You:** Tomorrow at 8.30/9?

[7:40 PM] **You:** Esselunga/ smth else?

[7:53 PM] **Eugeje italian:** 09.00; where it is quite

[7:53 PM] **Eugeje italian:** Lets try eselunga

---

## February 4, 2026

[10:52 AM] **Eugeje italian:** Ok, you pick up mika, i will pick up Dani

[11:14 AM] **You:**
> _Eugeje italian: Ok, you pick up mika, i will pick up Dani_
Bene

[11:14 AM] **You:** Who takes him to Bogliasco?

[11:16 AM] **Eugeje italian:**
> _You: Who takes him to Bogliasco?_
Up to you

[11:17 AM] **You:** I can take him.

[11:17 AM] **You:** Then you do Friday, I do Sunday?

[11:17 AM] **Eugeje italian:** I also would like to see him play sunday...

[11:18 AM] **Eugeje italian:** Honestly..i want to see them as much as possible

[11:19 AM] **Eugeje italian:** But we can still both go to his partita's, no?

[11:20 AM] **You:**
> _Eugeje italian: But we can still both go to his partita's, no?_
Sure

[11:21 AM] **You:** Just to say i can bring him n u can join latteria u want

[11:25 AM] **Eugeje italian:**
> _You: Just to say i can bring him n u can join latteria u want_
Ok, agreed

[11:29 AM] **You:** [Voice message]

[11:39 AM] **Eugeje italian:** By default

[11:43 AM] **You:** Thanks. That's the one

[11:43 AM] **You:** Could you please cover car insurance

[11:44 AM] **You:**
> _You: Could you please cover car insurance_
[Voice message]

[11:44 AM] **You:** [Voice message]

[11:49 AM] **Eugeje italian:**
> _You: Could you please cover car insurance_
Ok, will do

[2:32 PM] **Eugeje italian:** I will take the insurance money from the joint account

[2:33 PM] **Eugeje italian:** Now our divorce seems to be final, we would need to discuss the finances.

[2:34 PM] **Eugeje italian:** I suggest to have a coffee next week

[2:44 PM] **Eugeje italian:** [Forwarded] [Document] 16161114_1_yourdocumentpdf_260204_143626.pdf

[2:44 PM] **Eugeje italian:** FYI

[7:05 PM] **You:** [Forwarded] Scusate, convince tutti questo compito obbligatorio per venerdì, vedere il film Marie Antoinette? Lo avevo visto.(Quello di Sofia Coppola giusto?) Consigliato a maggiori 16 anni, adatto a giovani o adulti a causa di tutta la parte sulla sessualità della regina e del re, conseguenti amanti ecc. Magari sono io a pensare che tanti aspetti della storia possano mettere in imbarazzo i nostri ragazzini? Se è così solo per me, ne parlerò io alla prof. Forse ci sono film più adatti su quel periodo storico.

[7:05 PM] **You:** [Forwarded] Ho pensato la stessa cosa.
Poi mi è venuto il dubbio che forse non è da vedere quello di Sofia Coppola🤔

[7:06 PM] **You:**
> _You: Scusate, convince tutti questo compito obbligatorio per venerdì, vedere il film Marie Antoinette? Lo avevo visto.(Quello di Sofia Coppola giusto?) Consigliato a maggiori 16 anni, adatto a giovani o adulti a causa di tutta la parte sulla sessualità della regina e del re, conseguenti amanti ecc. Magari sono io a pensare che tanti aspetti della storia possano mettere in imbarazzo i nostri ragazzini? Se è così solo per me, ne parlerò io alla prof. Forse ci sono film più adatti su quel periodo storico._
Let's talk about this and Doria during dinner with Dani

[7:20 PM] **Eugeje italian:**
> _You: Let's talk about this and Doria during dinner with Dani_
Ok

[7:20 PM] **Eugeje italian:** I dont know the movie

[10:08 PM] **You:**
> _Eugeje italian: I dont know the movie_
We'll find it together

---

## February 5, 2026

[8:11 AM] **You:** Mirning. Sorry, but why -1300?

[8:11 AM] **You:** Instead of 500? 
And actually you said you'll give me m9ney back

[8:12 AM] **You:** So  you could have deducted this 500 from there

[8:13 AM] **You:** Right, let's start building pressure

[8:13 AM] **You:** So you)

[8:15 AM] **You:** Send me a scatch of a financial agreement please before next coffee

[8:16 AM] **Eugeje italian:** 502 for the car insurance; 800 to help paying the rent

[8:16 AM] **Eugeje italian:** I'm very low on cash

[8:17 AM] **Eugeje italian:** With this 1300, you cashed out 2300 in total from this 5ke, beside the using the card

[8:19 AM] **Eugeje italian:**
> _You: Instead of 500? 
And actually you said you'll give me m9ney back_
Yes, and i will give you this money back, but right now i'm just extremely low on cash

[8:21 AM] **Eugeje italian:**
> _You: So you)_
I resent your tone; i took it out just because i'm very low on cash to help pay the rent

[8:22 AM] **You:**
> _Eugeje italian: 502 for the car insurance; 800 to help paying the rent_
Could you not comunicate this to me?

[8:22 AM] **You:** Let's pause

[8:22 AM] **You:** No need to fight

[8:23 AM] **Eugeje italian:** Was planning to, i was awake since 4am; i needed to pay the rent now, so i took this 800

[8:23 AM] **You:** Just tell me crucial things that's it

[8:23 AM] **You:** No need ro create extra pressure

[8:23 AM] **You:** Have a good day

[8:24 AM] **Eugeje italian:**
> _You: Just tell me crucial things that's it_
You cashed out 2*500 = 1000 eur at an atm the last 2 weeks...did you tell me...? No, you didn't

[8:24 AM] **Eugeje italian:** Did i get upset / ask questions...? No, i didn't

[8:25 AM] **Eugeje italian:** I assume you act in good faith; you assume i act in bad faith

[8:26 AM] **Eugeje italian:**
> _You: Right, let's start building pressure_
Fine, as you wish

[8:36 AM] **You:**
> _Eugeje italian: Did i get upset / ask questions...? No, i didn't_
You could. I'm trying to organise an income stream x myself..but one can not expect miracles in 2-3 weeks even from supereoman

Let's put agreement 9n paper

[8:36 AM] **You:** I kindly remind u i was busy trying to automise yr site  in December ...

Almost succeded

[8:37 AM] **You:** But then got interrupted by diving into Crypto again to help and save yr apt..

[8:37 AM] **You:** Besides all the personal turmoil

[8:38 AM] **You:** It's impossible to live on such a vulcano, Eugene

[8:39 AM] **You:** We really need 2 settle an agreement and not 2 stand on the way of one another

[8:39 AM] **You:** And avoid all this energy draining conversation

[8:40 AM] **You:** I've also slept 4 h

[8:40 AM] **You:** X alteady mamy days

[8:41 AM] **Eugeje italian:**
> _You: It's impossible to live on such a vulcano, Eugene_
Who started this volcano...?

[8:46 AM] **Eugeje italian:** _This message was deleted_

[8:51 AM] **Eugeje italian:** [Voice message]

[8:52 AM] **Eugeje italian:** [Voice message]

[11:56 AM] **Eugeje italian:** You are the one who is leaving me...for something 'new'....

[11:56 AM] **Eugeje italian:** And still i'm constructive, i don't act out, i stay calm

[11:59 AM] **Eugeje italian:** Am i sad..? Yes, i am. Because i know it should not be necessary; the last few months it went already much nicer, we had fun together....and again because of the tornado's in your head a few weeks ago, everything now blows up...thats hard to accept

[12:03 PM] **Eugeje italian:** You throw away your future with your family....and i can't stop you....after 20 years i still think you are beautiful & special...

[12:05 PM] **Eugeje italian:** But you act if i'm the enemy...over and over again; also 2 weeks ago when i just made a positive comment on yr IG activities...your reaction: you explode from anger...

[12:06 PM] **Eugeje italian:** And then you tell me yesterday that i'm against IG...while i only said something positive...that is not me...thats your tornado in yr own head making me the bad guy

[12:09 PM] **Eugeje italian:** And still....this time i won't let it provoke me...i stay calm & constructive.

[12:11 PM] **Eugeje italian:** So...please don't treat me as the enemy.

---

## February 6, 2026

[8:47 AM] **You:** [Forwarded] [Document] 16339388_1_COMUNICAZIONE SUL SERVIZIO PAGO IN RETE FAMIGLIE.pdf.pdf

[11:08 AM] **Eugeje italian:** [Image] Well...i logged in, it seems to work

[11:09 AM] **Eugeje italian:** [Document] Also paid

[1:21 PM] **You:** Ok. Спасибо 🙏🏻

[5:54 PM] **Eugeje italian:** FYI; I bought food & will cook tonight

[7:41 PM] **You:** [Voice message]

[11:08 PM] **Eugeje italian:** If you would somehow still care for me...then you would take responsibillity for your own mistakes in our marriage....i have taken responsibillity for mine, i'm very sorry that i was not on my best at times, but i learned from it, i changed for the better.

[11:10 PM] **Eugeje italian:** From you...i never heard anything else than blame...not a single word for the things you did which really hurt me.

[11:12 PM] **Eugeje italian:** So please......spare me your 'caring for me'....

---

## February 8, 2026

[5:22 AM] **Eugeje italian:** _This message was deleted_

[5:23 AM] **Eugeje italian:** _This message was deleted_

[11:31 AM] **Eugeje italian:** I will take care of the kids this afternoon

[4:46 PM] **You:** Should i cook dinner or you r eating out with them as you were saying another day?

[5:38 PM] **Eugeje italian:** I will do supermarket and cook

[5:42 PM] **You:**
> _Eugeje italian: I will do supermarket and cook_
I've done a bit: eggs, some veggies, creme and yoghurt

---

## February 9, 2026

[12:31 PM] **You:** Hi! I'd like to take Mika to ⚽2day

---

## February 10, 2026

[1:00 PM] **You:** _You deleted this message_

[1:00 PM] **Eugeje italian:** Ok

[1:00 PM] **You:** Hi! I'll pick Mika up to 2day

[1:12 PM] **Eugeje italian:** I think we also need to pick up Dani

[1:18 PM] **You:**
> _Eugeje italian: I think we also need to pick up Dani_
I'll see if it rains

[1:18 PM] **You:** I'll call her

[1:24 PM] **Eugeje italian:** Ok, tnx

[3:31 PM] **Eugeje italian:** [Document] Documentazione polizza_10022026.pdf

[3:31 PM] **Eugeje italian:** [Document] linear_modulo_CAI.pdf

[3:59 PM] **You:** Thx

---

## February 11, 2026

[11:31 AM] **You:** I'll pick Mika up

[11:32 AM] **Eugeje italian:** Ok

[7:16 PM] **You:** [Voice message]

[7:16 PM] **You:** [Voice message]

[7:16 PM] **You:** [Voice message]

[7:41 PM] **Eugeje italian:** [Voice message]

[8:04 PM] **You:** [Voice message]

[8:21 PM] **Eugeje italian:** [Voice message]

---

## February 14, 2026

[2:55 PM] **Eugeje italian:** We are at marrassi

[2:56 PM] **You:** I know

[2:56 PM] **You:** [Voice message]

[2:56 PM] **Eugeje italian:** Ok

---

## February 15, 2026

[6:23 PM] **You:** Just FMI: d'u eat out with Mika?

[6:24 PM] **Eugeje italian:** Will eat at home

[11:37 PM] **Eugeje italian:** We don't need to meet for coffee; that you want to divorce, doesn't mean i need to leave this house....and for sure we can't keep living like this, so just tell me your planning

[11:37 PM] **Eugeje italian:** As you already announed our divorce, especially to Dani & Mika, i assume you have a plan for yourself; please put it in action asap.

---

## February 16, 2026

[12:16 PM] **Eugeje italian:** I'm on a video call; please do not enter the house until at least 13.00

[12:16 PM] **Eugeje italian:** The kids are in eselunga bar

[12:41 PM] **You:** [Voice message]

[12:43 PM] **You:**
> _Eugeje italian: The kids are in eselunga bar_
I'll join them in 30 min.
As u haven't told me in advance of yr call, i could not change my plans at the last moment

[12:43 PM] **You:** Need to finish smth w my appointment before i can join kids

[12:53 PM] **You:** 15 min

[12:54 PM] **Eugeje italian:** I'm free now, thank you

[12:54 PM] **Eugeje italian:** Kids are fine

[12:55 PM] **You:** [Voice message]

[12:55 PM] **You:** [Voice message]

[12:57 PM] **Eugeje italian:** Ok, i will bring mika then on wedn

[12:58 PM] **Eugeje italian:** No real need to join them: they can be 30 min by themselves in eselunga bar

[1:09 PM] **Eugeje italian:**
> _You: I'll join them in 30 min.
As u haven't told me in advance of yr call, i could not change my plans at the last moment_
I just asked you not to enter the house between 12.30 and 13.00 ; i didn't ask you to join the kids as they can be perfectly by themselves for 30 min in eselunga bar

[1:12 PM] **You:**
> _Eugeje italian: I just asked you not to enter the house between 12.30 and 13.00 ; i didn't ask you to join the kids as they can be perfectly by themselves for 30 min in eselunga bar_
[Voice message]

[1:14 PM] **You:** [Voice message]

[1:16 PM] **Eugeje italian:** I don't think i need to pre communicate with you if i ask the kids to be in eselunga bar for 30 min...thats a very small thing.

[1:17 PM] **Eugeje italian:** Dani goes there frequently, now she was with mika

[1:18 PM] **Eugeje italian:** And nobody is 'kicking anybody out of the house'.

[1:28 PM] **You:**
> _Eugeje italian: And nobody is 'kicking anybody out of the house'._
FYI: "nobody" can do it

[1:29 PM] **You:** Legally female rights are protected

[1:29 PM] **You:** Emotionally though it's very disturbing yr messages

[1:29 PM] **You:** This is the main reason why we are not together

[1:30 PM] **You:** Yet again: let's try to keep respectful and civilised approach

[1:31 PM] **You:** From my side i'm showing you everytime i'm ready to help, not only by words but in a tion

[1:31 PM] **You:** In return, i got this kind of feedback from you..

[1:31 PM] **You:** Ps don't respond

[1:32 PM] **Eugeje italian:**
> _You: This is the main reason why we are not together_
I can think of another few reasons...

[1:34 PM] **Eugeje italian:**
> _You: FYI: "nobody" can do it_
You know very well what i mean.

[1:37 PM] **Eugeje italian:** You know very well that i'm not trying to 'kick you out of the house'...i'm the one still sleeping here on the floor

[2:15 PM] **Eugeje italian:** Ok...breath in&out; i will do supermarket and cook tonight

---

## February 17, 2026

[11:55 AM] **You:** [Forwarded] Buongiorno, domenica 1 marzo mattina si terrà la terza tappa del FJP Green maschile a S.Margherita o Zoagli. Se volete partecipare confermatemi l'iscrizione entro lunedì 23, grazie

[8:41 PM] **Eugeje italian:**
> _You: Buongiorno, domenica 1 marzo mattina si terrà la terza tappa del FJP Green maschile a S.Margherita o Zoagli. Se volete partecipare confermatemi l'iscrizione entro lunedì 23, grazie_
Well, depending if he has a partita on March 1st...

---

## February 18, 2026

[9:59 AM] **You:** Hi, could you, please tell Lessia /or myself when will you be able to refund her 5k?

[10:12 AM] **Eugeje italian:** Lets first see how that money was spend

[10:13 AM] **Eugeje italian:** I took 500 for your car insurance, and 800 for the rent in a house also you are living in

[10:15 AM] **Eugeje italian:** According to you we are already divorced...so why do you think only i need to pay for all costs...? Including your personal expenses...please explain

[10:16 AM] **Eugeje italian:** I can explain her who actually used that money, no problem.

[10:17 AM] **Eugeje italian:** To start with, you moved 1300 eur to your own account and cashed 500 eur at an atm.

[10:18 AM] **Eugeje italian:** I didn't use that money to pay off my apt....you used most of it

[10:25 AM] **Eugeje italian:** I already replied to you on the other phone, but you ignore those messages

[10:44 AM] **Eugeje italian:** I suggest we sit down for a coffee and quietly discuss the housing issue and costs which should be paid.

[11:37 AM] **You:** I'll pick Mika up

[11:37 AM] **You:** Then Bogliasco s on me

[11:38 AM] **You:** Ps do Friday & Sund

[11:49 AM] **Eugeje italian:** Ok

[12:44 PM] **Eugeje italian:** Pse check the messages on the other phone, to keep this channel as clean as possible

[1:22 PM] **You:** Ps open the door 2 Mik

[1:27 PM] **Eugeje italian:** He is inside

[4:08 PM] **You:** Ps send him down in 5

[4:11 PM] **Eugeje italian:** Ok

[5:51 PM] **Eugeje italian:** [Video]

---

## February 19, 2026

[4:25 PM] **Eugeje italian:** Edo asked if Mika could play after tennis, but then he needs to skip atletica. Ok for you?

---

## February 20, 2026

[10:16 AM] **Eugeje italian:** Remember how you were shouting at me, because i forgot to tell you that Natasha would come.....?

[10:17 AM] **Eugeje italian:** Luckily i'm different

[10:18 AM] **You:** Apologies

[10:19 AM] **You:**
> _Eugeje italian: Pse check the messages on the other phone, to keep this channel as clean as possible_
Thought you wanted "to keep this channel as clean as possible"

[10:21 AM] **Eugeje italian:** If course, thats your reaction

[10:26 AM] **Eugeje italian:** I will not miss your verbal abuses...nor will i miss a wife who shows everybody else the best side of her....but not her own husband. 😏

[11:02 AM] **You:** Will pick Mika up

---

## February 21, 2026

[12:50 PM] **You:** [Image]

[12:50 PM] **You:** I'd suggest a ☕ next week

[1:31 PM] **You:** [Forwarded] [Audio]

[1:31 PM] **You:** [Forwarded] [Audio]

---

## February 22, 2026

[1:39 AM] **Eugeje italian:** Scusa, since when do we leave the kids alone in the night...?

[1:40 AM] **Eugeje italian:** I left the house when you were still there

[3:50 PM] **You:** [Voice message]

[3:50 PM] **You:**
> _Eugeje italian: Scusa, since when do we leave the kids alone in the night...?_
[Voice message]

[3:50 PM] **You:** [Voice message]

[4:00 PM] **Eugeje italian:** I was out, i was not home, otherwise i wouldn't send you this message. I was only in mika's bed for a few minutes, then went to Dani, then did the garbage etc and left the house

[4:25 PM] **Eugeje italian:** Nothing happened, they were asleep, perhaps just double check next time if you don't see me, thats all

[10:38 PM] **Eugeje italian:** _This message was deleted_

[10:40 PM] **Eugeje italian:** _This message was deleted_

---

## February 23, 2026

[1:00 PM] **Eugeje italian:** Greetings; will you bring mika to training, or shall i?

[3:24 PM] **You:** I'll pick Mika up

[3:27 PM] **Eugeje italian:** Ok

[6:47 PM] **You:** [Forwarded] [Image]

[6:47 PM] **You:** Shall Mika do a gift separately (not with class, nor with calcio team)?

[6:48 PM] **You:** Then it's like 40 tb spent instead of 20 (10 w class + 10 w ⚽️)?

[6:48 PM] **You:** Nerf or a sweatshirt?

[7:09 PM] **Eugeje italian:**
> _You: Shall Mika do a gift separately (not with class, nor with calcio team)?_
Yes, i think we should do separately.

[7:09 PM] **Eugeje italian:**
> _You: Nerf or a sweatshirt?_
I will ask Marco

---

## February 24, 2026

[2:15 PM] **You:** Planning:
Mornings school: 
Mon: euge
Tues: euge 
Wed: euge
Tursd: ale
Fr: ale
Sat (partita): ale

Noons (school, training)
Mon: ale
Tues: ale
Wed: ale
Tursd: euge
Fr: euge
Sund (activity)


Any other 2b added

Planning:
Mornings school: 
Mon: euge
Tues: euge 
Wed: euge
Tursd: ale
Fr: ale
Sat (partita): ale


Planning:
Mornings school: 
Mon: euge
Tues: euge 
Wed: euge
Tursd: ale
Fr: ale
Sat (partita): ale

[2:16 PM] **You:**
> _You: Planning:
Mornings school: 
Mon: euge
Tues: euge 
Wed: euge
Tursd: ale
Fr: ale
Sat (partita): ale

Noons (school, training)
Mon: ale
Tues: ale
Wed: ale
Tursd: euge
Fr: euge
Sund (activity)


Any other 2b added

Planning:
Mornings school: 
Mon: euge
Tues: euge 
Wed: euge
Tursd: ale
Fr: ale
Sat (partita): ale


Planning:
Mornings school: 
Mon: euge
Tues: euge 
Wed: euge
Tursd: ale
Fr: ale
Sat (partita): ale_
[Voice message]

[2:19 PM] **Eugeje italian:** Good to do planning; but would like some changes: fe for today i promised mika to pick him up and play or tennis or calcio

[2:19 PM] **Eugeje italian:** And would also 2 times training

[3:26 PM] **You:** As agreed. Ps send ma an invitation to yr Google (or other calendar) 4 convenience of plan adjustments

[10:38 PM] **Eugeje italian:** https://teamup.com/c/gpsvw2

---

## February 25, 2026

[1:23 AM] **You:**
> _Eugeje italian: https://teamup.com/c/gpsvw2_
You need to give ma e password or undicate a specific email

[2:07 AM] **Eugeje italian:** E.rasing@hotmail.com

[2:07 AM] **Eugeje italian:** Kids@Calendar

[12:41 PM] **You:**
> _Eugeje italian: Kids@Calendar_
[Voice message]

[12:41 PM] **You:** [Voice message]

[12:52 PM] **Eugeje italian:** I'm home for Dani

[12:53 PM] **Eugeje italian:** [Forwarded] [Image]

[12:53 PM] **Eugeje italian:** [Forwarded] [Image]

[12:53 PM] **Eugeje italian:** Password; Kids@Calendar

[1:00 PM] **You:** Ah.ok

[1:01 PM] **You:** Thanks

[2:07 PM] **Eugeje italian:** Thank you for lunch

[2:30 PM] **You:**
> _Eugeje italian: https://teamup.com/c/gpsvw2_
I don't understand how to change double filled (booked (C1))

[6:17 PM] **Eugeje italian:** Pse check what & how you filled in; you use calendar 2, which is fine, but you now have the same schedule for coming weeks, incl. Mika partita sat.

[6:17 PM] **Eugeje italian:** I suggest we plan for 1 week ahead.

---

## February 26, 2026

[9:25 AM] **Eugeje italian:** _This message was deleted_

[9:49 AM] **Eugeje italian:** I put it in correctly; i will use calendar 1, which is purple, you will use calendar 2, which is green. Then you can see already at the color who is doing what. Please no 'repeats' as we will alternate week by week.

[7:06 PM] **Eugeje italian:** FYI; we will be home late, more like 20.30 / 21.00

---

## February 27, 2026

[11:40 PM] **Eugeje italian:** _This message was deleted_

[11:42 PM] **Eugeje italian:** _This message was deleted_

[11:49 PM] **Eugeje italian:** _This message was deleted_

[11:53 PM] **Eugeje italian:** _This message was deleted_

[11:54 PM] **Eugeje italian:** _This message was deleted_

[11:57 PM] **Eugeje italian:** _This message was deleted_

---

## February 28, 2026

[2:44 AM] **Eugeje italian:** _This message was deleted_

[2:46 AM] **Eugeje italian:** _This message was deleted_

[2:49 AM] **Eugeje italian:** _This message was deleted_

[2:56 AM] **Eugeje italian:** _This message was deleted_

[10:30 AM] **Eugeje italian:** Nah...its not worth while my time anymore...😏

[12:07 PM] **You:** Hi! Could you, Ps, confirm if you have paid the gift for Edo on Mika's behalf and on behalf of Leo. 

Thx

[12:09 PM] **You:** After the game i can bring mika the the BD party, 

would you please reconfirm if you'll come there (as you told me yesterday). 

what time?

[12:12 PM] **You:**
> _You: Hi! Could you, Ps, confirm if you have paid the gift for Edo on Mika's behalf and on behalf of Leo. 

Thx_
How much?

[12:14 PM] **Eugeje italian:**
> _You: How much?_
20 Eur; 10 per person

[12:20 PM] **Eugeje italian:** _This message was deleted_

[2:48 PM] **Eugeje italian:** Will be at compleano

[3:48 PM] **You:** Ok.thanks

[10:49 PM] **Eugeje italian:** _This message was deleted_

[10:50 PM] **Eugeje italian:** _This message was deleted_

---

## March 1, 2026

[7:43 PM] **Eugeje italian:** FYI; i put the agenda in for coming week.

---

## March 2, 2026

[11:11 AM] **You:**
> _Eugeje italian: FYI; i put the agenda in for coming week._
Hi, can we not do the same as last week?

[11:11 AM] **Eugeje italian:** Why?

[11:17 AM] **You:** [Voice message]

[11:19 AM] **Eugeje italian:** Tuesd Mika and i play together, thursday i'm already close bye. So makes sense for me to pick up mika tursd and thursd. I also like to bring him to calcio. I already give you only 2 early mornings, while i take 3

[11:20 AM] **Eugeje italian:** You put partita on saturday, while i checked the schedule and put it on sunday with the correct time...?

[11:21 AM] **Eugeje italian:** I also like to bring mika to partita...i suggest to alternare, not to have always the same parent bringing him to partita

[11:27 AM] **You:**
> _Eugeje italian: Tuesd Mika and i play together, thursday i'm already close bye. So makes sense for me to pick up mika tursd and thursd. I also like to bring him to calcio. I already give you only 2 early mornings, while i take 3_
That's whay i take sunday partita

[11:28 AM] **Eugeje italian:** You brought him already this saturday

[11:28 AM] **You:** Not to be mentioned that for all the years of their school almost always it was me

[11:28 AM] **Eugeje italian:** Last saturday...

[11:28 AM] **You:** Is it again an argument here

[11:30 AM] **Eugeje italian:** If you make it into one; we agreed that we would alternate bringing him to partita's....you brought him last saturday, i bring him next time

[11:31 AM] **You:** Coffee at 14? Easier to explain talking

[11:31 AM] **You:** No need to fight

[11:32 AM] **You:**
> _Eugeje italian: If you make it into one; we agreed that we would alternate bringing him to partita's....you brought him last saturday, i bring him next time_
Also no need to blame

[11:33 AM] **Eugeje italian:** In this week's schedule you already bring him 2 times to training, i only 1 time. You also want him to bring always to his partita's? Thats your way of dividing it evenly?

[11:34 AM] **Eugeje italian:**
> _You: Coffee at 14? Easier to explain talking_
No, thank you

[11:36 AM] **Eugeje italian:**
> _You: Not to be mentioned that for all the years of their school almost always it was me_
Not to be mentioned that for all the years that we rented an apartment, which was appr. 18 years... it was always me paying...good, lets change that from now

[11:37 AM] **Eugeje italian:** _This message was deleted_

[11:39 AM] **Eugeje italian:** Not for once a simple thing goes easy with you...always looking for an argument; we agreed on 1 time you bringing him to partira, the other time me...but the 2nd week, you already want to change the agreement

[12:31 PM] **Eugeje italian:** Fine, ignore me, don't reply on messages...have it your way

[12:44 PM] **You:** [Voice message]

[12:45 PM] **You:** [Voice message]

[12:51 PM] **Eugeje italian:** Its very simple; i already gave you 2 trainings this week, and you had the partita of last saturday; nevertheless you kept insisting that also now you should bring mika again to his partita of coming weekend.

[12:52 PM] **Eugeje italian:** But i know...you just do that to push my nerves..just to make my life miserable. You knew the schedule was ok...you just need to make it difficult

[12:54 PM] **Eugeje italian:** We need asap to sell the apt and land in moscow;  split the money in 2, then there is enough for both for some time.

[12:54 PM] **Eugeje italian:** We can't keep living like this, especially when you use any opportunity to pick an argument

[12:56 PM] **Eugeje italian:** I have zero money left, i even can't pay my own salary anymore. I need to borrow money everywhere. And it will take 5 months to get organised for myself. We can't wait that long

[12:56 PM] **Eugeje italian:** You might enjoy all this, denying on the simple agreement with the calcio, very well knowing it would upset me...but you do it anyway

[1:03 PM] **Eugeje italian:**
> _You: Voice message_
Non residing doesn't mean automatically 1 week here, another week there. For you apparently its ok, but i don't want to be the whole week without the kids....and i think they also don't want that

[1:05 PM] **Eugeje italian:** It becomes 'easier', when you adhere to the agreement we make...it becomes difficult when you inmidiately start changing smth to your own advantage.....

[1:08 PM] **Eugeje italian:** But i know...you will keep doing this...just to divorce for you is not enough...you need to make my life as miserable as possible...

[1:10 PM] **You:**
> _Eugeje italian: But i know...you will keep doing this...just to divorce for you is not enough...you need to make my life as miserable as possible..._
Please stop being offencive

[1:12 PM] **You:** [Voice message]

[1:12 PM] **Eugeje italian:** Who is being offensive? Who starts arguing about a schedule while you know its ok?

[1:13 PM] **You:** [Voice message]

[1:13 PM] **Eugeje italian:** You are bullying me

[1:13 PM] **You:** [Voice message]

[1:13 PM] **Eugeje italian:** I have no money...🤣🤣🤣

[1:13 PM] **You:**
> _Eugeje italian: You are bullying me_
[Voice message]

[1:14 PM] **You:** [Voice message]

[1:14 PM] **You:** [Voice message]

[1:15 PM] **Eugeje italian:** [Voice message]

[1:16 PM] **Eugeje italian:** [Voice message]

[1:17 PM] **Eugeje italian:** [Voice message]

[1:19 PM] **Eugeje italian:** You just try to 'create an issue'...thats all....

[1:20 PM] **Eugeje italian:** Nobody bothers you here in the house, you even have the bedroom while i sleep on the floor.

[1:24 PM] **Eugeje italian:**
> _Eugeje italian: But i know...you will keep doing this...just to divorce for you is not enough...you need to make my life as miserable as possible..._
Precisely my point; you just want to create drama for me and the kids....just to rattle my nerves

[1:42 PM] **Eugeje italian:** You live in the house which i provide, food, car, which i provide. Somehow with loans i try to keep doing that. The only thing i ask you is to keep to the agreement for the schedule, especially the calcio...but in return, you try to take it all, incl all partita's.

[1:43 PM] **Eugeje italian:** And then you create a drama because i don't like that...??

[1:50 PM] **Eugeje italian:**
> _You: Voice message_
This is soooo toxic; 'pretending' that its not safe here...you are sooo evil...but mind you; many witnesses that its you have been shouting at me...witnesses that its calm here in the house, nobody will support your version

[1:55 PM] **Eugeje italian:** False accusations are also a thing...

[2:24 PM] **Eugeje italian:** I'm coming to you; have a quite conversation...and here you come again with the camera.

[2:24 PM] **Eugeje italian:** Still calling you to settle things down before the kids come home...but no

[2:28 PM] **You:** Anything constructive ps

[2:28 PM] **You:** Instead of :"you don't care about kids" "you only care about yourself"?

[2:29 PM] **You:**
> _You: Instead of :"you don't care about kids" "you only care about yourself"?_
Settling down you call this?

[2:29 PM] **You:** Kindly refrain from this language this isn't helping anything

[2:30 PM] **You:** Ps confirm u r out before 16 00 so then i can safely enter the house without any blames  from yr side

[2:31 PM] **Eugeje italian:**
> _You: Kindly refrain from this language this isn't helping anything_
Kindly refrain from making false accusations...that doesn't help

[2:32 PM] **Eugeje italian:**
> _You: Ps confirm u r out before 16 00 so then i can safely enter the house without any blames  from yr side_
Kindly confirm you stop shouting at me and making false accusations, thank you

[2:33 PM] **You:**
> _Eugeje italian: Kindly refrain from making false accusations...that doesn't help_
I'm sending the video from now and from 2 years ago to yr family now if you keep going

[2:33 PM] **Eugeje italian:**
> _You: I'm sending the video from now and from 2 years ago to yr family now if you keep going_
Please do 🤣🤣🤣

[2:33 PM] **You:** I don't know why d you do this actually

[2:33 PM] **You:** Ok

[2:34 PM] **Eugeje italian:** I will send a few things around myself as well...

[2:34 PM] **You:** All i asked is to leave me alone

[2:34 PM] **You:**
> _Eugeje italian: I will send a few things around myself as well..._
Go ahead

[2:35 PM] **Eugeje italian:**
> _You: All i asked is to leave me alone_
All i asked is to keep the agreement about the schedule...and you not to make false accussations

[2:36 PM] **Eugeje italian:**
> _You: I'm sending the video from now and from 2 years ago to yr family now if you keep going_
Your toxicity reaches again a new level...🤣🤣

[2:43 PM] **Eugeje italian:** _This message was deleted_

[2:44 PM] **Eugeje italian:** You really want 85 yr olds to get a heart attack out out of this???

[2:44 PM] **Eugeje italian:** Are you really insane here??

[2:46 PM] **Eugeje italian:** _This message was deleted_

[2:46 PM] **Eugeje italian:** Have you lost completely your mind dragging my parents into this??

[2:46 PM] **Eugeje italian:** You have no class at all??

[9:00 PM] **Eugeje italian:** [Forwarded] [Image]

[9:00 PM] **Eugeje italian:** FYI

---

## March 3, 2026

[10:25 PM] **You:**
> _Eugeje italian: Image_
I didn't get it

[10:33 PM] **You:** Are you just trying to keep insulting me?)

[10:33 PM] **You:** 👏🏽👏🏽👏🏽👏🏽👏🏽👏🏽👏🏽
👏🏽👏🏽👏🏽👏🏽👏🏽👏🏽👏🏽

[10:33 PM] **You:** Whatever

[10:33 PM] **You:** Used to it

---

## March 4, 2026

[12:03 AM] **Eugeje italian:** I send you again the instructions to log in; how is that insulting?

[12:04 AM] **Eugeje italian:** There is the link, email & password.

[12:07 AM] **Eugeje italian:** Go to teamup.com

[12:07 AM] **Eugeje italian:** Go to login

[12:07 AM] **Eugeje italian:** Use the email & password

[12:07 AM] **Eugeje italian:** Again; how is that insulting?

[12:08 AM] **Eugeje italian:** I suggest you try to keep your attitude cooperative, instead of this.

[12:09 AM] **Eugeje italian:** I send you this before, it worked; you ask again; i send it again. What is now 'insulting' about this?

[8:22 AM] **You:** [Image] Ps confirm nothing's changed

[8:23 AM] **Eugeje italian:** Nothing has changed

[8:23 AM] __You added Papa and Julia Zinnik Mob__

[8:23 AM] __Eugeje italian left__

[8:25 AM] **You:** When any updat SUGGESTED, NOT ULTIMATUMED, let's send a link 2 one another. 

Not just FYI

[10:03 AM] **Papa:** Привет, уже все поняли!🤣🤣🙏🙏🙏👍😘

---

## March 5, 2026

[9:07 PM] **You:** Unfortunately as i see the way it's being going we'd need to add to an agenda who the kids are  having the dinner with each day

[9:09 PM] **You:** I don't feel coming out of my room to eat together when you pretend nothing happened after all has been said today just dee hours ago

[9:11 PM] **You:** And talking u/me doesn't help as we both know, so whenever you are ready wuthin March let's please make an appointment with a mediator/ lawyer to set up a plan

[9:14 PM] **You:** You enjoy a company of kids at dinner.and i cant ..  and i also want to have this..

Please send me your suggestions in calender

[9:16 PM] **You:**
> _You: You enjoy a company of kids at dinner.and i cant ..  and i also want to have this..

Please send me your suggestions in calender_
In a sense, i don't enjoy the pretense

[9:16 PM] **You:** I stick with them

[9:17 PM] **You:** But you and me, we need to see each other as little as possible

[9:17 PM] **You:** With no pretence

[9:18 PM] **You:** And no blame

[9:19 PM] __You added Mama__

[9:20 PM] **You:** My usual )) what you i wish to you will ever share with somebody

---

## March 8, 2026

[6:19 PM] **You:** Eugene, i's just calling to riconfirm who picks up who (d/m))

[8:43 PM] **You:** [Image] I'll feed Mika now, if you don't mind. He's hungry

---

## March 9, 2026

[8:55 PM] **You:** Would it be possible to have a ☕ tomorrow? What time?

[9:20 PM] **You:** And I need at least 1000 
I can't go around with coins in my pocket..

[9:21 PM] **You:** I was counting on your words you'd give me money back ..

[9:21 PM] **You:** At least something before i start making something

[9:22 PM] **You:** I gave you all my cash, when you were in trouble.. i ve also asked my friends

[9:23 PM] **You:** Now i literally have no other spurse to pull any penny from

[9:23 PM] **You:** I also risk to lose my best friend in Italy..

[9:23 PM] **You:** And you act as if it's all normal and good

[9:24 PM] **You:** Even managed to blame me again

[9:24 PM] **You:** And to say that i eat your food which you provide

[9:24 PM] **You:** I dont need your food

[9:25 PM] **You:** I don't need yr money

[9:25 PM] **You:** But i need mine back

[9:25 PM] **You:** At least something that I can g0 around

[9:27 PM] **You:** Mind that December i.was busy with yr site automation, and wpuld have delivered, if i dlwould not  have to drop everything to divw back to Crypto to save YOUR apartment 
..

[9:28 PM] **You:** What i'm left with?!

[9:28 PM] **You:** Blames and a whole in the pocket

[9:28 PM] **You:** And ofcourse alla totally my "fault" i m brok, lost, and powerless

[9:29 PM] **You:** Even back infront 9f the children

[9:29 PM] **You:** _You deleted this message_

[9:31 PM] **You:** At least if you would have non taken money from the joint account i could have maybe pulled it through without  all this misery.. before i can start gaining something

[9:31 PM] **You:** But Ok..

[9:31 PM] **You:** I guess, i need to ask someone else

[9:31 PM] **You:** Though you did ask ME!

[9:32 PM] **You:** And I was there for you, even that we were already NOT TOGETHER

[9:33 PM] **You:** And I didn't blame, nor ask how was it all possible nor claimed "you have much more money then me" e c t what you are saying ..

[9:33 PM] **You:** Whatever

[9:33 PM] **You:** You do you

---

## March 10, 2026

[11:23 AM] __Mama left__

---

## March 12, 2026

[9:20 AM] **You:** [album message]

[9:20 AM] **You:** [Image] Do my 5% 
I spent a couple of days this time
A number of month of my life i guess i total... "nobody" counts ofcourse.

haven't managed this time
Be the New Ps do take over

[9:40 AM] **You:** Or 2% was it? ..
Don't really remember 
No offence))

---

## March 15, 2026

[12:52 PM] **You:** Calendar Kids | Teamup https://share.google/8twdqDjRAJbsiwCEf

[12:52 PM] **You:**
> _You: Calendar Kids | Teamup https://share.google/8twdqDjRAJbsiwCEf_
Hi! Filled in. 
Ps confirm yrs

[10:28 PM] **You:** Would you please be so kind to remind me if you have made an appointment for Dani's next medical visit

[10:28 PM] **You:** Thx
