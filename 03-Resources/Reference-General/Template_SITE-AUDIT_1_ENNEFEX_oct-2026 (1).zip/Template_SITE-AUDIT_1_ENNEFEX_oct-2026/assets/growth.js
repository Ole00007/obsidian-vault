/* growth.js — reveal-on-scroll animations + break-even calculator. Respects prefers-reduced-motion. */
(function () {
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var els = document.querySelectorAll('.reveal,.ladder,.flow');
  function show(el) { el.classList.add('in'); }
  if (reduce || !('IntersectionObserver' in window)) { els.forEach(show); }
  else {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { show(e.target); io.unobserve(e.target); } });
    }, { threshold: 0.12 });
    els.forEach(function (el) { io.observe(el); });
  }
  var c = document.querySelector('[data-calc]');
  if (!c) return;
  var q = function (n) { return c.querySelector('[name="' + n + '"]'); };
  var f = { val: q('val'), com: q('com'), dir: q('dir'), n: q('n'), pkg: q('pkg') };
  function num(el) { var v = parseFloat(String(el.value).replace(',', '.')); return isFinite(v) && v >= 0 ? v : 0; }
  function fmt(x, d) {
    var l = document.documentElement.getAttribute('data-lang') === 'en' ? 'en-GB' : 'it-IT';
    return new Intl.NumberFormat(l, { maximumFractionDigits: d || 0, minimumFractionDigits: d || 0 }).format(x);
  }
  function out(k, v) { c.querySelectorAll('[data-out="' + k + '"]').forEach(function (e) { e.textContent = v; }); }
  function bar(k, pct) { var e = c.querySelector('[data-bar="' + k + '"]'); if (e) e.style.width = Math.max(0, Math.min(100, pct)) + '%'; }
  function render() {
    var val = num(f.val), com = num(f.com), dir = num(f.dir), n = num(f.n);
    var o = f.pkg.options[f.pkg.selectedIndex], cmin = +o.getAttribute('data-min'), cmax = +o.getAttribute('data-max');
    var per = val * Math.max(com - dir, 0) / 100, save = per * n;
    out('per', '€ ' + fmt(per, 2)); out('save', '€ ' + fmt(save, 0)); out('cost', '€ ' + fmt(cmin) + '–' + fmt(cmax));
    out('be', per > 0 ? Math.ceil(cmin / per) + '–' + Math.ceil(cmax / per) : '—');
    out('save2', '€ ' + fmt(save, 0)); out('cost2', '€ ' + fmt(cmin) + '–' + fmt(cmax));
    var top = Math.max(save, cmax, 1); bar('save', save / top * 100); bar('cost', cmax / top * 100);
    var v = c.querySelector('.calc__verdict'); v.setAttribute('data-on', save >= cmax ? 'ok' : (save >= cmin ? 'min' : 'no'));
  }
  c.addEventListener('input', render); c.addEventListener('change', render);
  new MutationObserver(render).observe(document.documentElement, { attributes: true, attributeFilter: ['data-lang'] });
  render();
})();
