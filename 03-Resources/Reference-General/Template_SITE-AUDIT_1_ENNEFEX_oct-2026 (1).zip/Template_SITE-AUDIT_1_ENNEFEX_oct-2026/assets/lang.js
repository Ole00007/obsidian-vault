/* Language toggle: IT <-> EN via globe button.
   Preserves language across pages via URL param ?lang= and in-memory state. */
(function () {
  const root = document.documentElement;
  const params = new URLSearchParams(location.search);
  let lang = params.get('lang');
  if (!lang) {
    lang = window.__auditLang || 'it'; // default Italian (client-facing)
  }
  setLang(lang);

  document.querySelectorAll('[data-lang-toggle]').forEach(btn => {
    btn.addEventListener('click', () => {
      setLang(lang === 'it' ? 'en' : 'it');
    });
  });

  function setLang(l) {
    lang = l;
    window.__auditLang = l;
    root.setAttribute('data-lang', l);
    root.setAttribute('lang', l);
    // keep lang across navigation — preserve relative paths (works on any base URL)
    document.querySelectorAll('a[href]').forEach(a => {
      const href = a.getAttribute('href');
      if (!href || href.startsWith('#') || (href.startsWith('http') && !href.startsWith(location.origin)) || href.startsWith('mailto:') || href.startsWith('tel:')) return;
      try {
        const url = new URL(href, location.href); // resolve against current doc, not origin
        url.searchParams.set('lang', l);
        a.setAttribute('href', url.href === location.origin + url.pathname ? url.pathname + '?' + url.searchParams.toString() : url.href);
      } catch (e) {
        const sep = href.indexOf('?') >= 0 ? '&' : '?';
        a.setAttribute('href', href + sep + 'lang=' + l);
      }
    });
    const btn = document.querySelector('[data-lang-toggle]');
    if (btn) btn.textContent = l === 'it' ? '🌐 EN' : '🌐 IT';
  }
})();
