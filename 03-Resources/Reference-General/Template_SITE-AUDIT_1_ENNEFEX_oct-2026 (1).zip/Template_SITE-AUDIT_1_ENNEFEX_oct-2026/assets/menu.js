/* menu.js — hamburger (sandwich) menu for mobile/tablet. Required in every HTML file. */
(function () {
  var btn = document.querySelector('.menu-toggle');
  var nav = document.getElementById('site-menu');
  if (!btn || !nav) return;
  function set(open) {
    nav.classList.toggle('is-open', open);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  btn.addEventListener('click', function () { set(!nav.classList.contains('is-open')); });
  nav.addEventListener('click', function (e) { if (e.target.closest('a')) set(false); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && nav.classList.contains('is-open')) { set(false); btn.focus(); }
  });
  document.addEventListener('click', function (e) {
    if (nav.classList.contains('is-open') && !nav.contains(e.target) && !btn.contains(e.target)) set(false);
  });
  window.addEventListener('resize', function () { if (window.innerWidth > 1100) set(false); });
})();
