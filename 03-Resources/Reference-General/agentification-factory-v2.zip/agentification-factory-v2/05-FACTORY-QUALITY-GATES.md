# Factory Quality Gates

## Pipeline

```text
INTAKE → AUDIT → ISOLATE → BUILD → PROVE → ПЕРЕКРЁСТНЫЙ ТЕСТ → SCORE → HUMAN SHIP → OBSERVE
```

## Isolate

- Fresh branch from current `origin/main`.
- Dedicated Git worktree and task manifest.
- Explicit allowed files, tools, systems, data, and spend.
- No agent works directly on `main`.

## Build

- Builder reads repository rules and current architecture.
- Existing interfaces are reused before new infrastructure is added.
- Code, tests, migrations, docs, metrics, and rollback are one change set.
- Scope expansion stops for approval.

## Prove

Evidence must include:

- Reproducible before state.
- Exact commands and environment.
- Automated test/lint/build/security results.
- Functional after state: screenshots, video, payload, logs, or measured values.
- Diff summary and known limitations.
- Cost and latency where AI is in the runtime path.

## Перекрёстный тест

An independent profile/session must:

- Reproduce the problem without builder coaching.
- Test expected, edge, failure, permission, and recovery paths.
- Verify claims against artifacts rather than narrative.
- Check unrelated workflows for regression.
- Issue blocking/non-blocking findings with evidence IDs.

## 5/5 score

| Point | Pass condition |
|---|---|
| 1. Scope | Correct task, architecture, and isolated diff |
| 2. Technical | Relevant automated checks pass |
| 3. Operational | Workflow works against realistic cases and integrations |
| 4. Safety | Privacy, security, permissions, recovery, and cost pass |
| 5. Delivery | PR, evidence, docs, monitoring, rollback, and human owner complete |

A missing point returns the task to the failing stage. The agent cannot round up, self-waive, or replace evidence with confidence language.

## Ship

- Agent opens/updates the PR; it cannot merge.
- Human release owner reviews the evidence pack and unresolved risks.
- Protected branch and required CI checks enforce the decision.
- Production release begins as canary, narrow cohort, or reversible slice.

## Cleanup

- Preserve branch and worktree until merge and rollback window pass.
- Archive task manifest, evidence index, score, costs, incidents, and decisions.
- Remove worktree only after a clean status check and human-authorized cleanup.
- Promote recurring verified learning into skills; never auto-edit global rules.
