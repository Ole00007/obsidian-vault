# Industry Playbooks

These modules adapt the same audit and integration method to four operational environments. They are starting hypotheses, not substitutes for observing each company.

## Legal services

### Systems to discover

Practice/case management, document management, email/calendar, billing, court/e-filing portals, identity/e-signature, research tools, CRM/intake, telephony, and knowledge bases.

### High-value workflows

- Intake completeness, conflict-check preparation, and matter routing.
- Document collection, naming, chronology, and missing-evidence follow-up.
- Deadline extraction and supervised docket/calendar preparation.
- Contract/due-diligence review with citations and exception queues.
- Time-entry suggestions, pre-bill review, and client-status draft updates.
- Knowledge retrieval and precedent packaging with source traceability.

### Human-only gates

Legal advice, conflict clearance, strategy, privilege decisions, final filings, settlement, client commitments, and unsupervised external communications.

### Proof

Citation accuracy, missed-risk rate, privilege/data leakage tests, turnaround time, lawyer override rate, deadline integrity, and complete matter audit trail.

## Accounting, tax, and audit

### Systems to discover

General ledger, ERP, bank feeds, document portals, tax/audit software, payroll, AP/AR, spreadsheets, CRM, practice management, and regulatory knowledge sources.

### High-value workflows

- Client document request, extraction, completeness, and anomaly queue.
- Transaction classification recommendations with evidence.
- Reconciliation preparation and unmatched-item investigation.
- Vouching/support matching and cited workpaper preparation.
- Close checklist monitoring and exception escalation.
- Regulatory research and policy-change impact drafts.

### Human-only gates

Posting material entries, signing reports/returns, changing accounting policy, audit conclusions, independence judgments, and regulatory submissions.

### Proof

Tie-out accuracy, evidence coverage, exception recall, rework, close time, reviewer overrides, segregation-of-duties compliance, and reproducible workpapers.

## Vehicle repair operations

### Systems to discover

Workshop/DMS, booking, telephony, parts catalogue/inventory, technician scheduling, diagnostic systems, warranty portals, payments, messaging, and vehicle history.

### High-value workflows

- Missed-call recovery, triage, appointment preparation, and reminders.
- VIN/history-aware pre-diagnosis questions for advisor review.
- Job-to-technician preparation based on skill, capacity, and parts status.
- Estimate explanation drafts and approval tracking.
- Parts availability and delay notifications.
- Declined-work, maintenance, no-show, and post-service follow-up.

### Human-only gates

Safety diagnosis, final repair authorization, warranty representation, price commitment outside policy, roadworthiness, and dispute resolution.

### Proof

Booked-job conversion, first-time fix proxy, no-show rate, bay utilization, parts-delay rate, customer override/complaint rate, and safe escalation accuracy.

## Vehicle retail and dealerships

### Systems to discover

DMS, CRM, inventory/merchandising, OEM portals, finance/insurance tools, valuation, website/chat, telephony, e-signature, service history, and marketing platforms.

### High-value workflows

- Lead capture, source reconciliation, qualification, routing, and follow-up.
- Inventory-aware vehicle matching and appointment preparation.
- Trade-in evidence collection and appraisal packet preparation.
- Missing-document and deal-stage monitoring.
- Handoffs from sales to finance, delivery, and service.
- Post-sale onboarding, service outreach, and dormant-lead reactivation.

### Human-only gates

Credit decisions, regulated finance/insurance disclosures, final valuation, binding price/discount, contract signature, and complaint resolution.

### Proof

Speed-to-lead, appointment show rate, duplicate-lead reduction, inventory-match quality, deal-cycle time, compliance completeness, and customer opt-out rate.

## Cross-industry opportunity table

| Operational pattern | Agent role | Existing software action | Risk |
|---|---|---|---|
| Missing inputs | Detect, request, track | Update case/task status | Low–medium |
| Duplicate entry | Extract and map | Create pending record | Medium |
| Queue prioritization | Rank with reasons | Add priority/recommendation | Medium |
| Professional decision | Prepare evidence | No final action | High |
| Customer communication | Draft/personalize | Send only after policy/approval | Medium–high |
| Compliance submission | Validate package | Human submits | High |
| Scheduling | Check constraints | Tentative booking/confirmation | Medium |
| Exception handling | Detect and route | Assign accountable human | Low–medium |
