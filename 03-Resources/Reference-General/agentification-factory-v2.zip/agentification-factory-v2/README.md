# Agentification Factory v2

Updated: 2026-10-09

A reusable, industry-neutral operating kit for forward-deployed engineers (FDEs) who audit operations, integrate agents into existing software, prove outcomes, and transfer a governed system to the client.

This package is **not limited to CRM development**. It covers process discovery, systems-of-record integration, policy encoding, agent deployment, evaluation, adoption, monitoring, and continuous improvement.

## Files

1. `01-FDE-OPERATING-MODEL.md` — engagement and delivery model.
2. `02-PROCESS-AUDIT.md` — evidence-led operational audit.
3. `03-AGENTIFICATION-ARCHITECTURE.md` — system architecture and integration rules.
4. `04-INDUSTRY-PLAYBOOKS.md` — legal, accounting, repair, and vehicle retail modules.
5. `05-FACTORY-QUALITY-GATES.md` — isolate, build, prove, cross-test, ship.
6. `06-GOVERNANCE-AND-APPROVALS.md` — autonomy, risk, RACI, data controls.
7. `07-DEPLOYMENT-AND-ADOPTION.md` — pilot, rollout, observability, handover.
8. `08-SOURCES-AND-ATTRIBUTION.md` — source links, licenses, and adaptation notes.
9. `factory-gatekeeper.mjs` — dependency-free Node.js task validator and gate scorer.
10. `task.example.json` — generic task manifest.

## Start

```bash
node --version                 # Node 20+ recommended
node factory-gatekeeper.mjs task.example.json
```

## Core rule

```text
Audit real work → select one measurable workflow → integrate around the system of record
→ run silently → prove results → cross-test independently → human-approved release
→ monitor → transfer ownership → expand only after evidence
```

## Constraints

- Agents never merge or deploy production autonomously.
- Existing systems of record remain authoritative unless replacement is explicitly approved.
- Every write action is permissioned, logged, reversible where possible, and linked to evidence.
- A 5/5 score means all gates have evidence; it is not model self-confidence.
