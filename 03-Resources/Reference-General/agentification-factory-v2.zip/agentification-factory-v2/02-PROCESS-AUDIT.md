# Company Process Audit

## Goal

Find work where people currently act as glue between systems, then determine whether to simplify, integrate, automate, or agentify it. Do not begin from a preferred model or tool.

## Audit sequence

### Intake

Collect:

- Business objective and pain statement.
- Process owner, operators, approvers, customers, and regulators.
- Applications, databases, inboxes, spreadsheets, documents, devices, and vendors.
- Volumes, seasonality, service levels, costs, complaints, and known incidents.
- Data classes, retention rules, legal basis, residency, and vendor restrictions.

### Observe

For 5–10 representative cases, record:

| Step | Actor | Input | System | Decision | Output | Wait | Exception | Evidence |
|---|---|---|---|---|---|---|---|---|
| Example | Role, not name | Source record | System of record | Rule/judgment | Changed record | Minutes/hours | Failure path | Screenshot/log ID |

Never map only the official procedure. Compare written policy, interviews, screen observation, and system logs.

### Classify

Label each activity:

- `REMOVE` — no customer/control value.
- `SIMPLIFY` — policy or form can be reduced.
- `INTEGRATE` — duplicate entry between systems.
- `AUTOMATE` — deterministic rules are sufficient.
- `ASSIST` — AI drafts/recommends; human decides.
- `AGENTIFY` — bounded multi-step action is justified.
- `HUMAN_ONLY` — professional judgment, consent, negotiation, or irreversible consequence.

### Score candidate workflows

Score 0–2 per factor:

| Factor | 0 | 1 | 2 |
|---|---|---|---|
| Frequency | Rare | Regular | High-volume |
| Friction | Low | Moderate | Material delay/rework |
| Data readiness | Missing | Partial | Reliable and accessible |
| Rules/evidence | Tacit | Mixed | Defined and testable |
| Reversibility | Hard to undo | Partly reversible | Fully reversible |
| Integration | Closed/manual | Limited | Stable API/events |
| Risk | High | Managed | Low |
| Value | Unclear | Plausible | Measurable |

Start with high-value, data-ready, reversible workflows. High-risk workflows may be assisted but should not be autonomous first pilots.

## Required outputs

1. Current-state process map.
2. System-of-record and connector inventory.
3. Data classification and access matrix.
4. Exception and failure-mode catalogue.
5. Baseline measurements.
6. Automation/agentification opportunity register.
7. Recommended first pilot and explicit non-goals.
8. Human approval map.
9. Evaluation set from real, redacted historical cases.
10. Rollback and incident ownership.

## Workflow audit prompt

```text
Act as an FDE process auditor. Do not design a solution yet.
For the selected workflow, identify actors, triggers, systems of record, inputs,
decisions, outputs, handoffs, exceptions, approvals, personal data, failure cost,
current measurements, and evidence gaps. Separate observed facts from assumptions.
Recommend REMOVE, SIMPLIFY, INTEGRATE, AUTOMATE, ASSIST, AGENTIFY, or HUMAN_ONLY
for each step. Escalate missing access, policy, or ownership instead of guessing.
```
