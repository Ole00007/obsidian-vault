# Agentification Architecture

## Principle

Agents form a governed operations layer over existing systems of record. They should not create a competing shadow database, bypass current permissions, or force staff to abandon working software.

## Reference architecture

```text
Channels
(email, voice, web, WhatsApp, internal UI, cron, webhook)
        |
        v
Intake + identity + tenant boundary
        |
        v
Durable orchestrator / case state machine
        |
        +--> Policy engine and approval gates
        +--> Context builder / retrieval
        +--> Small specialist agents
        +--> Deterministic tools and calculations
        |
        v
Integration gateway
(API, webhook, queue, ETL, MCP, browser last)
        |
        v
Systems of record
(CRM, practice management, accounting, DMS, ERP, email, storage)
        |
        v
Evidence ledger + observability + cost + outcome metrics
```

## State rules

- Business state remains in the authoritative application.
- Workflow state is durable, resumable, idempotent, and correlated by case ID.
- Prompts and policies are versioned like code.
- Tool inputs and outputs use schemas; free-form text never directly executes writes.
- Retries use idempotency keys and bounded backoff.
- Every agent action records actor, tenant, case, model, prompt/policy version, tool, input hash, result, cost, and approval.

## Integration priority

1. Supported API and webhook.
2. Database read replica or governed service account.
3. File/event export.
4. MCP server behind an allowlist and policy gateway.
5. UI/browser automation only when no stable interface exists.

## Agent permissions

| Tier | Allowed | Example |
|---|---|---|
| Observe | Read and summarize | Inspect queue, classify documents |
| Recommend | Draft but cannot write | Proposed response or journal mapping |
| Prepare | Create pending object | Draft appointment, task, workpaper |
| Execute reversible | Write with full audit/undo | Tag record, schedule tentative slot |
| Execute consequential | Human approval required | Send client message, post entry, submit filing |
| Forbidden | Never delegated | Conceal evidence, bypass consent, change own controls |

## Required production controls

- Tenant isolation and least-privilege identities.
- Explicit tool allowlists and parameter validation.
- Human approval for consequential or irreversible actions.
- Audit trail and decision evidence.
- Prompt-injection and untrusted-content boundaries.
- Data minimization, redaction, retention, and deletion.
- Evaluation suites by workflow and risk class.
- Cost ceilings by case, day, model, and tool.
- Kill switch, pause/resume, retry policy, and rollback.
- Monitoring for failure, drift, overrides, latency, adoption, and spend.

## Multi-agent rule

Use multiple agents only when at least one is true:

- Independent review is required.
- Different permissions must be isolated.
- Work can be safely parallelized.
- Domain specializations use different context and tools.

Otherwise, prefer one workflow with deterministic code and one focused agent.
