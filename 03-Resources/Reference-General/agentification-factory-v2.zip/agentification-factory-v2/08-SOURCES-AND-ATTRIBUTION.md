# Sources and Attribution

This package is an original synthesis. It does **not** reproduce third-party documents. Source patterns were adapted into a cross-industry implementation kit.

## Primary and useful sources

- [OpenAI — Forward Deployed Engineer role](https://openai.com/careers/forward-deployed-engineer-%28fde%29-sf-san-francisco/) — discovery through production rollout, adoption, measurable workflow impact, reusable playbooks.
- [Atlassian — Forward Deployed Engineering](https://www.atlassian.com/enterprise/success/fde) — discover, build, adopt, and scale inside existing enterprise workflows.
- [HumanLayer — 12-Factor Agents](https://github.com/humanlayer/12-factor-agents) — production-agent principles including owned control flow/context, small agents, unified state, pause/resume, and human contact. Content is CC BY-SA 4.0; code is Apache 2.0.
- [General Action — Emdash](https://github.com/generalaction/emdash) — parallel coding agents using isolated worktrees.
- [Trigger.dev](https://github.com/triggerdotdev/trigger.dev) — durable AI agents and background workflows.
- [Vercel Workflow](https://github.com/vercel/workflow) — durable, reliable, observable TypeScript workflows.
- [Thomson Reuters — Agentic AI governance in legal](https://www.thomsonreuters.com/en/institute/articles/iltacon-2026-agentic-ai-automation) — reversibility, observability, permissible use, and accountability.
- [Thomson Reuters — Agentic workflows in professional services](https://www.thomsonreuters.com/en/insights/articles/how-to-use-agentic-ai-workflows-in-professional-services) — integrated legal, tax, and audit workflows with professional review.
- [AICPA & CIMA — AI in enterprise systems](https://www.aicpa-cima.com/professional-insights/article/how-ai-is-transforming-enterprise-systems) — embed AI into core systems with traceability and auditability.
- [Salesforce — Dealer management software](https://www.salesforce.com/automotive/car-dealership-software/dealer-management-software/) — dealership systems, service, sales, parts, finance, and integration context.

## October 2026 update incorporated

The update strengthens:

- FDE ownership from discovery to measurable production adoption.
- Operational process audit before software selection.
- Agents layered on existing systems of record.
- Durable, resumable workflow state and evidence ledgers.
- Small focused agents instead of default swarms.
- Reversibility, explicit permissions, and human consequential-action gates.
- Adoption, handover, unit economics, and measurable operational outcomes.
- Industry modules beyond CRM: legal delivery, accounting/audit, repair operations, and dealership operations.

## License note

The package may be used as an internal operating template. Before redistributing adaptations of source-specific wording or code, review each linked repository/site license. The included JavaScript is newly written for this package.
