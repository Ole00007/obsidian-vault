# Governance and Approvals

## Decision rule

Treat every delegated action as either reversible or consequential. Reversible work can run automatically inside budgets; consequential work requires explicit approval, stronger evidence, or remains human-only.

## Autonomy matrix

| Level | Agent may | Approval |
|---|---|---|
| Green | Read, classify, summarize, test, prepare internal drafts | None inside approved scope |
| Yellow | Create pending records, open PRs, queue communications, recommend changes | Digest or designated reviewer |
| Red | Merge, deploy, send externally, post entries, change permissions, spend, delete | Named human before action |
| Black | Bypass controls, hide evidence, self-expand permissions, train on client data without basis | Forbidden |

## RACI minimum

Every workflow names:

- Business process owner — accountable for outcome and policy.
- System owner — accountable for integration and availability.
- Data/privacy owner — accountable for lawful access and retention.
- Agent workflow owner — accountable for prompt, tools, evals, and incidents.
- Human approver — accountable for consequential actions.
- Operator — responsible for monitoring and recovery.

## Data controls

- Inventory data classes and systems before connecting agents.
- Use per-tenant, per-environment, least-privilege credentials.
- Do not place secrets or unnecessary personal data in prompts, logs, memory, or evidence.
- Separate production, staging, synthetic test data, and memory banks.
- Define retention and deletion for traces, artifacts, recordings, and embeddings.
- Preserve professional confidentiality, privilege, independence, and segregation of duties.

## Tool controls

- Default deny; enable tools per workflow.
- Validate structured input before execution.
- Separate read and write identities.
- Add idempotency and dry-run modes.
- Cap retries, model spend, tool spend, and case duration.
- Require approval tokens for red actions.
- Log denied actions as well as executed ones.

## Incident triggers

Pause automatically on:

- Cross-tenant or unauthorized access.
- Missing audit events.
- Unexpected write volume.
- Repeated tool failure or retry loop.
- Cost/latency ceiling breach.
- Evaluation regression.
- Unsupported professional conclusion.
- Prompt injection or untrusted instruction reaching a write tool.

## Human attention budget

Humans review exceptions, not every successful step. Use:

- Immediate alert for red incidents.
- Daily digest for decisions and blocked work.
- Weekly outcome/cost/adoption review.
- Monthly permission, evaluation, and retention review.
