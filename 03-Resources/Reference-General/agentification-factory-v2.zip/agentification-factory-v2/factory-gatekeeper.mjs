#!/usr/bin/env node
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const PHASES = ['intake', 'audit', 'isolate', 'build', 'prove', 'cross-test', 'score', 'ship', 'observe'];
const INDUSTRIES = ['generic', 'legal', 'accounting', 'auto-repair', 'auto-retail'];
const RISKS = ['low', 'medium', 'high', 'critical'];
const GATES = ['scope', 'technical', 'operational', 'safety', 'delivery'];

function fail(message, details = []) {
  console.error(JSON.stringify({ ok: false, message, details }, null, 2));
  process.exit(1);
}

function nonEmpty(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function hasEvidence(task, gate) {
  const items = task.evidence?.[gate];
  return Array.isArray(items) && items.some(nonEmpty);
}

function validate(task) {
  const errors = [];
  for (const field of ['id', 'title', 'branch', 'worktree', 'systemOfRecord', 'processOwner', 'humanReleaseOwner']) {
    if (!nonEmpty(task[field])) errors.push(`Missing ${field}`);
  }
  if (!INDUSTRIES.includes(task.industry)) errors.push(`industry must be: ${INDUSTRIES.join(', ')}`);
  if (!RISKS.includes(task.risk)) errors.push(`risk must be: ${RISKS.join(', ')}`);
  if (!PHASES.includes(task.phase)) errors.push(`phase must be: ${PHASES.join(', ')}`);
  if (!task.branch?.startsWith('feat/') && !task.branch?.startsWith('fix/') && !task.branch?.startsWith('chore/')) {
    errors.push('Use an isolated feat/, fix/, or chore/ branch');
  }
  if (['main', 'master'].includes(task.branch)) errors.push('Direct work on main/master is forbidden');
  const budget = task.budget ?? {};
  if (!(budget.maxCredits >= 0)) errors.push('budget.maxCredits must be set');
  if (!(budget.maxToolCalls > 0)) errors.push('budget.maxToolCalls must be positive');
  if (!(budget.maxMinutes > 0)) errors.push('budget.maxMinutes must be positive');
  if (task.permissions?.consequential === true) errors.push('Consequential permission cannot be pre-authorized in a task manifest');
  return errors;
}

function score(task) {
  const gates = Object.fromEntries(GATES.map((gate) => [gate, hasEvidence(task, gate)]));
  if (!task.crossTest?.passed || Number(task.crossTest?.blockingFindings ?? 0) > 0) {
    gates.safety = false;
    gates.delivery = false;
  }
  return { gates, total: Object.values(gates).filter(Boolean).length };
}

function decision(task, result) {
  if (result.total < 5) return { action: 'RETURN_TO_FAILED_GATE', mergeReady: false, deployReady: false };
  if (!task.humanApproval?.approved) return { action: 'AWAIT_HUMAN_APPROVAL', mergeReady: true, deployReady: false };
  if (!nonEmpty(task.humanApproval.approvedBy) || !nonEmpty(task.humanApproval.approvedAt)) {
    return { action: 'INVALID_APPROVAL_RECORD', mergeReady: false, deployReady: false };
  }
  return { action: 'HUMAN_MAY_SHIP', mergeReady: true, deployReady: true };
}

const file = process.argv[2];
if (!file) fail('Usage: node factory-gatekeeper.mjs <task.json>');

let task;
try {
  task = JSON.parse(await readFile(resolve(file), 'utf8'));
} catch (error) {
  fail('Cannot read task manifest', [error.message]);
}

const errors = validate(task);
if (errors.length) fail('Task manifest rejected', errors);

const result = score(task);
const outcome = decision(task, result);
const report = {
  ok: true,
  task: task.id,
  phase: task.phase,
  risk: task.risk,
  score: `${result.total}/5`,
  gates: result.gates,
  crossTest: task.crossTest,
  humanApproval: task.humanApproval,
  outcome
};

console.log(JSON.stringify(report, null, 2));
process.exit(outcome.deployReady ? 0 : 2);
