# Install and Test

```bash
unzip agentification-factory-v2.zip
cd agentification-factory-v2
node factory-gatekeeper.mjs task.example.json
```

Expected result: `5/5`, `AWAIT_HUMAN_APPROVAL`, exit code `2`. This is deliberate: evidence may make a task merge-ready, but only a valid human approval record permits shipping.

To test approval, edit only:

```json
"humanApproval": {
  "approved": true,
  "approvedBy": "human-release-owner",
  "approvedAt": "2026-10-09T17:00:00+02:00"
}
```

Then run the command again. Do not use this script as the sole production control; enforce protected branches, CI checks, environment approvals, and least-privilege credentials in the real platform.
