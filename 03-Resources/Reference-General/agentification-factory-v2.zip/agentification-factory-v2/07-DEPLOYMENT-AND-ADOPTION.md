# Deployment and Adoption

## Rollout path

### Phase 0 — Baseline

Measure the current workflow and create the evaluation set. No agent writes.

### Phase 1 — Offline replay

Run historical, redacted cases. Compare agent decisions with actual outcomes and expert review.

### Phase 2 — Shadow mode

Use live inputs but suppress side effects. Compare recommendations, latency, coverage, and errors.

### Phase 3 — Assisted pilot

Agents prepare work; humans approve every consequential action. Start with one team, location, case type, or threshold.

### Phase 4 — Bounded autonomy

Automate only proven reversible actions. Keep exception routing and approval thresholds.

### Phase 5 — Scale

Add workflows or business units only after stable outcomes, adoption, controls, support, and unit economics.

## Operational dashboard

Track by workflow and tenant:

- Cases started/completed/failed/escalated.
- Cycle and waiting time.
- Manual touches removed and new rework introduced.
- Accuracy/evaluation score and drift.
- Human overrides and reasons.
- Tool/model cost per completed case.
- Latency and integration availability.
- Security/privacy events.
- Adoption by role and location.
- Outcome KPI tied to the original contract.

## Runbook

Every deployed workflow documents:

1. Trigger and expected result.
2. Systems, accounts, permissions, and data classes.
3. Normal state and health checks.
4. Failure modes and escalation owner.
5. Pause, resume, retry, replay, and kill-switch commands.
6. Rollback and record reconciliation.
7. Evaluation and release procedure.
8. Cost limits and model fallback order.
9. Vendor failure and manual continuity procedure.
10. Change log and responsible owner.

## Adoption

- Train operators on supervision, correction, and escalation—not generic prompting.
- Show evidence and limitations in the same interface as recommendations.
- Capture overrides as structured feedback, not hidden chat corrections.
- Do not measure success only by usage; measure business outcome and reduced rework.
- Transfer ownership through paired operation, recorded drills, and a client-run release.

## 30/60/90 outline

| Period | Focus | Exit evidence |
|---|---|---|
| Days 0–30 | Audit, baseline, connectors, first shadow path | Process map, eval set, shadow results |
| Days 31–60 | Integrate, harden, assisted pilot | Controls, runbook, adoption and quality data |
| Days 61–90 | Bounded release, measure, handover | Outcome delta, ownership drill, scale/stop decision |
