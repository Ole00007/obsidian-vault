# FDE Operating Model

## Mission

Turn one costly company workflow into a measurable, governed production capability. The FDE owns discovery, technical scoping, system design, integration, release, adoption, and handover—not only software delivery.

## Engagement pod

| Role | Accountable for | Cannot approve alone |
|---|---|---|
| Deployment strategist | Outcome, process ownership, adoption | Technical release |
| FDE lead | Architecture, integration, delivery | Own production merge |
| Process auditor | Current-state evidence, exceptions, controls | Automation target |
| Builder agents | Scoped implementation | Own review or score |
| Prover/tester | Evals, before/after proof | Business acceptance |
| Security/privacy reviewer | Access, data, threat controls | Commercial scope |
| Client process owner | Policy, acceptance, escalation | Hidden technical risk |
| Human release owner | Final merge/deploy decision | Skip required evidence |

One person may hold several roles in a small team, but the builder and final reviewer must use separate sessions and evidence.

## Delivery cycle

### Discover

- Shadow actual work, including spreadsheets, email, calls, chat, paper, and undocumented handoffs.
- Identify the real system of record for every decision and write.
- Capture exceptions, rework, approvals, waiting time, access boundaries, and failure costs.
- Establish baseline measures before proposing AI.

### Design

Choose the least complex mechanism that works:

1. Existing software feature.
2. Deterministic rule or integration.
3. Retrieval or classification model.
4. Single tool-using agent.
5. Multi-agent workflow only when role separation or parallel specialization is justified.

### Build

- Put agents around existing software through APIs, webhooks, queues, files, browser automation only as a last resort, and MCP where governed.
- Keep business state in the operational system; keep execution state in a durable workflow log.
- Use small agents with narrow permissions and explicit stop conditions.

### Prove

- Replay historical cases first.
- Run in shadow mode without side effects.
- Compare outcomes to the baseline and approved evaluation set.
- Test happy paths, exceptions, adversarial inputs, permissions, rollback, and recovery.

### Adopt

- Introduce the workflow to the people who perform and supervise it.
- Preserve clear escalation and manual takeover.
- Measure adoption, overrides, cycle time, error/rework, and cost per completed case.

### Transfer

The engagement is complete only when the client can:

- Explain the workflow and controls.
- Pause or disable agents.
- Inspect evidence and audit trails.
- Rotate credentials and change permissions.
- Add a similar use case from the documented template.

## Outcome contract

Every engagement starts with:

```yaml
business_outcome: one measurable result
process_owner: named human role
system_of_record: named application/database
baseline_period: defined dates
success_metrics: cycle time, touches, quality, cost, adoption
forbidden_actions: irreversible or regulated actions
pilot_boundary: team, location, workflow slice, or case type
rollback_owner: named human role
```
